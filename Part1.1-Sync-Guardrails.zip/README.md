# 同期検査・再発防止

使い方と必要な依存関係は tools/media-sync/README.md、運用ルールは docs/media-sync.md を参照してください。元の動画素材は含みません。回帰試験の成功と、完成動画の同期確認は別の検査です。
