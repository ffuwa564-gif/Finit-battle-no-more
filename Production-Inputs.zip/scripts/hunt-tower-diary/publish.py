from pathlib import Path
import json,hashlib,shutil,subprocess
R=Path('artifacts/hunt-tower-diary');D=R/'delivery';P=Path('/workspace/stillveil-hunt-tower-media');repo='ffuwa564-gif/Finit-battle-no-more';branch='media/hunt-tower-diary-20261107';sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
q=json.loads((D/'final-qa.json').read_text());assert q['pass']and q['sha256']==sha(D/'stillveil-hunt-tower.mp4')
for name in ['sync-audit.json','playback-audit.json','visual-review.json']:
 a=json.loads((D/name).read_text());assert a['pass']and a['sha256']==q['sha256']
manifest=json.loads((D/'SHA256.json').read_text())
for name,item in manifest.items():assert sha(D/name)==item['sha256']and (D/name).stat().st_size<95*1024*1024
for p in D.iterdir():
 if p.is_file():shutil.copyfile(p,P/p.name)
raw=f'https://raw.githubusercontent.com/{repo}/{branch}/'
(P/'README.md').write_text(f"""# 引けた仲間と拾った石で、塔１層を攻略するのだ

ずんだもん・四国めたん / 1080p / ５分12秒 / 日本語字幕。

[▶ 動画を見る・保存する]({raw}stillveil-hunt-tower.mp4)

[投稿用セット]({raw}YouTube-Package.zip) / [サムネイル]({raw}thumbnail.jpg)

![サムネイル](thumbnail.jpg)

通常探索のハクスラ周回、レア回収、研磨、引けた仲間からの編成変更を描く攻略実況。新規データの自動操作記録を実ゲームUIで再生・編集しています。特定の４人を待たず、同じガチャの実際の取得結果と石から考えます。実時間の手操作録画とは区別し、収集省略・戦闘抜粋・倍率を表示しています。

塔は38R・３人生存・薬５個で突破。その後の周回用編成変更で、この記録では聖堂28体Aから55体Sへ。編成・石・指示・乱数が異なる各１回の結果です。最短攻略や最強編成の主張ではありません。

[制作記録]({raw}Production-Inputs.zip) / [検査](final-qa.json) / [台本](script.md) / [YouTube説明文](youtube-description.txt)

音声：VOICEVOX:ずんだもん／VOICEVOX:四国めたん。音楽：甘茶の音楽工房「フィヨルドの澄んだ風」。投稿時は説明文のクレジットを掲載してください。

収録ソースは1.28.0＋稀な敵の出発停止の局所修正。公開ゲームのマージ・配信や、YouTube投稿は行っていません。

完成MP4 SHA-256：`{q['sha256']}`
""")
def git(*args):subprocess.run(['git','-C',str(P),*args],check=True)
# Separate pushes keep each request bounded; all files passed QA before the first push.
names=[p.name for p in P.iterdir()if p.is_file()and p.name not in ['.git','YouTube-Package.zip','Production-Inputs.zip']]
for files,message in [(names,'media: publish verified adaptive hunt and tower diary'),(['YouTube-Package.zip'],'media: add adaptive hunt diary posting package'),(['Production-Inputs.zip'],'media: add reproducible adaptive hunt diary production inputs')]:
 git('add','--',*files);git('commit','-m',message);git('push','origin',f'HEAD:refs/heads/{branch}')
commit=subprocess.check_output(['git','-C',str(P),'rev-parse','HEAD'],text=True).strip();report={'repository':repo,'branch':branch,'commit':commit,'sha256':q['sha256'],'urls':{name:f'https://raw.githubusercontent.com/{repo}/{commit}/{name}'for name in ['stillveil-hunt-tower.mp4','YouTube-Package.zip','Production-Inputs.zip','thumbnail.jpg','final-qa.json']}};(R/'publication.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
