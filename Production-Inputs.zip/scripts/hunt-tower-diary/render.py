from pathlib import Path
import json,subprocess,wave,math,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path('artifacts/hunt-tower-diary').resolve();S=json.loads((R/'script.json').read_text());P=json.loads((R/'playthrough.json').read_text());C=json.loads((R/'capture-with-audio.json').read_text());clips={c['id']:c for c in C['clips']};lines={l['id']:l for l in S['lines']};FPS=30;SR=48000;SPF=1600;W,H=1920,1080;T=0;scenes=[];voices=[]
for s in S['scenes']:
 row={**s,'startFrame':T,'start':T/FPS,'clipStartFrame':T};f=T+9
 if s['id']=='finish':
  death=next((c for c in clips[s['clip']]['cues'] if c['event']['kind'] in ['attack','area'] and any(u['side']=='enemy' and u['hp']==0 and u['uid']in c['event'].get('targetIds',[]) for u in c['event'].get('unitsAfter',[]))),None)
  if death:f=T+death['frame']+9
 for lid in s['lines']:
  l=lines[lid];p=R/'voices'/f'{lid}.wav'
  with wave.open(str(p)) as q:n=q.getnframes();assert q.getframerate()==SR
  v={**l,'file':str(p),'frame':f,'start':f/FPS,'samples':n,'duration':n/SR,'endFrame':f+math.ceil(n/SPF)};voices.append(v);f=v['endFrame']+9
 duration=max(f+12,T+(clips[s['clip']]['frames'] if s['clip'] else 0)+6);row['frames']=duration-T;row['duration']=row['frames']/FPS;T=duration;scenes.append(row)
N=T*SPF

def decode(p):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-ac','2','-ar','48000','-f','f32le','-']),'<f4').reshape(-1,2).copy()
def wav(p,x):
 with wave.open(str(p),'wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(SR);f.writeframes((np.clip(x,-1,1)*32767).astype('<i2').tobytes())
# One continuous music bed, loops with equal-power 100ms crossfades, never cuts at scene boundaries.
x=decode('public/audio/fjordnosundakaze.mp3');music=np.zeros((N,2),np.float32);overlap=4800;at=0
while at<N:
 y=x[:min(len(x),N-at)].copy();n=len(y)
 if at>0:
  f=min(overlap,n);y[:f]*=np.sin(np.linspace(0,np.pi/2,f))[:,None];music[at:at+f]*=np.cos(np.linspace(0,np.pi/2,f))[:,None]
 music[at:at+n]+=y;at+=len(x)-overlap
music*=.055;fade=min(SR,N//2);music[:fade]*=np.linspace(0,1,fade)[:,None];music[-fade:]*=np.linspace(1,0,fade)[:,None]
speech=np.zeros_like(music);game=np.zeros_like(music);duck=np.ones(N,np.float32)
for v in voices:
 a=v['frame']*SPF;y=decode(v['file']);f=min(240,len(y)//4);y[:f]*=np.linspace(0,1,f)[:,None];y[-f:]*=np.linspace(1,0,f)[:,None];speech[a:a+len(y)]+=y*.94
 before=min(a,960);end=min(N,a+len(y));after=min(N-end,3840)
 if before:duck[a-before:a]=np.minimum(duck[a-before:a],np.linspace(1,.72,before))
 duck[a:end]=np.minimum(duck[a:end],.72)
 if after:duck[end:end+after]=np.minimum(duck[end:end+after],np.linspace(.72,1,after))
for s in scenes:
 if s['clip'] and clips[s['clip']]['audio']:
  c=clips[s['clip']];y=decode(c['audioFile']);a=s['clipStartFrame']*SPF;n=min(len(y),N-a);game[a:a+n]+=y[:n]*.45
# The same smooth envelope applies to audible music and SE; no hard gain steps under speech.
music*=duck[:,None];game*=duck[:,None];peak=float(np.max(abs(music+speech+game)));master=min(1,.91/max(.001,peak));music*=master;speech*=master;game*=master
wav(R/'soundtrack.wav',music+speech+game);wav(R/'background-without-voice.wav',music+game);wav(R/'background-without-game.wav',music+speech);wav(R/'game-bed.wav',game)
# Persist lossless master. Final AAC is encoded only at final mux.
subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'soundtrack.wav'),'-c:a','flac',str(R/'soundtrack.flac')],check=True)
font=lambda n:ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',n);PLUM='#642c4e';INK='#4e2942';PINK='#b84b82';EDGE='#dca9c0';BG='#fffaf4'
def wrap(t,n,w):
 rows=[];cur=''
 for ch in t:
  if font(n).getlength(cur+ch)>w and cur:rows.append(cur);cur=ch
  else:cur+=ch
 if cur:rows.append(cur)
 return rows
base=Image.new('RGB',(W,H),'#f9e8ef');d=ImageDraw.Draw(base)
for x in range(-1080,1920,32):d.line((x,0,x+1080,1080),fill='#f4dfe9',width=8)
d.rounded_rectangle((296,60,1624,930),radius=24,fill=BG,outline=EDGE,width=3);d.rectangle((304,60,802,932),fill=PLUM)
d.text((30,70),'ずんだもんの',font=font(29),fill=PLUM);d.text((30,120),'拾い物日誌',font=font(35),fill=PINK);d.text((30,174),'NEW GAME',font=font(25),fill=PLUM)
d.text((850,77),'STILLVEIL',font=font(55),fill=PLUM);d.text((853,150),'白亜の塔 １層',font=font(27),fill='#9f7089')
d.rounded_rectangle((18,946,1902,1074),radius=20,fill=BG,outline=EDGE,width=3)
avatars={name:Image.open(R/'assets'/f'{name}-avatar.png').convert('RGBA')for name in ['z-happy','z-panic','m-happy','m-deadpan']}
assets=json.loads((R/'content.json').read_text());chars={c['id']:c for c in assets['characters']};art={a['id']:a['path']for a in assets['assets']};faces={}
towerSave=P['shots']['goal-party']['save'];farmSave=P['shots']['farm-party']['save']
for cid in set(towerSave['partyIds']+farmSave['partyIds']):
 path=Path('public')/art[chars[cid]['portraitId']].lstrip('/');im=Image.open(path).convert('RGBA');im.thumbnail((90,90));faces[cid]=im
(R/'frames').mkdir(exist_ok=True);(R/'scene-game').mkdir(exist_ok=True)
todos=['通常探索を踏破して塔を解放','引けた仲間の仕事を考える','拾った石で編成を更新','塔１層を突破、報酬確定','周回用の編成も組んでみる']
def equipment(save):
 result=[]
 for cid in save['partyIds']:
  g=next((g for g in save['memoryGems']['items']if g['id']==save['memoryGems']['equipped'].get(cid)),None)
  names={'shield-break':'砕盾石','pale-ward':'白灯石','dream-lace':'夢織石','wick-stone':'灯芯の補助石','clear-tear':'祓いの涙石','echo-shard':'残響石'}
  if g:
   r=g.get('roll',{'power':0,'value':0,'trait':'none'});val=max(r['power'],r['value']if r['trait']!='none'else 0);tier=next((t for t,lo in reversed(list(enumerate([0,34,67,120,160,220],1)))if val>=lo),1);stat=f"T{tier}｜威力{r['power']}・"+({'bulwark':'庇護','mercy':'慈雨','execution':'処刑','chain':'連鎖','none':'特性なし'}.get(r['trait'],r['trait']))+(str(r['value'])if r['trait']!='none'else'');result.append((cid,names.get(g['defId'],g['defId']),stat))
  else:result.append((cid,'記憶石なし','手持ちの通常スキル'))
 return result
gear=equipment(towerSave);farmgear=equipment(farmSave)
def board(s,v):
 im=base.copy();d=ImageDraw.Draw(im)
 title=wrap(s['title'],38,720)
 for i,t in enumerate(title):d.text((850,205+i*48),t,font=font(38),fill=PLUM)
 top=325
 if s['board'] in ['goal','gear','farm']:
  for i,(cid,gname,stat)in enumerate(farmgear if s['board']=='farm'else gear):
   y=top+i*106;d.rounded_rectangle((840,y,1594,y+95),radius=15,fill='#f9e8ef',outline=EDGE,width=1);im.alpha_composite(faces[cid],(850,y+3)) if im.mode=='RGBA' else im.paste(faces[cid],(850,y+3),faces[cid]);d=ImageDraw.Draw(im);d.text((955,y+5),chars[cid]['name']+'  ／  '+gname,font=font(26),fill=PLUM)
   text=stat if s['board']=='gear' else (['全体攻撃を先頭から予約','リーダー・守りを担当','単体攻撃と吸命','防御低下・強化解除'][i] if s['board']=='farm'else ['吸命＋障壁を使った砲撃','リーダー・かばう・吸命','回復＋夢織石の睡眠','Rの守り役・全体攻撃強化'][i]);d.text((955,y+51),text,font=font(23),fill=INK)
 elif s['board']=='progress':
  d.text((850,340),'今回の取得・再挑戦記録',font=font(29),fill=PLUM)
  for i,t in enumerate(['祈願 85回／特定の４人を狙わない','２回目：イザナミ','37回目：ヘカテ','47回目：弁財天','48回目：Rアテナ','73回目：フレイヤ','塔は58回目の挑戦で突破']):d.text((850,401+i*51),t,font=font(28),fill=PINK if i in [0,6]else INK)
 elif s['board']=='compare':
  for i,t in enumerate(['同じ聖堂・100手の今回の記録','塔攻略用の編成：28体／A','全体攻撃を優先：55体／S','獲得原石：５個 → 11個']):d.text((850,350+i*94),t,font=font(30 if i==0 else 38),fill=PLUM if i==0 else PINK)
  for i,t in enumerate(['編成・装備・指示・乱数が異なります。','各１回の記録。毎回の収穫保証ではありません。']):d.text((850,744+i*31),t,font=font(22),fill=INK)
 elif s['board']=='tools':
  for i,t in enumerate(['余剰素材 → 研磨粉','作業台で研磨布を製作','布は１個につき原石１個を開封','Tierや特性の抽選は変わらない']):d.text((850,350+i*95),t,font=font(31),fill=PLUM)
 elif s['board']=='credits':
  for i,t in enumerate(['音声：VOICEVOX','ずんだもん／四国めたん','音楽：甘茶の音楽工房','「フィヨルドの澄んだ風」','新規データの自動操作記録を再生','周回省略・戦闘抜粋・SE再構成']):d.text((850,340+i*62),t,font=font(28),fill=PLUM)
 else:
  d.text((850,324),'TODAY’S ToDo',font=font(30),fill=PINK)
  for i,t in enumerate(todos):
   y=390+i*64;done=i<s['done'];d.rounded_rectangle((847,y,1594,y+52),radius=12,fill='#f9e8ef'if not done else'#ecebdc');d.text((864,y+4),('✓  'if done else'□  ')+t,font=font(26),fill='#6f7655'if done else PLUM)
 for i,t in enumerate(wrap(s['note'],24,720)):d.text((850,815+i*32),t,font=font(24),fill='#8f607a')
 d.text((850,907),f'ver{P["version"]}  /  戦闘ログ再生・編集あり',font=font(19),fill='#947886')
 z='z-panic'if s['id']in ['summon','grind','tower-late'] else'z-happy';m='m-deadpan'if s['id']in ['summon','grind','goal']else'm-happy'
 for x,name,who in [(0,z,'z'),(1600,m,'m')]:
  art=avatars[name];im.paste(art,(x,470),art)
  if v and v['speaker']==who:d.rounded_rectangle((x+44,862,x+276,906),radius=15,fill=BG,outline=EDGE,width=2)
  d.text((x+56,869),'ずんだもん'if who=='z'else'四国めたん',font=font(23),fill='#3e7543'if who=='z'else'#aa3c76')
 # Static game snapshot underlay; moving clips replace only this rectangle.
 game=Image.open(C['shots'][s['source']]['file']).convert('RGB').resize((486,864),Image.Resampling.LANCZOS);im.paste(game,(310,66));d=ImageDraw.Draw(im)
 if v:
  color='#3e7543'if v['speaker']=='z'else'#aa3c76';rows=wrap(v['text'],48,1790)
  if len(rows)>2:raise ValueError('Caption overflow: '+v['id'])
  y=951+(110-len(rows)*54)//2
  for i,t in enumerate(rows):d.text(((1920-font(48).getlength(t))/2,y+i*54),t,font=font(48),fill=color)
 return im
cuts=[]
for s in scenes:
 sv=[v for v in voices if v['id']in s['lines']];points=sorted({s['startFrame'],s['startFrame']+s['frames'],*[v['frame']for v in sv],*[v['endFrame']for v in sv]})
 for j,(a,b)in enumerate(zip(points,points[1:])):
  v=next((v for v in sv if v['frame']<=a<v['endFrame']),None);p=R/'frames'/f'{s["id"]}-{j:03}.png';board(s,v).save(p);cuts.append({'frame':a,'frames':b-a,'file':str(p),'scene':s['id'],'voiceId':v['id']if v else None})
concat=R/'frames.ffconcat';concat.write_text('ffconcat version 1.0\n'+''.join(f"file '{c['file']}'\nduration {c['frames']/FPS:.9f}\n"for c in cuts)+f"file '{cuts[-1]['file']}'\n")
# Expand static boards before compositing to keep framesync queues bounded.
subprocess.run(['ffmpeg','-v','error','-y','-threads','2','-f','concat','-safe','0','-i',str(concat),'-r','30','-frames:v',str(T),'-c:v','libx264','-threads','4','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',str(R/'boards.mp4')],check=True)
gamefiles=[]
for s in scenes:
 target=R/'scene-game'/f'{s["id"]}.mp4';cmd=['ffmpeg','-v','error','-y','-filter_threads','1']
 if s['clip']:
  c=clips[s['clip']];cmd+=['-i',c['file'],'-vf',f"scale=486:864,tpad=stop_mode=clone:stop_duration={s['duration']},fps=30,drawbox=x=0:y=0:w=iw:h=36:color=black@0.7:t=fill:enable='gte(t,{c['duration']})',drawtext=fontfile=/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc:text=解説のため一時停止:fontcolor=white:fontsize=20:x=12:y=6:enable='gte(t,{c['duration']})'"]
 else:cmd+=['-loop','1','-framerate','30','-i',C['shots'][s['source']]['file'],'-vf','scale=486:864,format=yuv420p']
 cmd+=['-an','-frames:v',str(s['frames']),'-c:v','libx264','-threads','2','-preset','veryfast','-crf','17','-pix_fmt','yuv420p',str(target)];subprocess.run(cmd,check=True);gamefiles.append(target);print('scene',s['id'],s['duration'],flush=True)
(R/'game.ffconcat').write_text('ffconcat version 1.0\n'+''.join(f"file '{p}'\n"for p in gamefiles));subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(R/'game.ffconcat'),'-c','copy',str(R/'game-reel.mp4')],check=True)
meta={'frames':T,'duration':T/FPS,'gameRect':[310,66,486,864],'scenes':scenes,'voices':voices,'visualCuts':cuts,'masterGain':master,'peakBeforeMaster':peak,'sourceCommit':P['commit'],'version':P['version'],'audioPolicy':'Offline authored game PCM keyed to recorded event frames; 48kHz single mix, smooth fades and ducks, continuous BGM; AAC once.'};(R/'timeline.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d},{ms%1000:03d}'
(R/'stillveil-hunt-tower.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(v["start"])} --> {stamp(v["start"]+v["duration"])}\n{v["text"]}'for i,v in enumerate(voices)))
paths=[Path(__file__),R/'script.json',R/'playthrough.json',R/'capture-with-audio.json',*[Path(v['file'])for v in voices],*[Path(c['file'])for c in C['clips']]];(R/'input-hashes.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths},indent=2));print('RENDERED',T/FPS,flush=True)
