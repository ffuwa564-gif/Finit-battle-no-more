import sys,json,wave,io,hashlib
from pathlib import Path
import numpy as np
from scipy.signal import resample_poly
root=Path('artifacts/hunt-tower-diary');engine=Path('artifacts/wolf-rta-v112');sys.path.insert(0,str(engine/'pydeps'))
from voicevox_core.blocking import Onnxruntime,OpenJtalk,Synthesizer,VoiceModelFile
syn=Synthesizer(Onnxruntime.load_once(filename=str(next((engine/'voicevox').rglob('libvoicevox_onnxruntime.so.1.17.3')).resolve())),OpenJtalk(engine/'voicevox/open_jtalk_dic_utf_8-1.11'),acceleration_mode='CPU',cpu_num_threads=2)
with VoiceModelFile.open(engine/'voicevox/0.vvm')as v:syn.load_voice_model(v)
(root/'voices').mkdir(exist_ok=True);lines=json.loads((root/'script.json').read_text())['lines']
for l in lines:
 style=3 if l['speaker']=='z'else 2;key=hashlib.sha256(json.dumps([l,style,'core0.17.1-model0.17.0-speed1.16/1.12',Path(__file__).read_text()],ensure_ascii=False).encode()).hexdigest();p=root/'voices'/f"{l['id']}.wav";meta=p.with_suffix('.json')
 if p.exists()and meta.exists()and json.loads(meta.read_text()).get('key')==key:continue
 q=syn.create_audio_query(l['voice'],style);q.speed_scale=1.16 if style==3 else 1.12;q.intonation_scale=1.15;q.pre_phoneme_length=.06;q.post_phoneme_length=.08
 raw=syn.synthesis(q,style)
 with wave.open(io.BytesIO(raw),'rb')as f:pcm=np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').astype(np.float64)/32768;rate=f.getframerate()
 pcm=resample_poly(pcm,48000,rate);peak=max(.001,float(abs(pcm).max()));pcm*=min(2,.80/peak)
 with wave.open(str(p),'wb')as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(48000);f.writeframes((np.clip(pcm,-1,1)*32767).astype('<i2').tobytes())
 meta.write_text(json.dumps({'key':key,'speaker':style,'duration':len(pcm)/48000,'text':l['text']},ensure_ascii=False));print(l['id'],round(len(pcm)/48000,2),l['text'],flush=True)
