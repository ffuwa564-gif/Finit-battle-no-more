from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
R=Path('artifacts/hunt-tower-diary');im=Image.new('RGB',(1280,720),'#f9e8ef');d=ImageDraw.Draw(im);f=lambda n:ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',n)
for x in range(-720,1280,30):d.line((x,0,x+720,720),fill='#f1d7e4',width=8)
d.rounded_rectangle((24,22,1256,698),radius=24,fill='#fffaf4',outline='#b84b82',width=4)
game=Image.open(R/'shots/ready-4.png').convert('RGB').resize((337,600));im.paste(game,(42,58));d=ImageDraw.Draw(im);d.text((413,58),'STILLVEIL',font=f(37),fill='#642c4e');d.text((407,120),'白亜の塔',font=f(96),fill='#642c4e');d.text((410,235),'１層を突破！',font=f(80),fill='#b84b82')
d.rounded_rectangle((410,350,1217,457),radius=17,fill='#f9e8ef',outline='#dca9c0',width=3);d.text((433,370),'引けた仲間で、組み直すのだ',font=f(44),fill='#642c4e');d.text((430,485),'拾う → 引く → 組み直す',font=f(37),fill='#642c4e');d.text((431,550),'ハクスラ周回から、塔１層へ',font=f(30),fill='#8f607a')
for name,x in [('z-happy',970),('m-happy',1110)]:
 a=Image.open(R/'assets'/f'{name}-avatar.png').convert('RGBA');a.thumbnail((100,137));im.paste(a,(x,560),a)
d.text((40,669),'ずんだもん × 四国めたん',font=f(20),fill='#642c4e');im.save(R/'thumbnail.jpg',quality=95)
