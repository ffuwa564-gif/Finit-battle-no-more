# ハクスラ周回と、引けた仲間から考える塔攻略

新規データの正規コマンドによる自動操作を、実ゲームUIで再生・編集。通常探索はhunt形式。全ての入力・replayをcommands.jsonlへ記録し、verify.tsで最終セーブとの完全一致を確認する。

準備はprepare.ts → 出力をfull-playthrough-before-postlude.jsonへ保存 → postlude.ts → farm-switch.ts → verify.ts。特定SSR４人の取得を終了条件にせず、同じガチャを引き、所持キャラのスキルと拾った石から編成する。通常探索158回／塔58回／イベント260回／祈願85回。最短攻略ではない。

episode.py → make-voices.py → capture.ts → capture-extra.ts → make-sfx.ts → render.py → finish-cfr-frames.py → audit.py → check-playback.ts → 完成フレーム目視 → package.py。Vite4173番、artifacts/hunt-tower-diaryのviewer/revealとplaythrough.jsonを使う。

Part2承認済みピンク配色・表情素材。字幕最大２行。頭・耳・衣装はcontain。VOICEVOX0.17.1／モデル0.17.0は既存wolf-rta-v112のローカル環境を参照し、配布しない。音楽の独立原本も制作ZIPへ入れない。

全音源48kHz、全フレーム30fps。通常のフィルタ合成の末尾不足を避け、9372フレームを整数インデックスで合成してから音声mux。音声元はFLAC。AACは最終１回のみ。必殺の着弾音は編集倍率も適用。レア回収の操作音は実際に必要だったタップ数から配置。

完成ファイルそのもので70台詞、戦闘の開始・中間・終了、UI回収音を照合。80ms以内と十分な相関が必要。全編20ms窓で欠落・残差、全編デコード、Chromium/WebKitの３点シークも別に検査する。SHA256一致後に公開し、公開ファイルを読み戻して同じハッシュか確認する。

収録用のengine-hunt-rare.patchは、通常hunt出発時に旧Waveの稀出現抽選が先に走り存在しない敵を参照する不具合を修正する。ゲームの能力値・倍率・戦利品の抽選結果を調整したものではない。公開版へのマージ・配信は別工程。
