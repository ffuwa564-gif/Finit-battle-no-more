from pathlib import Path
import json,hashlib,shutil,zipfile,csv
R=Path('artifacts/hunt-tower-diary');D=R/'delivery';D.mkdir(exist_ok=True);T=json.loads((R/'timeline.json').read_text());M=R/'stillveil-hunt-tower.mp4';sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest();h=sha(M)
for f in ['sync-audit.json','playback-audit.json','visual-review.json']:
 a=json.loads((R/f).read_text());assert a['pass']and a['sha256']==h,f
assert json.loads((R/'playthrough-verification.json').read_text())['pass']
credits='''音声：VOICEVOX:ずんだもん（ノーマル）／VOICEVOX:四国めたん（ノーマル）
https://voicevox.hiroshiba.jp/
キャラクター：東北ずん子・ずんだもんプロジェクト
https://zunko.jp/
実況イラスト：承認済みSTILLVEIL攻略日記Part2のオリジナル表情素材を再利用。
音楽：甘茶の音楽工房（作曲：甘茶）「フィヨルドの澄んだ風」
https://amachamusic.chagasi.com/music_fjordnosundakaze.html
楽曲の単体再配布・Content ID登録はしないでください。
ゲーム：STILLVEIL ― 静謐の残響
効果音：ゲームの実装内PCM合成を、実際の戦闘イベント表示フレームに合わせて再構成。
'''
def clock(t):return f'{int(t)//60:02}:{int(t)%60:02}'
chapters='\n'.join(clock(s['start'])+' '+s['title']for s in T['scenes']if s['id']in ['opening','hunt','loot','polish','izanami','joins','build','tower','finish','farm','rank','tools'])+'\n'
description="""【STILLVEIL】引けた仲間と拾った石で、塔１層を攻略するのだ【ずんだもん・四国めたん】

ニューゲームから通常ダンジョンでハクスラ周回。レア回収、研磨、ガチャで来た仲間の作戦会議を経て、白亜の塔１層へ。
特定の４人を待つのではなく、その時の手持ちから組み直していきます。

ゲーム：https://fluffy3546.itch.io/stillveil

■ 収録条件
ver1.28.0＋稀な敵の出発停止の局所修正。初期データと既定乱数から正規コマンドだけで進行した自動操作記録を、実ゲームUIで再生・編集しています。リアルタイムの手操作録画とは区別しています。能力・素材・仲間・石の抽選結果・踏破フラグの注入や、ガチャ結果のやり直しはありません。
通常探索は現行の最大100手の連続討伐形式。イベントはWave制、塔は固定戦闘です。収集途中と再挑戦は省略、戦闘は抜粋・編集３倍、操作は等速、研磨は編集３倍。説明停止も表示しています。
同じゴス☆イザナミコレクションを85回。通常探索158回・イベント260回・塔58回。最短攻略や必須編成の推奨ではありません。原石の具体的なTierは研磨まで伏せ、低い結果も映しています。

■ 今回の結果
初期４人で聖堂32体A。イザナミ加入後も32体A。
塔用：フレイヤ／イザナミ／弁財天／Rアテナ。38ラウンド、３人生存、薬５個使用で１層突破。妖精・花も使用しています。
その編成で戻った聖堂は28体A。初期ノエルを先頭に戻し、イザナミ・フレイヤ・ヘカテと組み、装備・指示も変えると今回は55体S、原石11個。複数条件と乱数が違う各１回の例で、特定キャラの最適性や毎回の収穫を保証する比較ではありません。
余剰素材から研磨布も製作。道具は磨く手間を減らし、石の中身を変えません。

■ 音声と映像
収録負荷による音切れを避け、効果音は同じゲームのPCM合成と音程配列から、イベントと実際のUIタップのフレームへ配置しました。48kHz共通時刻でミックスし、AACは最終１回。完成MP4の全70台詞・主要戦闘・UI回収音の同期、波形欠落、9372フレーム全編、両ブラウザの再生を検査しています。
公開ゲームのマージ・デプロイ、YouTube投稿はこの制作では行っていません。

■ チャプター
"""+chapters+'\n■ クレジット\n'+credits
(R/'credits.txt').write_text(credits);(R/'chapters.txt').write_text(chapters);(R/'youtube-description.txt').write_text(description)
with (R/'storyboard.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['scene','start','title','source','clip','dialogue'])
 for s in T['scenes']:w.writerow([s['id'],s['start'],s['title'],s['source'],s['clip'],' / '.join(v['text']for v in T['voices']if v['id']in s['lines'])])
qa={'pass':True,'sha256':h,'duration':T['duration'],'resolution':'1920x1080','voicevoxSpeakers':['ずんだもん','四国めたん'],'evidence':['sync-audit.json','playback-audit.json','visual-review.json','playthrough-verification.json'],'audio':'48kHz common sample clock, offline game PCM, smooth fades/ducking, single final AAC encode. Entire encoded waveform checked against lossless master.'};(R/'final-qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2))
files=['stillveil-hunt-tower.mp4','stillveil-hunt-tower.srt','thumbnail.jpg','script.md','credits.txt','chapters.txt','youtube-description.txt','final-qa.json','sync-audit.json','playback-audit.json','visual-review.json','playthrough-verification.json','contact-sheet.jpg','storyboard.csv']
for name in files:shutil.copyfile(R/name,D/name)
with zipfile.ZipFile(D/'Production-Inputs.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in Path('scripts/hunt-tower-diary').glob('*'):
  if p.is_file():z.write(p,str(p))
 for name in ['playthrough.json','commands.jsonl','content.json','script.json','capture.json','capture-with-audio.json','extra-shots.json','timeline.json','input-hashes.json','final-render.json','viewer.html','viewer.tsx','reveal.html','reveal.tsx','playthrough-verification.json','full-playthrough.json','full-playthrough-before-postlude.json','engine-hunt-rare.patch','typecheck-pass.log','rare-fix-test.log','related-tests.log']:
  z.write(R/name,str(R/name))
 for folder in ['assets','voices','shots','clips']:
  for p in (R/folder).glob('*'):
   if folder=='assets' and p.name not in ['z-happy-avatar.png','z-panic-avatar.png','m-happy-avatar.png','m-deadpan-avatar.png']:continue
   if p.is_file()and p.suffix in ['.png','.wav','.json','.mp4']:z.write(p,str(p))
 z.write('docs/media/hunt-tower-diary/episode-brief.md')
with zipfile.ZipFile(D/'YouTube-Package.zip','w',zipfile.ZIP_DEFLATED)as z:
 for name in files:z.write(D/name,name)
manifest={p.name:{'sha256':sha(p),'bytes':p.stat().st_size}for p in D.iterdir()if p.is_file()and p.name!='SHA256.json'};(D/'SHA256.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({n:x['bytes']for n,x in manifest.items()},indent=2))
