"""Verify that capture-clock correction preserves pitch and transient time."""
from pathlib import Path
import numpy as np,subprocess,json
SR=48000;rows=[]
for tempo in [.84,.98,1.10]:
 x=np.sin(np.arange(SR*3)*2*np.pi*440/SR)*.1
 for t in [.5,1.5,2.5]:x[round(t*SR):round(t*SR)+20]+=.7
 data=subprocess.run(['ffmpeg','-v','error','-f','f32le','-ar',str(SR),'-ac','1','-i','pipe:0','-af',f'rubberband=tempo={tempo}:pitch=1:pitchq=quality:window=long:smoothing=on','-f','f32le','pipe:1'],input=x.astype('<f4').tobytes(),stdout=subprocess.PIPE,check=True).stdout
 y=np.frombuffer(data,'<f4');errors=[]
 for t in [.5,1.5,2.5]:
  center=round(t/tempo*SR);a=max(0,center-4000);b=min(len(y),center+4000);peak=a+int(np.argmax(abs(y[a:b])));errors.append((peak/SR-t/tempo)*1000)
 start=round(.8/tempo*SR);window=y[start:start+24000];freq=np.fft.rfftfreq(len(window),1/SR)[int(np.argmax(abs(np.fft.rfft(window*np.hanning(len(window))))))]
 rows.append({'tempo':tempo,'frequencyHz':float(freq),'expectedHz':440,'transientErrorsMs':errors,'pass':bool(abs(freq-440)<3 and max(abs(v)for v in errors)<80)})
report={'method':'rubberband tempo adjustment with pitch=1','sampleRate':SR,'pass':all(x['pass']for x in rows),'checks':rows};Path('artifacts/auto-harvest-diary/clock-stretch-test.json').write_text(json.dumps(report,indent=2));print(report)
assert report['pass']
