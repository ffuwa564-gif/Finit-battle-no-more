"""Write reactions tied to observed actions/results, not invented drops."""
from pathlib import Path
import json
R=Path('artifacts/auto-harvest-diary');C=json.loads((R/'raw/capture.json').read_text());E=C['events'];out=[]
def add(event,text,offset=0,mood='happy'):
 kind=event['type'];nth=[x for x in E if x['type']==kind].index(event)
 out.append({'id':f'z{len(out)+1:02}','text':text,'voice':text,'mood':mood,'selector':{'type':kind,'nth':nth},'offset':offset})
def first(kind):return next(e for e in E if e['type']==kind)
add(first('start'),'今日は、オート戦闘でのんびり素材集めをするのだ。',2)
add(first('home'),'前回の四人で、忘却の聖堂へもう一周。勝てる場所なら、余裕なのだ。',.2)
add(first('prepare'),'石と鉱石を持ち帰りたいのだ。ついでに原石も、ちょっとだけ。',.6)
add(first('battle-start'),'ぽちっとオート。これで、ぼくは拾う係なのだ。',.2)
cards=[e for e in E if e['type']=='cards']
texts={
 'touch':['三択なのだ。まずは指先。連打を少なくする作戦でいくのだ。','また指先がある！ 楽をするための投資なのだ。','三枚とも指先なのだ。キャラより、ぼくの指が育っているのだ。'],
 'abundance':['素材が増える方！ 一回の探索で、いっぱい持ち帰りたいのだ。','さらに素材を増やすのだ。欲張りセット、完成なのだ。'],
 'linger':['残る時間を延ばすのだ。これで、少しは落ち着いて拾えるはず。'],
 'mercy':['回復しながら、ほかの落とし物も拾うのだ。働き者の波紋なのだ。'],
 'focus':['援護を強くするのだ。拾い物で戦闘まで楽になるのだ。']}
seen={}
for e in cards:
 k=e['pick'];n=seen.get(k,0);seen[k]=n+1;add(e,texts[k][min(n,len(texts[k])-1)],.1)
taps=[e for e in E if e['type']=='pickup-tap']
if taps:add(taps[0],'あっ、落ちた。こっちを拾って、次はあっちなのだ。',.1)
states=[e for e in E if e['type']=='harvest-state']
def state(pred):return next((e for e in states if pred(e)),None)
e=state(lambda x:x.get('collected',0)>=2)
if e:add(e,'石も拾えたのだ。まだまだ、このくらい余裕なのだ。',1)
e=state(lambda x:x.get('gems',0)>=1)
if e:add(e,'原石も取れた！ 素材だけのつもりが、ちょっと欲が出てきたのだ。',.2)
e=state(lambda x:x.get('gems',0)>=2)
# This often coincides with the second card. Let the card reaction take priority.
if e and not any(abs(e['epoch']-q['epoch'])<7000 for q in cards):add(e,'原石、もう一つなのだ。中身は帰ってからのお楽しみ。',1)
e=state(lambda x:x.get('missed',0)>=3)
if e:add(e,'あれ？ 三つも逃してる。原石ばかり見ていたのだ。',.2,'panic')
e=state(lambda x:x.get('collected',0)>=10)
if e:add(e,'十個回収！ もう、ぼくが戦っているのか、拾っているのかわからないのだ。',.3)
# Reserve space around the actual choices and milestone reactions.
used=[e['epoch']/1000+v['offset'] for v in out for e in [next(x for x in E if x['type']==v['selector']['type'] and [y for y in E if y['type']==x['type']].index(x)==v['selector']['nth'])]]
rounds=[e for e in E if e['type']=='battle-round']
filler=[
 'みんな、戦闘は任せたのだ。ぼくは現場の回収係なのだ。',
 '回復も落ちているのだ。拾い物だけで、けっこう助かっているのだ。',
 '画面の左も右も気になるのだ。目がもう一組ほしいのだ。',
 '素材があると、あと一周だけって言いたくなるのだ。',
 'こういうときに限って、反対側にも落ちるのだ。',
 '拾うのに夢中で、敵の顔をぜんぜん見ていなかったのだ。',
 '戦闘はオートなのに、ぼくの指は休めないのだ。',
]
fi=0
for e in rounds:
 t=e['epoch']/1000+1.2
 if fi<len(filler) and all(abs(t-u)>9 for u in used):add(e,filler[fi],1.2);used.append(t);fi+=1
end=first('reward') if any(e['type']=='reward'for e in E)else first('failed')
if end['type']=='reward':
 h=end.get('harvest',{});add(end,'よし、倒したのだ！ でも、まだ安心してはいけないのだ。',.6)
 add(end,f"拾えたのは{h.get('collected',0)}個。逃したのは{h.get('missed',0)}個。全部は取れなかったのだ。",6.5)
 add(first('claimed'),'獲得を確定。これでようやく、ぼくのものなのだ。',.3)
else:add(end,'あっ、負けた……。欲張っても、帰れなければ持ち帰れないのだ。',.5,'panic')
add(first('outro'),'のんびりする予定が、ずっと拾っていたのだ。オートとは何だったのだ。',.5,'panic')
add(first('outro'),'次は素材を増やす組み合わせも試したいのだ。あと一周だけ。ほんとに、一周だけなのだ。',10)
# Drop filler if its audio would likely collide with an actual result/choice.
(R/'comments.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('Script lines:',len(out))
