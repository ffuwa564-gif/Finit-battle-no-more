from pathlib import Path
import json,hashlib,shutil,zipfile,csv
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path('artifacts/auto-harvest-diary');D=R/'delivery';D.mkdir(exist_ok=True)
A=json.loads((R/'sync-audit.json').read_text());B=json.loads((R/'playback-audit.json').read_text());T=json.loads((R/'edit-manifest.json').read_text());C=json.loads((R/'raw/capture.json').read_text());movie=R/'stillveil-auto-harvest.mp4'
def sha(p):return hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
assert A['pass']and B['pass']and A['sha256']==B['sha256']==sha(movie)
assert json.loads((R/'clock-stretch-test.json').read_text())['pass']
review=json.loads((R/'visual-review.json').read_text());assert review['pass']and review['sha256']==sha(movie)
def clock(t):return f'{int(t)//60:02}:{int(t)%60:02}'
def eventtime(e):
 t=e['epoch']/1000-C['firstFrameEpoch'];anchors=T['eventClockAnchors'];t+=float(np.interp(t,[a['real']for a in anchors],[a['video']-a['real']for a in anchors]));f=t*30
 p=next((p for p in T['pieces']if p['sourceStartFrame']<=f<p['sourceEndFrame']),T['pieces'][-1]);return p['start']+(f-p['sourceStartFrame'])/30/p['rate']
chapters=[('00:00','オートなのに手が足りないのだ')]
for kind,title in [('prepare','忘却の聖堂で素材集め'),('auto-on','戦闘はオート！'),('card-picked','カードを選んで、回収強化'),('reward','今回の収穫'),('outro','欲張り周回の感想')]:
 matches=[e for e in C['events']if e['type']==kind]
 for n,e in enumerate(matches):
  if kind=='card-picked' and n:continue
  chapters.append((clock(eventtime(e)),title))
chapters.sort(key=lambda p:p[0]);chapter_text='\n'.join(t+' '+label for t,label in chapters)+'\n'
credits='''音声：VOICEVOX:ずんだもん（ノーマル）
https://voicevox.hiroshiba.jp/
キャラクター：ずんだもん（東北ずん子・ずんだもんプロジェクト）
https://zunko.jp/
実況用イラスト：承認済みSTILLVEIL攻略日記Part2の表情素材。
音楽：甘茶の音楽工房（作曲：甘茶）
https://amachamusic.chagasi.com/
ゲーム内使用曲：「悲しみの曖昧な対象」「フィヨルドの澄んだ風」「騎兵戦」「楽しい冒険」
ゲームのBGM・効果音をプレイ画面と同時に収録しています。
楽曲そのものの再配布・Content ID登録はしないでください。
ゲーム・収録・編集：STILLVEIL制作プロジェクト
'''
title='【STILLVEIL】オート戦闘なのに手が足りないのだ【ずんだもん実況】'
description=f'''{title}

戦闘はお任せ、落とし物は自分で拾う。
忘却の聖堂で、カードと素材に振り回されるずんだもん。
前回の勲章日記のセーブを引き継ぎ、実際の探索と収穫を実況します。

対象版：ver{T['version']} / PR #171 未マージの試作版（df00a04）。公開版にはまだ存在しない挙動が含まれます。
遊ぶ：https://finit-battle-no-more.luxpedia.workers.dev/
itch.io：https://fluffy3546.itch.io/stillveil

通常UIへの自動入力で実プレイを収録し、ずんだもんの実況を後付けしています。
能力値・所持品・進行・ゲーム内の時計は変更していません。妖精チュートリアル案内は辞退。
収録の途中にカットはありません。移動の待ち時間だけ2倍速、会話・戦闘は等速です。
RTAではありません。探索と報酬画面のネタバレがあります。
生成AIを制作の一部に使用しています。実際の獲得結果は保存データと記録に基づきます。

【チャプター】
{chapter_text}
【クレジット】
{credits}
#ずんだもん #STILLVEIL #ゲーム実況 #ゲーム実況
'''
(D/'youtube-description.txt').write_text(description);(D/'chapters.txt').write_text(chapter_text);(D/'credits.txt').write_text(credits)
(D/'script.md').write_text('# '+title+'\n\n'+'\n\n'.join(f"{clock(v['start'])}　ずんだもん：{v['text']}"for v in T['voices']))
(D/'README.txt').write_text(f'{title}\n{clock(T["duration"])} / 1920×1080 / H.264 + AAC / 48kHz\n字幕は焼き込み済み。SRTも同梱しています。\nYouTubeへ投稿する際は同梱のクレジットを掲載してください。\nゲーム本体の変更・デプロイ、YouTube投稿は行っていません。\n')
for name in ['stillveil-auto-harvest.mp4','stillveil-auto-harvest.srt','sync-audit.json','playback-audit.json','contact-sheet.jpg','visual-review.json','clock-stretch-test.json','restoration-audit.json']:
 shutil.copyfile(R/name,D/name)
shutil.copyfile(R/'raw/initial-save.json',D/'initial-save.json');(D/'final-save.json').write_text(json.dumps(C['finalSave'],ensure_ascii=False,indent=2))
conditions={'version':T['version'],'commit':T['sourceCommit'],'freshBrowser':True,'continuedFrom':'medal-diary-01 genuine final save','sourceIsUnreleasedPR171':True,'tutorial':'declined','uiAutomation':True,'statsInventoryProgressionClockEdited':False,'initialSave':'initial-save.json','finalSave':'final-save.json','completedDungeons':C['finalSave']['completedDungeonIds'],'earnedMedals':C['finalSave'].get('medals',{}).get('earned',[]),'rawRecording':'artifacts/auto-harvest-diary/raw/video.mp4','rawPcm':'retained locally; not publicly distributed as standalone music','youtubeUploaded':False}
(D/'starting-conditions.json').write_text(json.dumps(conditions,ensure_ascii=False,indent=2))
with open(D/'storyboard.csv','w',newline='')as f:
 w=csv.writer(f,lineterminator='\n');w.writerow(['id','start','end','speaker','text','source_event','source_epoch','expression'])
 for v in T['voices']:w.writerow([v['id'],v['start'],v['end'],'ずんだもん',v['text'],json.dumps(v['sourceEvent'],ensure_ascii=False),v['sourceEvent']['epoch'],v['mood']])
shutil.copyfile(D/'storyboard.csv','docs/media/auto-harvest-diary/storyboard.csv')
# Thumbnail uses only frames/artwork from this actual episode.
thumb=Image.new('RGB',(1280,720),'#f9e8ef');draw=ImageDraw.Draw(thumb)
for x in range(-720,1280,32):draw.line((x,0,x+720,720),fill='#f4dfe9',width=7)
draw.rounded_rectangle((16,16,1264,704),radius=28,fill='#fffaf4',outline='#dca9c0',width=4)
font=lambda n:ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',n)
draw.text((45,45),'ずんだもんの',font=font(40),fill='#642c4e');draw.text((45,100),'欲張り周回',font=font(57),fill='#642c4e')
draw.text((360,290),'戦闘オートで',font=font(56),fill='#b84b82');draw.text((360,380),'手が足りない！',font=font(56),fill='#b84b82');draw.text((365,565),'STILLVEIL',font=font(39),fill='#642c4e')
art=Image.open(R/'assets/z-happy-avatar.png').convert('RGBA');thumb.paste(art,(30,250),art)
frame=Image.open(next((R/'reviews').glob('*silent-cathedral.jpg'))).convert('RGB');game=frame.crop((310,66,796,930)).resize((320,569),Image.Resampling.LANCZOS);thumb.paste(game,(925,74));thumb.save(D/'thumbnail.jpg',quality=95)
# New browser tests and render verification are tied to the same delivered bytes.
qa={'sha256':sha(movie),'pass':True,'sourceCommit':T['sourceCommit'],'version':T['version'],'duration':T['duration'],'medals':conditions['earnedMedals'],'toleranceMs':80,'voiceChecks':len(A['voices']),'gameAudioChecks':len(A['gameAudio']),'frameSequenceChecks':len(A['gameFootage'])+len(A['originalFootage']),'fullDecode':A['fullDecode'],'browsers':B['results'],'manualReview':review,'pitchPreservation':json.loads((R/'clock-stretch-test.json').read_text())}
(D/'final-qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2))
# Reproducible evidence; runtime/models/music-only files are deliberately excluded.
source=[*Path('scripts/auto-harvest-diary').glob('*'),*Path('docs/media/auto-harvest-diary').glob('*'),R/'raw/video.mp4',R/'raw/capture.json',R/'raw/initial-save.json',R/'capture-sync.json',R/'timeline.json',R/'edit-manifest.json',R/'comments.json',R/'initial-save.json',R/'restoration-audit.json',R/'render-command.json',R/'subtitles.ass',R/'serve.mjs',*list((R/'voices').glob('*.wav')),*list((R/'assets').glob('*-avatar.png'))]
source=[p for p in source if p.is_file()]
inputs={str(p):{'sha256':sha(p),'bytes':p.stat().st_size}for p in source};inputs[str(R/'raw/audio.f32')]={'sha256':sha(R/'raw/audio.f32'),'bytes':(R/'raw/audio.f32').stat().st_size,'publication':'local-only; diagnostic PCM includes game music'};(R/'input-hashes.json').write_text(json.dumps(inputs,ensure_ascii=False,indent=2))
with zipfile.ZipFile(D/'Production-Inputs.zip','w',zipfile.ZIP_DEFLATED,compresslevel=1)as z:
 for p in source+[R/'input-hashes.json']:z.write(p,str(p))
manifest={p.name:{'sha256':sha(p),'bytes':p.stat().st_size}for p in D.iterdir()if p.is_file()and p.name not in ['SHA256.json','YouTube-Package.zip']};(D/'SHA256.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(D/'YouTube-Package.zip','w',zipfile.ZIP_DEFLATED,compresslevel=1)as z:
 for p in sorted(D.iterdir()):
  if p.is_file()and p.suffix!='.zip':z.write(p,p.name)
print('DELIVERED',clock(T['duration']),sha(movie))
