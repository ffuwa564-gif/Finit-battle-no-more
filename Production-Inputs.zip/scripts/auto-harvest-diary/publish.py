from pathlib import Path
import subprocess,json,hashlib,shutil
R=Path('artifacts/auto-harvest-diary');D=R/'delivery';P=Path('/workspace/stillveil-auto-harvest-media');branch='media/auto-harvest-diary-20261107';repo='ffuwa564-gif/Finit-battle-no-more'
def sha(p):return hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
qa=json.loads((D/'final-qa.json').read_text());assert qa['pass']and sha(D/'stillveil-auto-harvest.mp4')==qa['sha256']
for k in ['sync-audit.json','playback-audit.json','visual-review.json']:
 a=json.loads((D/k).read_text());assert a['pass']and a['sha256']==qa['sha256']
manifest=json.loads((D/'SHA256.json').read_text())
for name,item in manifest.items():assert sha(D/name)==item['sha256'],name
for p in D.iterdir():
 if p.is_file():
  assert p.stat().st_size<95*1024*1024,('File exceeds media-branch budget',p.name)
  shutil.copyfile(p,P/p.name)
raw=f'https://raw.githubusercontent.com/{repo}/{branch}/'
(P/'README.md').write_text(f'''# 【STILLVEIL】オート戦闘なのに手が足りないのだ

ずんだもんの欲張り周回。1080p / 字幕入り。

[▶ 動画を開く・保存する]({raw}stillveil-auto-harvest.mp4)

[投稿用セットをダウンロード]({raw}YouTube-Package.zip) — MP4、字幕、サムネイル、台本、説明文、チャプター、クレジット、検証記録。

[制作記録]({raw}Production-Inputs.zip) / [検証結果](final-qa.json)

![サムネイル](thumbnail.jpg)

前回の勲章日記の実セーブを引き継ぎ、通常UIを自動操作して収録。ずんだもん実況を後付けしています。移動待ちのみ倍速、戦闘は等速、カットなし。能力値・所持品・進行・ゲーム内時計の変更なし。

PR #171（df00a04）の未公開試作版を使用。公開版にはまだ存在しない挙動を含みます。ゲームのマージ・デプロイは行っていません。

VOICEVOX:ずんだもん / 東北ずん子・ずんだもんプロジェクト / 音楽：甘茶の音楽工房。投稿時は [説明文](youtube-description.txt) のクレジットを掲載してください。

完成MP4 SHA-256：`{qa['sha256']}`

ゲーム本体の更新・YouTubeへの投稿は行っていません。旧作を上書きしない独立したメディアブランチです。
''')
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config',key],text=True).strip();subprocess.run(['git','-C',str(P),'config',key,value],check=True)
subprocess.run(['git','-C',str(P),'add','.'],check=True)
subprocess.run(['git','-C',str(P),'commit','-m','media: publish Zundamon auto harvest gameplay'],check=True)
subprocess.run(['git','-C',str(P),'push','origin',f'HEAD:refs/heads/{branch}'],check=True)
commit=subprocess.check_output(['git','-C',str(P),'rev-parse','HEAD'],text=True).strip()
urls={name:f'https://raw.githubusercontent.com/{repo}/{commit}/{name}'for name in ['stillveil-auto-harvest.mp4','YouTube-Package.zip','thumbnail.jpg','Production-Inputs.zip','final-qa.json']}
report={'repository':repo,'branch':branch,'commit':commit,'sha256':qa['sha256'],'urls':urls,'verification':'pending public read-back'};(R/'publication.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
