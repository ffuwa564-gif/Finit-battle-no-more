from pathlib import Path
import json,subprocess,wave,math,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path('artifacts/auto-harvest-diary');T=json.loads((R/'timeline.json').read_text());C=json.loads((R/'raw/capture.json').read_text());comments=json.loads((R/'comments.json').read_text());FPS=30;SR=48000;SPF=1600
def mapped(raw):
 f=max(0,min(T['sourceFrames'],raw*FPS))
 p=next((p for p in T['pieces']if p['sourceStartFrame']<=f<p['sourceEndFrame']),T['pieces'][-1])
 return p['start']+(f-p['sourceStartFrame'])/p['rate']/FPS
def raw_event_time(epoch):
 t=epoch/1000-C['firstFrameEpoch'];anchors=T['eventClockAnchors']
 return t+float(np.interp(t,[a['real']for a in anchors],[a['video']-a['real']for a in anchors]))
def eventtime(e):return mapped(raw_event_time(e['epoch']))
voices=[];unused=[]
for line in comments:
 selector=line['selector'];matches=[e for e in C['events']if all(str(e.get(k))==str(v)for k,v in selector.items()if k!='nth')]
 if len(matches)<=selector['nth']:unused.append(line['id']);continue
 e=matches[selector['nth']];desired=eventtime(e)+line['offset'];p=R/'voices'/f"{line['id']}.wav"
 with wave.open(str(p))as f:samples=f.getnframes();assert f.getframerate()==SR
 voices.append({**line,'file':str(p),'sourceEvent':e,'desired':desired,'samples':samples,'duration':samples/SR})
voices.sort(key=lambda v:v['desired']);last=0
for v in voices:
 v['frame']=math.ceil(max(v['desired'],last+.18)*FPS);v['start']=v['frame']/FPS;v['end']=v['start']+v['duration'];v['delay']=v['start']-v['desired'];last=v['end']
 if v['delay']>3:raise ValueError('Reaction is too late: '+v['id'])
 if v['end']>T['duration']-.2:raise ValueError('Narration exceeds continuous recording')
def decode(p):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-vn','-ac','2','-ar',str(SR),'-f','f32le','-']),'<f4').reshape(-1,2).copy()
N=T['frames']*SPF;game=decode(R/'gameplay-uncut.mkv');game=np.pad(game,((0,max(0,N-len(game))),(0,0)))[:N];speech=np.zeros_like(game);duck=np.ones(N,np.float32)
for v in voices:
 x=decode(v['file']);a=v['frame']*SPF;speech[a:a+len(x)]+=x*.94
 before=min(a,960);end=min(N,a+len(x));after=min(N-end,3840)
 if before:duck[a-before:a]=np.minimum(duck[a-before:a],np.linspace(1,.42,before))
 duck[a:end]=np.minimum(duck[a:end],.42)
 if after:duck[end:end+after]=np.minimum(duck[end:end+after],np.linspace(.42,1,after))
game*=duck[:,None]*.8;peak=float(np.max(abs(game+speech)));master=min(1,.94/max(.001,peak));game*=master;speech*=master
def wav(name,x):
 with wave.open(str(R/name),'wb')as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(SR);f.writeframes((np.clip(x,-1,1)*32767).astype('<i2').tobytes())
wav('soundtrack.wav',game+speech);wav('background-without-voice.wav',game);wav('background-without-game.wav',speech)
gaps=[];cursor=0
for v in voices:
 if v['start']-cursor>12:gaps.append({'start':cursor,'end':v['start'],'duration':v['start']-cursor})
 cursor=v['end']
if T['duration']-cursor>12:gaps.append({'start':cursor,'end':T['duration'],'duration':T['duration']-cursor})
print('Narration gaps >12s:',gaps,flush=True)
report={**T,'narrationGaps':gaps,'voices':voices,'unusedComments':unused,'masterGain':master,'gameGain':.8,'voiceGain':.94,'gameRect':[310,66,486,864],'avatarRect':[0,470,320,440]}
(R/'edit-manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
fontfile='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
def font(n):return ImageFont.truetype(fontfile,n)
im=Image.new('RGB',(1920,1080),'#f9e8ef');d=ImageDraw.Draw(im)
for x in range(-1080,1920,32):d.line((x,0,x+1080,1080),fill='#f4dfe9',width=8)
d.rounded_rectangle((296,60,1885,930),radius=24,fill='#fffaf4',outline='#dca9c0',width=3)
d.rectangle((306,62,800,934),fill='#642c4e')
d.text((28,95),'ずんだもんの',font=font(29),fill='#642c4e');d.text((28,145),'欲張り周回',font=font(34),fill='#b84b82');d.text((28,193),'オート編',font=font(34),fill='#642c4e')
d.text((850,95),'STILLVEIL',font=font(60),fill='#642c4e');d.text((853,185),'オートなのに、手が足りない！',font=font(40),fill='#b84b82')
for y,h in [(275,175),(480,130),(640,210)]:d.rounded_rectangle((835,y,1850,y+h),radius=24,fill='#f9e8ef',outline='#dca9c0',width=2)
d.text((870,294),'いまの目標',font=font(25),fill='#a06080');d.text((870,490),'拾えたもの',font=font(25),fill='#a06080');d.text((870,655),'ずんだもんの作戦',font=font(25),fill='#a06080')
d.text((850,877),f"ver{T['version']} / 前回データ継続 / PR #171 試作版",font=font(22),fill='#8f7282')
d.text((22,916),'VOICEVOX:ずんだもん',font=font(19),fill='#3e7543')
# Transparent avatar layers are composited after gameplay; no patch may cover the game.
d.rounded_rectangle((20,947,1900,1070),radius=20,fill='#fffaf4',outline='#dca9c0',width=3)
im.save(R/'background.png')
def at(t):
 n=round(max(0,t)*100);return f'{n//360000}:{n//6000%60:02}:{n//100%60:02}.{n%100:02}'
ass=['''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 2
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Caption,Noto Sans CJK JP,48,&H0043753E,&H0043753E,&H00FFF8F2,&H00FFF8F2,1,0,0,0,100,100,0,0,1,1,0,2,45,45,22,1
Style: Heading,Noto Sans CJK JP,38,&H004E2C64,&H004E2C64,&H00F9E8EF,&H00F9E8EF,1,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1
Style: Note,Noto Sans CJK JP,32,&H004E2C64,&H004E2C64,&H00F9E8EF,&H00F9E8EF,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1
Style: Count,Noto Sans CJK JP,56,&H00824BB8,&H00824BB8,&H00F9E8EF,&H00F9E8EF,1,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
''']
def row(a,b,style,text,pos=None):
 tag=f'{{\\pos({pos[0]},{pos[1]})}}'if pos else ''
 ass.append(f'Dialogue: 0,{at(a)},{at(b)},{style},,0,0,0,,{tag}{text}\n')
def wrap(s,size,width):
 lines=[];part=''
 for c in s:
  if font(size).getlength(part+c)>width and part:lines.append(part);part=c
  else:part+=c
 lines.append(part);return lines
for v in voices:
 rows=wrap(v['text'],48,1800)
 if len(rows)>2:raise ValueError('Caption overflows '+v['id'])
 row(v['start'],v['end'],'Caption','\\N'.join(rows))
labels={
 'start':('戦闘はオートに任せたい','でも、落とし物は自分で拾う。'),
 'home':('今日は素材を持ち帰ろう','前回の四人で、忘却の聖堂へ。'),
 'map':('忘却の聖堂へ、もう一度','勝つだけでは終われない。'),
 'prepare':('今回は、欲張ってみます','オート＋ドロップ回収に挑戦。'),
 'auto-on':('戦闘はお任せ！','空いた手で、素材を拾おう。'),
 'cards':('三枚から、一枚を選ぶ','拾いやすさ？ それとも収穫量？'),
 'card-picked':('選んだ宝石を枠にセット','組み合わせは、この探索の間だけ。'),
 'reward':('倒した！ あとは持ち帰ろう','最後の確認で、報酬が確定。'),
 'failed':('探索失敗……','この回の収穫は持ち帰れない。'),
 'claimed':('無事に持ち帰れたのだ','拾った分だけ、カバンが重い。'),
 'outro':('オートとは何だったのか','また一周、したくなる？')}
changes=[];countchanges=[(0,0,0)]
for e in C['events']:
 if e['type'] in labels:changes.append((eventtime(e),labels[e['type']]))
 if e['type']=='harvest-state':countchanges.append((eventtime(e),e.get('collected',0),e.get('missed',0)))
for i,(a,(title,note))in enumerate(changes):
 b=changes[i+1][0]if i+1<len(changes)else T['duration'];row(a,b,'Heading',title,(870,350));row(a,b,'Note',note,(870,710))
for i,(a,n,m)in enumerate(countchanges):
 b=countchanges[i+1][0]if i+1<len(countchanges)else T['duration']
 row(a,b,'Count',f'{n:02} 回収 / {m:02} 逃した',(900,526))
socket_changes=[(0,[])]
for e in C['events']:
 if e['type']=='harvest-state' and e.get('sockets',[])!=socket_changes[-1][1]:socket_changes.append((eventtime(e),e['sockets']))
for i,(a,slots)in enumerate(socket_changes):
 b=socket_changes[i+1][0]if i+1<len(socket_changes)else T['duration']
 text='◆ 指先 ×'+str(len(slots)) if slots else '◇ ◇ ◇   宝石の枠は、まだ空っぽ'
 row(a,b,'Note',text,(870,803))
for p in T['pieces']:
 row(p['start'],p['start']+p['duration'],'Note','移動待ち ×2'if p['rate']==2 else 'PLAY ×1',(1640,877))
(R/'subtitles.ass').write_text(''.join(ass))
def srt(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(R/'stillveil-auto-harvest.srt').write_text('\n\n'.join(f"{i+1}\n{srt(v['start'])} --> {srt(v['end'])}\n{v['text']}"for i,v in enumerate(voices))+'\n')
panic_enable='+'.join(f"between(t,{v['start']:.3f},{v['end']:.3f})"for v in voices if v['mood']=='panic')or'0'
filters=f"[1:v]scale=486:864,settb=1/30,setpts=N[game];[0:v][game]overlay=310:66:shortest=1[base];[base][2:v]overlay=0:470:enable='not({panic_enable})'[happy];[happy][3:v]overlay=0:470:enable='{panic_enable}'[art];[art]ass={R/'subtitles.ass'}[v]"
subprocess.run(['ffmpeg','-v','error','-y','-loop','1','-framerate','30','-i',str(R/'background.png'),'-t','1','-c:v','libx264','-threads','2','-preset','ultrafast','-qp','0','-pix_fmt','yuv420p',str(R/'background-loop.mp4')],check=True)
command=['ffmpeg','-v','error','-y','-filter_complex_threads','1','-stream_loop','-1','-i',str(R/'background-loop.mp4'),'-i',str(R/'gameplay-uncut.mkv'),'-loop','1','-framerate','30','-i',str(R/'assets/z-happy-avatar.png'),'-loop','1','-framerate','30','-i',str(R/'assets/z-panic-avatar.png'),'-i',str(R/'soundtrack.wav'),'-filter_complex',filters,'-map','[v]','-map','4:a','-t',str(T['duration']),'-frames:v',str(T['frames']),'-c:v','libx264','-threads','4','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart',str(R/'stillveil-auto-harvest.mp4')]
(R/'render-command.json').write_text(json.dumps(command,indent=2));subprocess.run(command,check=True)
print('RENDERED',T['duration'],'seconds',len(voices),'lines',flush=True)
