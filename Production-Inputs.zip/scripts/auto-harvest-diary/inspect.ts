import {readFileSync} from 'node:fs';
import {content} from '../../src/content';
import {dungeonLock} from '../../src/domain/events';
const save=JSON.parse(readFileSync('artifacts/auto-harvest-diary/initial-save.json','utf8'));
for(const id of ['silent-cathedral','chapel-approach','bell-stairs']){
 const d=content.dungeons.find(d=>d.id===id)!;console.log(id,d.name,'waves',d.waves.length,'lock',dungeonLock(d,save,content));
}
console.log('industry',save.industry?.stock);
