# オートなのに手が足りないのだ

PR #171（df00a04）の実UIを操作する実況動画。前回の勲章日記の終了セーブを標準の復元APIで読み込む。復元時のrevision更新以外、能力・所持品・進行・時計を改変しない。

制作順：capture.ts → prepare-edit.py → comments.py → make-voices.py → render.py → audit.py → check-playback.ts → 実フレーム目視 → package.py → publish.py。test-stretch.pyで音程を保つ時計補正も検査する。

診断ストライプと独立音声チャンネルは収録時のみ。最終動画から除去。完成MP4のSHAと結びつく、音声・動的フレーム・両ブラウザの再生検査を全て通してから配布する。制作ZIPには音楽単体・VOICEVOXモデル・実行環境を含めない。
