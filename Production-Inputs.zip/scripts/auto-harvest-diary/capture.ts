import {chromium,expect,type Frame,type Locator} from '@playwright/test';
import {readFileSync,writeFileSync,mkdirSync,appendFileSync} from 'node:fs';
import {spawn,execSync} from 'node:child_process';
import {once} from 'node:events';
import type {GameSave} from '../../src/domain/types';
const root='artifacts/auto-harvest-diary',pilot=process.argv.includes('--pilot');
const R=root+(pilot?'/pilot':'/raw');mkdirSync(R,{recursive:true});
writeFileSync(root+'/host.html',`<!doctype html><html><style>*{box-sizing:border-box}html,body{margin:0;background:#121212;width:580px;height:960px;overflow:hidden}iframe{position:absolute;left:0;top:0;width:540px;height:960px;border:0}#marker{position:absolute;left:540px;top:0;width:40px;height:960px;background:#121212}</style><iframe src="/"></iframe><div id="marker"></div><script>addEventListener('message',e=>{if('marker'in e.data)document.querySelector('#marker').style.background=e.data.marker?'white':'#121212'});</script></html>`);
const browser=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--disable-background-timer-throttling','--disable-renderer-backgrounding']});
const context=await browser.newContext({viewport:{width:580,height:960},locale:'ja-JP',deviceScaleFactor:1});
await context.addInitScript({content:readFileSync('scripts/auto-harvest-diary/audio-init.js','utf8')});
await context.addInitScript(()=>{localStorage.setItem('stillveil-language','ja');localStorage.setItem('stillveil-fairy-tutorial-v1',JSON.stringify({version:2,enrolled:false,dismissed:true,seen:[]}));});
writeFileSync(R+'/audio.f32',Buffer.alloc(0));let firstAudio:number|undefined,audioEnd=0;const audioGaps:any[]=[];
await context.exposeBinding('__pcmChunk',(_,{first,base64}:{first:number,base64:string})=>{
  const bytes=Buffer.from(base64,'base64');firstAudio??=first;
  const position=first-firstAudio;
  if(position>audioEnd){appendFileSync(R+'/audio.f32',Buffer.alloc((position-audioEnd)*12));audioGaps.push({at:audioEnd,frames:position-audioEnd});}
  if(position<audioEnd)throw Error('Audio chunks overlap');
  appendFileSync(R+'/audio.f32',bytes);audioEnd=position+bytes.length/12;
});
const page=await context.newPage();const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto('http://127.0.0.1:4173/'+root+'/host.html');
let frame=page.frames().find(f=>f.parentFrame()&&f.url()==='http://127.0.0.1:4173/')!;
if(!frame)throw Error('No game frame');
await frame.getByRole('button',{name:'タップしてはじめる',exact:true}).waitFor();
await frame.evaluate(async source=>{const a='/src/platform/save-backup.ts',b='/src/platform/save.ts',c='/src/content/index.ts';const {restoreBackup}=await import(a),{loadSave}=await import(b),{content}=await import(c);await restoreBackup({format:'stillveil-save',formatVersion:1,exportedAt:new Date().toISOString(),save:source},content,(await loadSave())?.revision??0);},JSON.parse(readFileSync(root+'/initial-save.json','utf8')));
await page.reload();frame=page.frames().find(f=>f.parentFrame()&&f.url()==='http://127.0.0.1:4173/')!;await frame.getByRole('button',{name:'タップしてはじめる',exact:true}).waitFor();
await frame.evaluate(()=>document.fonts.ready);await frame.evaluate(()=>(window as any).__initRecorder());
const ff=spawn('ffmpeg',['-v','error','-y','-f','image2pipe','-framerate','30','-i','pipe:0','-an','-c:v','libx264','-threads','2','-preset','veryfast','-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',R+'/video.mp4'],{stdio:['pipe','ignore','pipe']});let ffError='';ff.stderr.on('data',d=>ffError+=d);
const cdp=await context.newCDPSession(page);let first:number|undefined,last:Buffer|undefined,index=-1;const frames:any[]=[];let queue=Promise.resolve();
const put=async(data:Buffer)=>{if(!ff.stdin.write(data))await once(ff.stdin,'drain');};
cdp.on('Page.screencastFrame',e=>{
 const data=Buffer.from(e.data,'base64'),time=e.metadata.timestamp!;first??=time;const at=Math.round((time-first)*30);frames.push({time,at});
 queue=queue.then(async()=>{if(at<=index)return;while(index+1<at&&last){await put(last);index++;}await put(data);index++;last=data;});
 void cdp.send('Page.screencastFrameAck',{sessionId:e.sessionId});
});
await cdp.send('Page.startScreencast',{format:'jpeg',quality:97,maxWidth:580,maxHeight:960,everyNthFrame:1});
const events:any[]=[],speeds:any[]=[];const log=(type:string,data:any={})=>{const row={type,epoch:Date.now(),...data};events.push(row);console.log(type,JSON.stringify(data).slice(0,140));writeFileSync(R+'/events-live.json',JSON.stringify(events,null,2));};
const pause=(ms:number)=>page.waitForTimeout(ms);
async function click(button:Locator){await button.click({timeout:45000});}
async function save():Promise<GameSave>{return frame.evaluate(async()=>{const url='/src/platform/save.ts';return (await(await import(url)).loadSave())!;});}
async function readDialogue(opening=false){
 const box=frame.locator(opening?'.visual-novel:not(.world-conversation)':'.world-conversation');await box.waitFor();
 while(await box.count()){
  const sampled=await box.evaluate(el=>({text:el.querySelector('.novel-text')!.textContent!,scene:el.getAttribute('data-scene'),line:el.getAttribute('data-page'),speaker:el.querySelector('.novel-speaker')!.textContent!}));
  const {text,scene,line}=sampled;log('line',sampled);
  await pause(Math.max(4200,Math.min(8200,1400+text.length*105)));
  const next=box.getByRole('button',{name:'次の台詞',exact:true}),done=box.getByRole('button',{name:opening?'物語を閉じる':'地図へ戻る',exact:true});
  if(await done.count()){await click(done);break;}await click(next);
 }
}
let timer:ReturnType<typeof setInterval>|undefined;let fatal:unknown;
try{
 log('start',{pilot});await pause(1500);await click(frame.getByRole('button',{name:'タップしてはじめる',exact:true}));
 await frame.evaluate(()=>(window as any).__pulse('start'));
 timer=setInterval(()=>void frame.evaluate(()=>(window as any).__pulse('periodic')).catch(()=>{}),pilot?5000:8000);
 if(pilot){await pause(42000);}
 else{
  log('restored',{source:'medal-diary-01 genuine final save'});
  await pause(8000);log('home');writeFileSync(R+'/initial-save.json',JSON.stringify(await save(),null,2));
  await click(frame.locator('[data-guide="home-dungeons"]'));await pause(1500);
  log('map');
  await click(frame.getByRole('button',{name:'探索地点の一覧',exact:true}));
  await click(frame.getByRole('dialog',{name:'探索地点の一覧'}).getByRole('button',{name:'忘却の聖堂',exact:true}));
  await pause(1800);const travel=frame.locator('.world-map__travel');
  if((await travel.innerText()).includes('自動移動')){const start=Date.now();log('travel-start');await click(travel);await expect(travel).toContainText('探索の準備',{timeout:90000});await expect(travel).toBeEnabled();speeds.push({start,end:Date.now(),rate:2,kind:'travel'});log('travel-end');}
  await click(travel);log('prepare',{dungeonId:'silent-cathedral'});await pause(9000);
  await click(frame.locator('[data-guide="depart"]'));log('battle-start',{dungeonId:'silent-cathedral'});
  await pause(2500);await click(frame.getByRole('button',{name:'オート進行を開始',exact:true}));log('auto-on');
  let previousBeat=-1,previousRound=-1,previousChoice='',lastSnapshot='',actions=0;
  const stop=Date.now()+360000;
  while(Date.now()<stop){
   const s=await save();const b=s.battle;if(!b)throw Error('Lost battle');
   if(['reward','failed'].includes(b.phase)){log(b.phase,{dungeonId:'silent-cathedral',rounds:b.round,materials:b.pendingMaterials,harvest:b.harvest});break;}
   const h=b.harvest;
   if(b.round!==previousRound){previousRound=b.round;log('battle-round',{dungeonId:'silent-cathedral',round:b.round,wave:b.wave,party:b.units.filter(u=>u.side==='party').map(u=>({name:u.characterId,hp:u.hp,max:u.maxHp}))});}
   const snapshot=JSON.stringify({collected:h?.collected,missed:h?.missed,sockets:h?.sockets,materials:h?.materials,gems:h?.gems?.length});
   if(snapshot!==lastSnapshot){lastSnapshot=snapshot;log('harvest-state',JSON.parse(snapshot));}
   if(h?.choice && h.choice.id!==previousChoice){
    const options=h.choice.options;const order=['touch','abundance','linger','mercy','focus'];
    const best=[...options].sort((a,b)=>order.indexOf(a)-order.indexOf(b))[0];
    const card=frame.locator('[data-harvest-upgrade="'+best+'"]');
    if(await card.isVisible()){
     log('cards',{choice:h.choice.id,options,pick:best});await pause(1800);await click(card);previousChoice=h.choice.id;
     if((h.sockets?.length??0)>=3){await pause(650);await click(frame.locator('[data-harvest-socket="2"]'));}
     log('card-picked',{pick:best});await pause(1000);continue;
    }
   }
   const offers=[...(h?.offers??[])].sort((a,b)=>({gem:0,material:1,heal:2,strike:3}[a.kind]-{gem:0,material:1,heal:2,strike:3}[b.kind]));
   const target=offers.find(o=>!['heal','strike'].includes(o.kind)||(h?.aids?.length??0)<3);
   if(target){
    const el=frame.locator('[data-harvest-id="'+target.id+'"]');
    if(await el.isVisible()&&await el.isEnabled()){
     try{await el.click({timeout:900});actions++;if(actions%4===1)log('pickup-tap',{kind:target.kind,id:target.id,beat:h?.beat});}catch{}
    }
   }
   await pause(520);
  }
  const end=await save();if(!['reward','failed'].includes(end.battle?.phase??''))throw Error('Battle exceeded recording limit');
  await pause(12000);
  if(end.battle?.phase==='reward'){await click(frame.getByRole('button',{name:'獲得を確定',exact:true}));log('claimed',{dungeonId:'silent-cathedral',industry:(await save()).industry,rough:(await save()).roughMemoryGems});}
  else{await click(frame.getByRole('button',{name:'街へ戻る',exact:true}));log('failed-return');}
  await pause(4000);await click(frame.getByRole('navigation').getByRole('button',{name:'ホーム',exact:true}));
  log('outro',{actions});await pause(22000);

 }
}catch(e){fatal=e;log('error',{message:String(e)});await page.screenshot({path:R+'/failure.png'});}
finally{
 if(timer)clearInterval(timer);await frame.evaluate(()=>(window as any).__pulse('end'));await pause(1600);
 const audio=await frame.evaluate(()=>(window as any).__stopRecorder());await cdp.send('Page.stopScreencast');await queue;
 const end=Date.now();const finalIndex=Math.ceil((end/1000-first!)*30);while(index<finalIndex&&last){await put(last);index++;}
 ff.stdin.end();const[code]=await once(ff,'close');if(code!==0)throw Error(ffError);
 const finalSave=await save();writeFileSync(R+'/capture.json',JSON.stringify({version:finalSave.appVersion,commit:execSync('git rev-parse HEAD').toString().trim(),firstFrameEpoch:first,frames:index+1,frameLog:frames,audio:{...audio,firstSampleFrame:firstAudio,frames:audioEnd,gaps:audioGaps},events,speeds,errors,finalSave,uncut:true,gameRect:[0,0,540,960],diagnosticRect:[540,0,40,960],fatal:fatal?String(fatal):null},null,2));await browser.close();
}
if(fatal)throw fatal;
