import {chromium,webkit} from '@playwright/test';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash}from'node:crypto';
const R='artifacts/auto-harvest-diary',movie=R+'/stillveil-auto-harvest.mp4';const sha=()=>createHash('sha256').update(readFileSync(movie)).digest('hex'),hash=sha();
writeFileSync(R+'/player.html',`<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>オートなのに手が足りないのだ</title><style>body{margin:0;background:#f9e8ef;color:#642c4e;font:16px sans-serif;text-align:center}video{display:block;width:100%;max-height:88vh;background:black}button,a{display:inline-block;margin:12px;padding:12px}</style><video controls playsinline preload="metadata" src="./stillveil-auto-harvest.mp4"></video><button onclick="document.querySelector('video').play()">動画を再生</button><a href="./stillveil-auto-harvest.mp4" download>MP4をダウンロード</a></html>`);
const results=[];
for(const[name,type]of[['chromium',chromium],['webkit',webkit]]as const){
 let browser;try{
  const wk=process.env.HOME+'/.cache/ms-playwright/webkit-2370/minibrowser-wpe';
  browser=await type.launch(name==='webkit'?{executablePath:wk+'/bin/MiniBrowser',env:{...process.env,WEBKIT_EXEC_PATH:wk+'/bin',WEBKIT_INJECTED_BUNDLE_PATH:wk+'/lib',WEBKIT_INSPECTOR_RESOURCES_PATH:wk+'/share',LD_LIBRARY_PATH:wk+'/lib:'+wk+'/sys/lib:/workspace/Finit-battle-no-more/artifacts/wolf-rta-v112/browser-libs/root/usr/lib/x86_64-linux-gnu'}}:{});
  const p=await browser.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await p.goto('http://127.0.0.1:4193/player.html',{waitUntil:'domcontentloaded'});await p.getByRole('button',{name:'動画を再生'}).click();await p.waitForFunction(()=>document.querySelector('video')!.readyState>=2);
  const duration=await p.evaluate(()=>document.querySelector('video')!.duration),points=[];
  for(const time of[.5,duration/2,duration-2]){
   await p.evaluate(async time=>{const v=document.querySelector('video')!;v.pause();const done=new Promise<void>(resolve=>v.addEventListener('seeked',()=>resolve(),{once:true}));v.currentTime=time;await done;await v.play();},time);
   await p.waitForFunction(t=>{const v=document.querySelector('video')!;return Boolean(v.error)||v.currentTime>t+.2;},time,{timeout:20000});
   points.push(await p.evaluate(()=>{const v=document.querySelector('video')!;return {time:v.currentTime,width:v.videoWidth,height:v.videoHeight,error:v.error?.message??null,paused:v.paused};}));
  }
  results.push({browser:name,pass:points.every(x=>x.width===1920&&x.height===1080&&!x.error&&!x.paused),points});
 }catch(e){results.push({browser:name,pass:false,error:String(e)});}finally{await browser?.close();}
}
const report={sha256:hash,results,pass:results.every(x=>x.pass)&&sha()===hash};writeFileSync(R+'/playback-audit.json',JSON.stringify(report,null,2));console.log(report);if(!report.pass)process.exit(1);
