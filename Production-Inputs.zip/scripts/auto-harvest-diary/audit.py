from pathlib import Path
import json,subprocess,hashlib,sys
import numpy as np
from scipy.signal import correlate
from PIL import Image,ImageDraw,ImageFont
R=Path('artifacts/auto-harvest-diary');M=R/'stillveil-auto-harvest.mp4';T=json.loads((R/'edit-manifest.json').read_text());C=json.loads((R/'raw/capture.json').read_text());RATE=12000;FPS=30
def sha(p):return hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
def run(args):return subprocess.check_output(args)
def audio(p):return np.frombuffer(run(['ffmpeg','-v','error','-i',str(p),'-vn','-ac','1','-ar',str(RATE),'-f','f32le','-']),'<f4').copy()
def match(sig,ref,start):
 n=len(ref);base=round(start*RATE);pad=2400;lo=max(0,base-pad);y=sig[lo:base+n+pad].astype(float);x=ref.astype(float);x-=x.mean()
 c=correlate(y,x,mode='valid',method='fft');en=np.r_[0,np.cumsum(y*y)];sums=np.r_[0,np.cumsum(y)];variance=(en[n:]-en[:-n])-(sums[n:]-sums[:-n])**2/n
 score=c/np.sqrt(np.maximum(variance,1e-20)*max(1e-20,np.dot(x,x)));k=int(np.argmax(score));return {'lagMs':round((lo+k-base)/RATE*1000,3),'correlation':round(float(score[k]),6)}
mix=audio(M);without_voice=audio(R/'background-without-voice.wav');without_game=audio(R/'background-without-game.wav');N=min(len(mix),len(without_voice),len(without_game));vr=mix[:N]-without_voice[:N];gr=mix[:N]-without_game[:N]
voices=[]
for v in T['voices']:
 ref=audio(v['file']);offset=int(.08*RATE);ref=ref[offset:min(len(ref),offset+int(1.8*RATE))];m=match(vr,ref,v['start']+offset/RATE);m.update(id=v['id'],text=v['text']);m['pass']=abs(m['lagMs'])<=80 and m['correlation']>.8;voices.append(m)
print('voices',sum(v['pass']for v in voices),'/',len(voices),flush=True)
game=without_voice
def mapped_epoch(epoch):
 t=epoch/1000-C['firstFrameEpoch'];anchors=T['eventClockAnchors'];t+=float(np.interp(t,[a['real']for a in anchors],[a['video']-a['real']for a in anchors]));f=t*FPS;p=next((p for p in T['pieces']if p['sourceStartFrame']<=f<p['sourceEndFrame']),T['pieces'][-1]);return p['start']+(f-p['sourceStartFrame'])/FPS/p['rate']
starts=[e for e in C['events']if e['type']=='battle-start'];battles=[]
for first in starts:
 last=next(e for e in C['events']if e['type']in ['reward','failed']and e['dungeonId']==first['dungeonId']and e['epoch']>first['epoch'])
 battles.append((first['dungeonId'],mapped_epoch(first['epoch']),mapped_epoch(last['epoch']),first,last))
if len(battles)!=1:raise ValueError('This episode requires the recorded cathedral run')
battle_start,battle_end=battles[0][1:3]
windows=[]
for i,p in enumerate(T['pieces']):
 if p['duration']>.8:windows.append((f'piece-{i}-{p["kind"]}',p['start']+.1,p['start']+p['duration']-.1))
for id,a,b,_,_ in battles:
 for third in range(3):windows.append((f'{id}-battle-{third}',a+(b-a)*third/3,a+(b-a)*(third+1)/3))
sounds=[]
for label,a,b in windows:
 length=min(1.0,(b-a)/2);count=round(length*RATE);starts=range(round((a+.05)*RATE),max(round((a+.05)*RATE)+1,round((b-length-.05)*RATE)),800)
 at=max(starts,key=lambda k:float(np.dot(game[k:k+count],game[k:k+count])));ref=game[at:at+count];rms=float(np.sqrt(np.mean(ref*ref)))
 if rms<1e-5:raise ValueError('Audio checkpoint is silent: '+label)
 m=match(gr,ref,at/RATE);m.update(label=label,time=at/RATE,rms=rms);m['pass']=abs(m['lagMs'])<=80 and m['correlation']>.75;sounds.append(m)
print('game audio',sum(v['pass']for v in sounds),'/',len(sounds),flush=True)
def frames(p,crop):
 return np.frombuffer(run(['ffmpeg','-v','error','-i',str(p),'-an','-vf',crop+'fps=30,scale=94:166,format=gray','-f','rawvideo','-']),np.uint8).reshape(-1,166,94).copy()
G=frames(R/'gameplay-uncut.mkv','');F=frames(M,'crop=486:864:310:66,');visual=[]
def imagecheck(label,a,b):
 low=max(0,round(a*FPS));high=min(len(G)-10,round(b*FPS)-10);candidates=range(low,max(low+1,high),3)
 k=max(candidates,key=lambda k:float(np.mean(abs(np.diff(G[k:k+9].astype(float),axis=0)))))
 ref=G[k:k+9].astype(float);motion=float(np.mean(abs(np.diff(ref,axis=0))));options=[(float(np.sqrt(np.mean((F[j:j+9].astype(float)-ref)**2))),j)for j in range(max(0,k-3),min(len(F)-9,k+4))]
 rmse,j=min(options);lag=(j-k)/FPS*1000;dynamic=motion>.02
 return {'label':label,'frame':k,'motion':motion,'timingDeterminate':dynamic,'lagMs':lag if dynamic else None,'rmse':rmse,'pass':rmse<12 and (not dynamic or abs(lag)<=80)}
for i,p in enumerate(T['pieces']):
 if p['frames']>12:visual.append(imagecheck('piece-'+str(i),p['start'],p['start']+p['duration']))
for id,a,b,_,_ in battles:
 for third in range(3):
  check=imagecheck(f'{id}-battle-{third}',a+(b-a)*third/3,a+(b-a)*(third+1)/3)
  check['pass']=check['pass']and check['timingDeterminate'];visual.append(check)
print('images',sum(v['pass']for v in visual),'/',len(visual),flush=True)
# Cross-check actual retained source sequences against the original continuous raw file.
rawcheck=[]
for id,a,b,first,last in battles:
 for third in range(3):
  checkpoint=next(v for v in visual if v['label']==f'{id}-battle-{third}');t=checkpoint['frame']/FPS;p=next(p for p in T['pieces']if p['start']<=t<p['start']+p['duration']);rawtime=p['sourceStartFrame']/FPS+(t-p['start'])*p['rate'];ref=np.frombuffer(run(['ffmpeg','-v','error','-ss',str(rawtime),'-i',str(R/'raw/video.mp4'),'-t',str(.4*p['rate']),'-an','-vf',f'crop=540:960:0:0,fps={30/p["rate"]},scale=94:166,format=gray','-f','rawvideo','-']),np.uint8).reshape(-1,166,94)[:9].astype(float)
  k=round(t*FPS);options=[(float(np.sqrt(np.mean((F[j:j+9].astype(float)-ref)**2))),j)for j in range(max(0,k-2),min(len(F)-9,k+3))];rmse,j=min(options);lag=(j-k)/FPS*1000;rawcheck.append({'label':f'original-{id}-{third}','lagMs':lag,'rmse':rmse,'dynamicCheckpoint':checkpoint['timingDeterminate'],'pass':checkpoint['timingDeterminate']and abs(lag)<=80 and rmse<12})
del G,F
subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(M),'-f','null','-'],check=True)
probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(M)]));video=next(s for s in probe['streams']if s['codec_type']=='video');au=next(s for s in probe['streams']if s['codec_type']=='audio');duration=float(probe['format']['duration'])
structural={'dimensions':[video['width'],video['height']],'videoCodec':video['codec_name'],'audioCodec':au['codec_name'],'sampleRate':au['sample_rate'],'frames':int(video['nb_frames']),'duration':duration,'pass':video['width']==1920 and video['height']==1080 and int(video['nb_frames'])==T['frames']and abs(duration-T['duration'])<.08 and au['sample_rate']=='48000'}
points=[('start',.8)]
for kind in ['home','prepare','cards','claimed','outro']:
 e=next(e for e in C['events']if e['type']==kind);points.append((kind,mapped_epoch(e['epoch'])+2))
for id,a,b,_,_ in battles:points.append((id,a+(b-a)/2))
lastcard=[e for e in C['events']if e['type']=='card-picked'][-1];points.append(('sockets',mapped_epoch(lastcard['epoch'])+2));points.append(('end',duration-3))
(R/'reviews').mkdir(exist_ok=True);sheet=Image.new('RGB',(1440,270*((len(points)+2)//3)),'white')
for i,(label,t)in enumerate(points):
 path=R/'reviews'/f'{i:02}-{label}.jpg';subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(M),'-frames:v','1',str(path)],check=True);im=Image.open(path).convert('RGB');sheet.paste(im.resize((480,270)),((i%3)*480,(i//3)*270))
sheet.save(R/'contact-sheet.jpg',quality=94)
coverage={'uncut':T['uncut'],'sourceFrames':T['sourceFrames'],'coveredSourceFrames':sum(p['sourceEndFrame']-p['sourceStartFrame']for p in T['pieces']),'rates':sorted(set(p['rate']for p in T['pieces'])),'pass':T['pieces'][0]['sourceStartFrame']==0 and T['pieces'][-1]['sourceEndFrame']==T['sourceFrames']and all(a['sourceEndFrame']==b['sourceStartFrame']for a,b in zip(T['pieces'],T['pieces'][1:]))and all(p['rate']in[1,2]for p in T['pieces'])}
checks=voices+sounds+visual+rawcheck+[structural,coverage];report={'sha256':sha(M),'duration':duration,'sourceCommit':T['sourceCommit'],'version':T['version'],'toleranceMs':80,'fullDecode':True,'coverage':coverage,'captureClock':json.loads((R/'capture-sync.json').read_text()),'voices':voices,'gameAudio':sounds,'gameFootage':visual,'originalFootage':rawcheck,'structural':structural,'pass':all(c['pass']for c in checks)}
(R/'sync-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('FINAL',report['pass'],report['sha256'],flush=True)
if not report['pass']:sys.exit(1)
