from pathlib import Path
import json,subprocess,hashlib
import numpy as np
from scipy.signal import correlate
from PIL import Image,ImageDraw
R=Path('artifacts/tower-todo-diary').resolve();M=R/'stillveil-tower-todo.mp4';T=json.loads((R/'timeline.json').read_text());C=json.loads((R/'capture-with-audio.json').read_text());RATE=12000

def out(a):return subprocess.check_output(a)
def audio(p):return np.frombuffer(out(['ffmpeg','-v','error','-i',str(p),'-vn','-ac','1','-ar',str(RATE),'-f','f32le','-']),'<f4').copy()
def match(sig,ref,start):
 n=len(ref);base=round(start*RATE);pad=2400;lo=max(0,base-pad);y=sig[lo:base+n+pad].astype(float);x=ref.astype(float);x-=x.mean();c=correlate(y,x,mode='valid',method='fft');en=np.r_[0,np.cumsum(y*y)];sums=np.r_[0,np.cumsum(y)];var=(en[n:]-en[:-n])-(sums[n:]-sums[:-n])**2/n;score=c/np.sqrt(np.maximum(var,1e-20)*max(1e-20,np.dot(x,x)));k=int(np.argmax(score));return {'lagMs':round((lo+k-base)/RATE*1000,3),'correlation':round(float(score[k]),6)}
a=audio(M);bv=audio(R/'background-without-voice.wav');bg=audio(R/'background-without-game.wav');n=min(len(a),len(bv),len(bg));vr=a[:n]-bv[:n];gr=a[:n]-bg[:n];voices=[];sounds=[];visual=[]
for v in T['voices']:
 ref=audio(v['file']);offset=int(.08*RATE);ref=ref[offset:min(len(ref),offset+int(1.8*RATE))];m=match(vr,ref,v['start']+offset/RATE);m.update(id=v['id'],speaker=v['speaker']);m['pass']=abs(m['lagMs'])<=80 and m['correlation']>.8;voices.append(m)
print('voices',sum(v['pass']for v in voices),'/',len(voices),flush=True)
def frames(p,final=False):
 vf=('crop=486:864:310:66,'if final else'')+'fps=30,scale=94:166,format=gray';return np.frombuffer(out(['ffmpeg','-v','error','-i',str(p),'-an','-vf',vf,'-f','rawvideo','-']),np.uint8).reshape(-1,166,94).copy()
F=frames(M,True)
for row in T['scenes']:
 if not row['clip']:continue
 c=next(c for c in C['clips']if c['id']==row['clip']);G=frames(c['file']);N=len(G);ref=audio(c['audioFile'])if c['audio']else None
 for third in range(3):
  low=int(N*third/3);high=min(N-10,int(N*(third+1)/3));candidates=range(low,max(low+1,high),2);k=max(candidates,key=lambda k:float(np.mean(abs(np.diff(G[k:k+9].astype(float),axis=0)))));src=G[k:k+9].astype(float);expected=row['clipStartFrame']+k;motion=float(np.mean(abs(np.diff(src,axis=0))));opts=[(float(np.sqrt(np.mean((F[j:j+9].astype(float)-src)**2))),j)for j in range(max(0,expected-5),min(len(F)-9,expected+6))];rmse,j=min(opts);lag=(j-expected)/30*1000;visual.append({'scene':row['id'],'third':third,'frame':k,'motion':motion,'lagMs':lag,'rmse':rmse,'pass':abs(lag)<=80 and rmse<12 and (not c['audio']or motion>.001)})
  if ref is not None:
   length=int(.3*RATE);lo=int(low/30*RATE);hi=min(len(ref)-length,int((high+9)/30*RATE));starts=range(lo,max(lo+1,hi),400);q=max(starts,key=lambda q:float(np.dot(ref[q:q+length],ref[q:q+length])));x=ref[q:q+length];rms=float(np.sqrt(np.mean(x*x)));m=match(gr,x,row['clipStartFrame']/30+q/RATE)if rms>1e-5 else {'lagMs':None,'correlation':0};m.update(scene=row['id'],third=third,rms=rms);m['pass']=rms>1e-5 and abs(m['lagMs'])<=80 and m['correlation']>.6;sounds.append(m)
 print('clip',row['clip'],sum(x['pass']for x in visual[-3:]),flush=True)
# Independently compare the entire encoded waveform to the lossless source master.
master=audio(R/'soundtrack.flac');nn=min(len(a),len(master));block=240;mm=master[:nn//block*block].reshape(-1,block);aa=a[:len(mm)*block].reshape(-1,block);mr=np.sqrt(np.mean(mm*mm,axis=1));ar=np.sqrt(np.mean(aa*aa,axis=1));dropouts=np.flatnonzero((mr>.015)&(ar<mr*.25));residual=aa-mm;error_rms=float(np.sqrt(np.mean(residual**2)));max_window_error=float(np.max(np.sqrt(np.mean(residual**2,axis=1))));sample_peaks=float(np.max(abs(a)));join_points=[s['startFrame']/30 for s in T['scenes'][1:]];joins=[]
for sec in join_points:
 k=round(sec*RATE);lo=max(0,k-240);hi=min(nn,k+240);r=a[lo:hi]-master[lo:hi];joins.append({'time':sec,'addedResidualPeak':float(np.max(abs(r))),'pass':float(np.sqrt(np.mean(r*r)))<.025})
quality={'windowMs':20,'dropoutWindows':dropouts.tolist(),'encodedVsMasterRms':error_rms,'max20msResidualRms':max_window_error,'masterSamples12k':len(master),'decodedSamples12k':len(a),'decodedSamplePeak':sample_peaks,'sceneJoins':joins,'pass':not len(dropouts)and error_rms<.018 and max_window_error<.04 and len(master)-12<=len(a)<=len(master)+512 and sample_peaks<.99 and all(j['pass']for j in joins)}
subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(M),'-f','null','-'],check=True);probe=json.loads(out(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(M)]));v=next(x for x in probe['streams']if x['codec_type']=='video');au=next(x for x in probe['streams']if x['codec_type']=='audio');duration=float(probe['format']['duration']);structural={'width':v['width'],'height':v['height'],'frames':int(v['nb_frames']),'duration':duration,'sampleRate':au['sample_rate'],'pass':v['width']==1920 and v['height']==1080 and int(v['nb_frames'])==T['frames']and abs(duration-T['duration'])<.08 and au['sample_rate']=='48000'}
(R/'reviews').mkdir(exist_ok=True);sheet=Image.new('RGB',(1920,270*((len(T['scenes'])+3)//4)))
for i,s in enumerate(T['scenes']):
 at=s['start']+min(2,s['duration']/2);p=R/'reviews'/f'{i:02}-{s["id"]}.jpg';subprocess.run(['ffmpeg','-v','error','-y','-ss',str(at),'-i',str(M),'-frames:v','1',str(p)],check=True);sheet.paste(Image.open(p).convert('RGB').resize((480,270)),((i%4)*480,(i//4)*270))
sheet.save(R/'contact-sheet.jpg',quality=94)
report={'sha256':hashlib.sha256(M.read_bytes()).hexdigest(),'toleranceMs':80,'voices':voices,'gameAudio':sounds,'gameFootage':visual,'audioQuality':quality,'structural':structural,'fullDecode':True,'pass':all(x['pass']for x in voices+sounds+visual+[quality,structural])};(R/'sync-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('PASS',report['pass'],report['sha256'],flush=True)
if not report['pass']:raise SystemExit(2)
