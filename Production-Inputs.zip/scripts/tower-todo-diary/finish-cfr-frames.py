from pathlib import Path
import json,subprocess,hashlib
import numpy as np
R=Path('artifacts/tower-todo-diary');T=json.loads((R/'timeline.json').read_text());sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest();inputs=[R/'boards.mp4',R/'game-reel.mp4',R/'soundtrack.flac'];before={str(p):sha(p)for p in inputs};W,H=1920,1080;GW,GH=486,864;N=T['frames']
def decoder(p):return subprocess.Popen(['ffmpeg','-v','error','-threads','2','-i',str(p),'-an','-fps_mode','passthrough','-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE)
def exact(pipe,n):
 parts=[];left=n
 while left:
  b=pipe.read(left)
  if not b:raise RuntimeError('Unexpected source EOF')
  parts.append(b);left-=len(b)
 return b''.join(parts)
b=decoder(inputs[0]);g=decoder(inputs[1]);video=R/'composite-cfr.mp4';enc=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r','30','-i','pipe:0','-an','-frames:v',str(N),'-c:v','libx264','-threads','4','-preset','veryfast','-crf','19','-pix_fmt','yuv420p',str(video)],stdin=subprocess.PIPE)
for i in range(N):
 board=np.frombuffer(exact(b.stdout,W*H*3),np.uint8).reshape(H,W,3).copy();game=np.frombuffer(exact(g.stdout,GW*GH*3),np.uint8).reshape(GH,GW,3);board[66:66+GH,310:310+GW]=game;enc.stdin.write(board.tobytes())
 if i%900==0:print('frame',i,'/',N,flush=True)
assert not b.stdout.read(1)and not g.stdout.read(1),'Unexpected extra source frames';assert b.wait()==0 and g.wait()==0;enc.stdin.close();assert enc.wait()==0
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(video)]));v=probe['streams'][0];assert int(v['nb_frames'])==N and v['avg_frame_rate']=='30/1',v
# One final audio encode, directly from the lossless master. Video is copied, never retimed at mux.
command=['ffmpeg','-v','error','-y','-i',str(video),'-i',str(inputs[2]),'-map','0:v','-map','1:a','-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart',str(R/'stillveil-tower-todo.mp4')];subprocess.run(command,check=True);assert before=={str(p):sha(p)for p in inputs};(R/'final-render.json').write_text(json.dumps({'command':command,'inputs':before,'codeSha256':sha(Path(__file__)),'outputSha256':sha(R/'stillveil-tower-todo.mp4'),'composition':'Read all 9011 verified source frames, pair by integer index, composite at x310 y66, encode CFR30 without filter framesync or audio interleaving. Assert exact input and output counts before audio mux.'},indent=2));print('CFR COMPLETE',N,flush=True)
