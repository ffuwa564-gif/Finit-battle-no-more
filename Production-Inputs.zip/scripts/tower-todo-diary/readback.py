from pathlib import Path
import json,hashlib,urllib.request,concurrent.futures
R=Path('artifacts/tower-todo-diary');P=json.loads((R/'publication.json').read_text())
def check(item):
 name,url=item;h=hashlib.sha256();n=0
 with urllib.request.urlopen(url,timeout=90) as f:
  status=f.status
  while block:=f.read(1024*1024):h.update(block);n+=len(block)
 local=R/'delivery'/name;expected=hashlib.file_digest(open(local,'rb'),'sha256').hexdigest()
 row={'name':name,'url':url,'status':status,'bytes':n,'sha256':h.hexdigest(),'pass':status==200 and h.hexdigest()==expected and n==local.stat().st_size};print(name,row['pass'],n,flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:rows=list(pool.map(check,P['urls'].items()))
report={'publicationCommit':P['commit'],'movieSha256':P['sha256'],'checks':rows,'pass':all(x['pass']for x in rows)}
(R/'public-readback.json').write_text(json.dumps(report,indent=2));assert report['pass'];P['verification']='All five public files read back successfully; SHA-256 and sizes match tested local delivery files.';(R/'publication.json').write_text(json.dumps(P,indent=2))
