from pathlib import Path
import json,hashlib,shutil,subprocess
R=Path('artifacts/tower-todo-diary');D=R/'delivery';P=Path('/workspace/stillveil-tower-todo-media');repo='ffuwa564-gif/Finit-battle-no-more';branch='media/tower-todo-diary-20261107';sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
q=json.loads((D/'final-qa.json').read_text());assert q['pass']and q['sha256']==sha(D/'stillveil-tower-todo.mp4')
for name in ['sync-audit.json','playback-audit.json','visual-review.json']:
 a=json.loads((D/name).read_text());assert a['pass']and a['sha256']==q['sha256']
manifest=json.loads((D/'SHA256.json').read_text())
for name,item in manifest.items():assert sha(D/name)==item['sha256']and (D/name).stat().st_size<95*1024*1024
for p in D.iterdir():
 if p.is_file():shutil.copyfile(p,P/p.name)
raw=f'https://raw.githubusercontent.com/{repo}/{branch}/'
(P/'README.md').write_text(f'''# 白亜の塔１層、ToDoを埋めて攻略するのだ

ずんだもん・四国めたん / 1080p / 約５分 / 日本語字幕。

[▶ 動画を見る・保存する]({raw}stillveil-tower-todo.mp4)

[投稿用セット]({raw}YouTube-Package.zip) / [サムネイル]({raw}thumbnail.jpg)

![サムネイル](thumbnail.jpg)

ニューゲームの初期データから、実ルールの自動操作で仲間・装備を集め、塔１層へ挑戦した記録をゲームUIで再生・編集しました。収集途中は省略、戦闘は抜粋・倍速、SEは同じゲームのPCM合成で再構成しています。リアルタイムの手操作収録とは区別しています。

今回の４SSRを揃えるまでイベント1874周・祈願477回。最短攻略や初心者必須編成の推奨ではありません。妖精・花と守り／回復系必殺も利用した一つの成功例です。28ラウンド・４人生存、回復薬の使用０。

[制作記録]({raw}Production-Inputs.zip) / [検査](final-qa.json) / [台本](script.md) / [YouTube説明文](youtube-description.txt)

音声：VOICEVOX:ずんだもん／VOICEVOX:四国めたん。音楽：甘茶の音楽工房「フィヨルドの澄んだ風」。投稿時は同梱の説明文にあるクレジットを掲載してください。

ゲームのマージ・配信や、YouTubeへの投稿は行っていません。

完成MP4 SHA-256：`{q['sha256']}`
''')
def git(*args):subprocess.run(['git','-C',str(P),*args],check=True)
# Separate pushes keep each request bounded; all files passed QA before the first push.
names=[p.name for p in P.iterdir()if p.is_file()and p.name not in ['.git','YouTube-Package.zip','Production-Inputs.zip']]
for files,message in [(names,'media: publish verified new-game tower ToDo diary'),(['YouTube-Package.zip'],'media: add tower diary posting package'),(['Production-Inputs.zip'],'media: add reproducible tower diary production inputs')]:
 git('add','--',*files);git('commit','-m',message);git('push','origin',f'HEAD:refs/heads/{branch}')
commit=subprocess.check_output(['git','-C',str(P),'rev-parse','HEAD'],text=True).strip();report={'repository':repo,'branch':branch,'commit':commit,'sha256':q['sha256'],'urls':{name:f'https://raw.githubusercontent.com/{repo}/{commit}/{name}'for name in ['stillveil-tower-todo.mp4','YouTube-Package.zip','Production-Inputs.zip','thumbnail.jpg','final-qa.json']}};(R/'publication.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
