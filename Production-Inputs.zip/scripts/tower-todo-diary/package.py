from pathlib import Path
import json,hashlib,shutil,zipfile,csv
R=Path('artifacts/tower-todo-diary');D=R/'delivery';D.mkdir(exist_ok=True);T=json.loads((R/'timeline.json').read_text());M=R/'stillveil-tower-todo.mp4';sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest();h=sha(M)
for f in ['sync-audit.json','playback-audit.json','visual-review.json']:
 a=json.loads((R/f).read_text());assert a['pass']and a['sha256']==h,f
assert json.loads((R/'playthrough-verification.json').read_text())['pass']
credits='''音声：VOICEVOX:ずんだもん（ノーマル）／VOICEVOX:四国めたん（ノーマル）
https://voicevox.hiroshiba.jp/
キャラクター：東北ずん子・ずんだもんプロジェクト
https://zunko.jp/
実況イラスト：承認済みSTILLVEIL攻略日記Part2のオリジナル表情素材を再利用。
音楽：甘茶の音楽工房（作曲：甘茶）「フィヨルドの澄んだ風」
https://amachamusic.chagasi.com/music_fjordnosundakaze.html
楽曲の単体再配布・Content ID登録はしないでください。
ゲーム：STILLVEIL ― 静謐の残響
効果音：ゲームの実装内PCM合成を、実際の戦闘イベント表示フレームに合わせて再構成。
'''
def clock(t):return f'{int(t)//60:02}:{int(t)%60:02}'
chapters='\n'.join(clock(s['start'])+' '+s['title']for s in T['scenes']if s['id']in ['opening','goal','first','farm','grind','polish','gear','tower-open','tower-mid','finish','claim'])+'\n'
description='''【STILLVEIL】白亜の塔１層、ToDoを埋めて攻略するのだ【ずんだもん・四国めたん】

ニューゲームから目標ビルドを決めて、仲間と記憶石を集め、白亜の塔１層に挑戦！
眠らせて、守って、削る。理想品が全部揃っていなくても、役割をつないで突破を目指します。

ゲーム：https://fluffy3546.itch.io/stillveil

■ この動画の条件
ver1.28.0。初期データからゲーム内の正規コマンドのみで進行した自動操作記録を、実ゲームUIで再生・編集しています。所持品・能力値・乱数・踏破フラグの注入はありません。プレイヤーのリアルタイム手操作を収録した動画ではありません。
最初の聖堂は互換の短いWave形式で記録しています（現行の通常探索UIは連続討伐形式）。塔とイベントは現行ルールです。
収集の途中は省略。戦闘ログは抜粋・倍速、説明中は一時停止。倍率と省略を画面に表示しています。SEは収録負荷による音切れを避けるため、同じゲームの合成関数からフレームに合わせて書き出しています。

今回の４SSRが揃うまでイベント1,874周・祈願477回。新規に同じ４人を狙う負担は大きいため、最短攻略・初心者向けの必須編成として推奨するものではありません。入手順や睡眠の成功は毎回変わります。
塔１層ではノクス／イザナミ（リーダー）／セレネ／弁財天を編成。回復薬５個を携帯、使用０。妖精５回・花13回を利用し、守り・回復系必殺も予約しています。最終表示28ラウンド・４人生存。この操作方針を含めた一つの成功例です。

■ チャプター
'''+chapters+'\n■ クレジット\n'+credits
(R/'credits.txt').write_text(credits);(R/'chapters.txt').write_text(chapters);(R/'youtube-description.txt').write_text(description)
with (R/'storyboard.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['scene','start','title','source','clip','dialogue'])
 for s in T['scenes']:w.writerow([s['id'],s['start'],s['title'],s['source'],s['clip'],' / '.join(v['text']for v in T['voices']if v['id']in s['lines'])])
qa={'pass':True,'sha256':h,'duration':T['duration'],'resolution':'1920x1080','voicevoxSpeakers':['ずんだもん','四国めたん'],'evidence':['sync-audit.json','playback-audit.json','visual-review.json','playthrough-verification.json'],'audio':'48kHz common sample clock, offline game PCM, smooth fades/ducking, single final AAC encode. Entire encoded waveform checked against lossless master.'};(R/'final-qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2))
files=['stillveil-tower-todo.mp4','stillveil-tower-todo.srt','thumbnail.jpg','script.md','credits.txt','chapters.txt','youtube-description.txt','final-qa.json','sync-audit.json','playback-audit.json','visual-review.json','playthrough-verification.json','contact-sheet.jpg','storyboard.csv']
for name in files:shutil.copyfile(R/name,D/name)
with zipfile.ZipFile(D/'Production-Inputs.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in Path('scripts/tower-todo-diary').glob('*'):
  if p.is_file():z.write(p,str(p))
 for name in ['playthrough.json','commands.jsonl','content.json','script.json','capture.json','capture-with-audio.json','capture-polish.json','timeline.json','input-hashes.json','final-render.json','viewer.html','viewer.tsx','reveal.html','reveal.tsx','playthrough-verification.json','playthrough-before-card-selection.json','commands-before-card-selection.jsonl','card-selection-verification.json']:
  z.write(R/name,str(R/name))
 for folder in ['assets','voices','shots','clips']:
  for p in (R/folder).glob('*'):
   if folder=='assets' and p.name not in ['z-happy-avatar.png','z-panic-avatar.png','m-happy-avatar.png','m-deadpan-avatar.png']:continue
   if p.is_file()and p.suffix in ['.png','.wav','.json','.mp4']:z.write(p,str(p))
 z.write('docs/media/tower-todo-diary/episode-brief.md')
with zipfile.ZipFile(D/'YouTube-Package.zip','w',zipfile.ZIP_DEFLATED)as z:
 for name in files:z.write(D/name,name)
manifest={p.name:{'sha256':sha(p),'bytes':p.stat().st_size}for p in D.iterdir()if p.is_file()and p.name!='SHA256.json'};(D/'SHA256.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({n:x['bytes']for n,x in manifest.items()},indent=2))
