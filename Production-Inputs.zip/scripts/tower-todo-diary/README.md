# 塔１層・ToDo攻略動画

現行ver1.28.0の初期セーブをapplyCommandだけで進める自動操作記録。初期所持・乱数・能力・踏破フラグの注入なし。初期乱数0x584a39b1。イベント1874周・祈願477回で４SSRを獲得。最短・初心者推奨の攻略ルートではない。

prepare.tsが原記録を作る。playthrough.jsonとcommands.jsonlをそれぞれ `*-before-card-selection` へコピーしてからretake-tower.tsを実行し、邪魔な三択を正規コマンドで片付ける。verify-playthrough.tsで全コマンドの再実行と最終セーブの一致を検査する。

episode.py → make-voices.py → capture.ts（静止UIと短い原記録）→ capture-full.ts（塔の長い場面）→ capture-polish.ts → capture-reveal.ts。capture.jsonのclipsへcapture-polish.jsonのpolish-demoを１つ加え、make-sfx.ts → render.py → finish-cfr-frames.py → audit.py → check-playback.ts → 完成フレーム目視 → package.py。

viewer.html／viewer.tsx／reveal.html／reveal.tsxとplaythrough.jsonはartifacts/tower-todo-diary下。Viteの4173番ポートを使う。VOICEVOXは既存wolf-rta-v112のcore0.17.1・モデル0.17.0を利用。モデル・ランタイムや甘茶の元楽曲を制作ZIPに含めない。ゲームのMP3と実装PCM関数は元のゲームチェックアウトから参照する。

Part2承認済みピンク配色、表情差分、contain配置。実況字幕２行、ゲーム486x864、出力1920x1080/30fps。収集省略・戦闘抜粋・編集倍率・停止・自動操作記録の区別を表示する。

最終音声は48kHz共通サンプル時刻。ブラウザのリアルタイム録音を使わず、同じ合成関数からSEを書き出す。短い音源端フェード、音楽ループのクロスフェード、滑らかなダック。FLAC中間、最終AACのみ１回。

完成ファイル自体の全話者・主要戦闘各３点を照合する。全編の20ms窓でFLACからの欠落を確認。全編デコード、Chromium/WebKitの開始・中盤・終了シークも別に確認。検査後に再書き出したら全て再検査する。旧候補や旧公開動画は上書きしない。
