from pathlib import Path
import json, subprocess, hashlib, wave
from fractions import Fraction
import numpy as np
from scipy.signal import resample_poly
R=Path('artifacts/medal-diary-01');D=R/'raw';FPS=30;SR=48000;SPF=1600
meta=json.loads((D/'capture.json').read_text())
if meta['fatal'] or meta['errors']:raise ValueError('Capture failed: '+str(meta.get('fatal') or meta['errors']))
def sha(p):return hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
key=hashlib.sha256((sha(D/'video.mp4')+sha(D/'audio.f32')+sha(D/'capture.json')+Path(__file__).read_text()).encode()).hexdigest()
raw=np.memmap(D/'audio.f32',dtype='<f4',mode='r').reshape(-1,3)
gray=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(D/'video.mp4'),'-vf','crop=40:960:540:0,scale=1:1,format=gray','-f','rawvideo','-']),dtype='u1')
vm=np.flatnonzero((gray>160)&np.r_[True,gray[:-1]<=160])/FPS
block=240;amp=np.max(abs(raw[:len(raw)//block*block,2].reshape(-1,block)),axis=1)>.1
am=np.flatnonzero(amp&np.r_[True,~amp[:-1]])*block/SR
original_pulses=meta['audio']['pulses']
logged_audio=np.array([p['at']-meta['audio']['firstSampleFrame']/SR for p in original_pulses])
# Two diagnostic oscillators may overlap. Their continuous burst has only one
# observable onset, so do not invent a second calibration observation.
matched=[]
for t in am:
 i=int(np.argmin(abs(logged_audio-t)))
 if abs(logged_audio[i]-t)>.012 or i in matched:raise ValueError('Unmatched or duplicate observed audio marker')
 matched.append(i)
merged_audio=[i for i in range(len(original_pulses))if i not in matched]
for i in merged_audio:
 previous=max((j for j in matched if j<i),default=-1)
 if previous<0 or not 0<logged_audio[i]-logged_audio[previous]<.125:raise ValueError('Missing isolated audio calibration marker')
 # The logged second oscillator must extend the same measured burst.
 tail=raw[round((logged_audio[i]+.05)*SR):round((logged_audio[i]+.1)*SR),2]
 if len(tail)<100 or float(np.max(abs(tail)))<.1:raise ValueError('Merged calibration burst is not present')
pulses=[original_pulses[i]for i in matched]
expected_audio=logged_audio[matched]
if np.max(abs(am-expected_audio))>.012:raise ValueError('Audio markers do not match their recorded sample positions')
expected_video=np.array([p['epoch']/1000-meta['firstFrameEpoch']for p in pulses])
(R/'clock-observed.json').write_text(json.dumps({'video':vm.tolist(),'audio':am.tolist(),'loggedVideo':expected_video.tolist(),'loggedAudio':expected_audio.tolist(),'pulses':pulses,'inputKey':key},indent=2))
# Match monotonically; nearby diagnostic pulses may merge in captured images.
# Parent-frame paint is later during heavy rendering, so nearest-neighbor alone
# can assign both images to the later pulse. Logged emissions disambiguate them.
# The measured first title-load marker painted 0.817 s after emission.
# Allow its uniquely matched observed onset; final waveform/frame audits remain <=80 ms.
n,m=len(expected_video),len(vm)
isolated=[i for i in range(n)if(i==0 or expected_video[i]-expected_video[i-1]>1)and(i==n-1 or expected_video[i+1]-expected_video[i]>1)]
latency=[]
for i in isolated:
 j=int(np.argmin(abs(vm-expected_video[i])));delta=vm[j]-expected_video[i]
 if -.05<=delta<=1.0:latency.append((expected_video[i],delta))
expected_latency=np.interp(expected_video,[p[0]for p in latency],[p[1]for p in latency])
dp=np.full((n+1,m+1),np.inf);dp[0,0]=0;back={}
for i in range(n+1):
 for j in range(m+1):
  if not np.isfinite(dp[i,j]):continue
  if i<n and dp[i,j]+.5<dp[i+1,j]:dp[i+1,j]=dp[i,j]+.5;back[i+1,j]=(i,j,'skip')
  if i<n and j<m and -.06<=vm[j]-expected_video[i]<=1.05:
   cost=abs(vm[j]-expected_video[i]-expected_latency[i])
   if dp[i,j]+cost<dp[i+1,j+1]:dp[i+1,j+1]=dp[i,j]+cost;back[i+1,j+1]=(i,j,'match')
if not np.isfinite(dp[n,m]):raise ValueError('Clock emission sequence cannot be aligned')
i,j=n,m;pairs=[];missing_visual=[]
while i or j:
 pi,pj,kind=back[i,j]
 if kind=='match':pairs.append((pi,pj))
 else:missing_visual.append(pi)
 i,j=pi,pj
pairs.reverse();clusters=[]
for i,j in pairs:
 if clusters and vm[j]-clusters[-1][0][0]<1:clusters[-1].append((vm[j],am[i],i))
 else:clusters.append([(vm[j],am[i],i)])
all_video=np.array([vm[j]for i,j in pairs]);all_audio=np.array([am[i]for i,j in pairs])
vm=np.array([np.mean([r[0]for r in group])for group in clusters]);am=np.array([np.mean([r[1]for r in group])for group in clusters])
anchor_residuals=(all_audio-np.interp(all_video,vm,am))*1000
if len(vm)<6 or vm[0]>15 or meta['frames']/FPS-vm[-1]>15 or np.max(np.diff(vm))>31:raise ValueError('Insufficient start/interior/end clock coverage')
# A pair of unpainted periodic markers occurred during the return's automatic
# travel, outside combat. Retain the observed 30-second span rather than invent
# marker observations. Combat still requires the original <=21-second coverage.
battle_ranges=[]
for e in meta['events']:
 if e['type']=='battle-start':
  end=next(v for v in meta['events']if v['type']in ['reward','failed']and v['epoch']>e['epoch']and v['dungeonId']==e['dungeonId'])
  battle_ranges.append((e['epoch']/1000-meta['firstFrameEpoch'],end['epoch']/1000-meta['firstFrameEpoch']))
long_gaps=[{'start':float(a),'end':float(b),'seconds':float(b-a)}for a,b in zip(vm,vm[1:])if b-a>21]
if any(g['start']<b and g['end']>a for g in long_gaps for a,b in battle_ranges):raise ValueError('Insufficient combat clock coverage')
if max(abs(anchor_residuals))>80:raise ValueError('Measured post-correction clock residual exceeds 80ms')
# A single linear clock is rejected by the data. This diagnostic describes the
# raw nonlinear clock; it is NOT a lag measurement of the corrected movie.
nonlinear_diagnostic=[float((am[i]-np.interp(vm[i],[vm[i-1],vm[i+1]],[am[i-1],am[i+1]]))*1000)for i in range(1,len(vm)-1)]
event_clock=[{'real':float(np.mean([expected_video[r[2]]for r in group])),'video':float(np.mean([r[0]for r in group]))}for group in clusters]
duration=meta['frames']/FPS;N=meta['frames']*SPF
def lookup(t):
 if t<vm[0]:return am[0]+(t-vm[0])*(am[1]-am[0])/(vm[1]-vm[0])
 if t>vm[-1]:return am[-1]+(t-vm[-1])*(am[-1]-am[-2])/(vm[-1]-vm[-2])
 return float(np.interp(t,vm,am))
points=[0]+[round(t*SR) for t in vm if 0<t<duration]+[N]
# Pitch-preserving clock correction, with overlapping context at observed anchors.
# Resampling the clock directly would also detune the music under capture load.
corrected=np.zeros((N,2),np.float32);weights=np.zeros(N,np.float32);padding=4800
for a,b in zip(points,points[1:]):
 rate=(lookup(b/SR)-lookup(a/SR))*SR/(b-a)
 lo=max(0,a-padding);hi=min(N,b+padding)
 x=round(lookup(a/SR)*SR+(lo-a)*rate);y=round(lookup(a/SR)*SR+(hi-a)*rate)
 data=np.pad(np.array(raw[max(0,x):min(len(raw),y),:2]),((max(0,-x),max(0,y-len(raw))),(0,0)))
 tempo=len(data)/(hi-lo)
 encoded=subprocess.run(['ffmpeg','-v','error','-f','f32le','-ar',str(SR),'-ac','2','-i','pipe:0','-af',f'rubberband=tempo={tempo:.12f}:pitch=1:pitchq=quality:window=long:smoothing=on','-f','f32le','pipe:1'],input=data.astype('<f4').tobytes(),stdout=subprocess.PIPE,check=True).stdout
 result=np.frombuffer(encoded,'<f4').reshape(-1,2)
 result=np.pad(result,((0,max(0,hi-lo-len(result))),(0,0)))[:hi-lo]
 w=np.ones(hi-lo,np.float32)
 if a>lo:w[:a-lo]=np.linspace(0,1,a-lo)
 if hi>b:w[b-lo:]=np.linspace(1,0,hi-b)
 corrected[lo:hi]+=result*w[:,None];weights[lo:hi]+=w
corrected/=np.maximum(weights[:,None],1e-6)
with wave.open(str(R/'game-clock-corrected.wav'),'wb')as out:
 out.setnchannels(2);out.setsampwidth(2);out.setframerate(SR);out.writeframes((np.clip(corrected,-1,1)*32767).astype('<i2').tobytes())
del corrected,weights
report={'key':key,'sourceVideoSha256':sha(D/'video.mp4'),'sourceAudioSha256':sha(D/'audio.f32'),'videoMarks':vm.tolist(),'audioMarks':am.tolist(),'matchedObservedMarkers':len(pairs),'mergedAudioPulseIds':merged_audio,'observedAudioPulseIds':matched,'missingVisualPulseIds':[matched[i]for i in missing_visual],'clusters':[[r[2]for r in group]for group in clusters],'longNonCombatGaps':long_gaps,'coveragePolicy':{'maximumCombatGapSeconds':21,'maximumOtherGapSeconds':31},'clockAnchorResidualMs':anchor_residuals.tolist(),'maxClockAnchorResidualMs':float(max(abs(anchor_residuals))),'rawClockNonlinearityDiagnosticMs':nonlinear_diagnostic,'rawClockOffsetsMs':((vm-am)*1000).tolist(),'eventClockAnchors':event_clock,'audioCorrection':'Monotonic piecewise clock warp using measured anchors, pitch-preserving Rubber Band time stretching with 100ms overlapping context. Nearby diagnostic emissions are clustered to avoid exaggerated local rate changes. Game channels 0/1 only; diagnostic channel 2 excluded. The raw clock is nonlinear; omitted-neighbor diagnostics are not corrected-movie lag. Finished-file image/audio/voice checks are separate.','pass':True}
(R/'capture-sync.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
def video_time(epoch):
 t=epoch/1000-meta['firstFrameEpoch']
 return t+float(np.interp(t,[p['real']for p in event_clock],[p['video']-p['real']for p in event_clock]))
spans=[]
for row in sorted(meta['speeds'],key=lambda r:r['start']):
 a=max(0,min(meta['frames'],round(video_time(row['start'])*FPS)));b=max(a,min(meta['frames'],round(video_time(row['end'])*FPS)))
 if b>a:spans.append((a,b,row['rate'],row['kind']))
pieces=[];cursor=0;target=0
def add(a,b,rate,kind):
 global target
 if b<=a:return
 n=round((b-a)/rate);pieces.append({'sourceStartFrame':a,'sourceEndFrame':b,'rate':rate,'kind':kind,'frames':n,'startFrame':target,'start':target/FPS,'duration':n/FPS});target+=n
for a,b,rate,kind in spans:
 if a<cursor:raise ValueError('Speed intervals overlap')
 add(cursor,a,1,'play');add(a,b,rate,kind);cursor=b
add(cursor,meta['frames'],1,'play')
assert sum(p['sourceEndFrame']-p['sourceStartFrame'] for p in pieces)==meta['frames']
assert all(a['sourceEndFrame']==b['sourceStartFrame']for a,b in zip(pieces,pieces[1:]))
timeline={'fps':FPS,'sampleRate':SR,'frames':target,'duration':target/FPS,'eventClockAnchors':event_clock,'sourceFrames':meta['frames'],'sourceDuration':duration,'pieces':pieces,'uncut':True,'skippedSourceFrames':0,'sourceCommit':meta['commit'],'version':meta['version']}
(R/'timeline.json').write_text(json.dumps(timeline,ensure_ascii=False,indent=2))
(R/'segments').mkdir(exist_ok=True)
for i,p in enumerate(pieces):
 path=R/'segments'/f'{i:02}.mkv';cache=path.with_suffix('.json');cacheKey=hashlib.sha256(json.dumps([key,p,Path(__file__).read_text()],sort_keys=True).encode()).hexdigest()
 if path.exists()and cache.exists()and json.loads(cache.read_text()).get('key')==cacheKey:continue
 a,b,n=p['sourceStartFrame'],p['sourceEndFrame'],p['frames'];r=p['rate'];tempo=','.join(['atempo=2']*(int(np.log2(r))))if r>1 else 'anull'
 vf=f'crop=540:960:0:0,trim=start_frame=0:end_frame={b-a},setpts=(PTS-STARTPTS)/{r},fps=30,tpad=stop_mode=clone:stop_duration=1,trim=end_frame={n},setpts=N/(30*TB)'
 af=f'atrim=start_sample=0:end_sample={(b-a)*SPF},asetpts=PTS-STARTPTS,{tempo},apad,atrim=end_sample={n*SPF},asetpts=N/SR/TB'
 subprocess.run(['ffmpeg','-v','error','-y','-ss',f'{a/FPS:.9f}','-i',str(D/'video.mp4'),'-ss',f'{a/FPS:.9f}','-i',str(R/'game-clock-corrected.wav'),'-map','0:v','-map','1:a','-vf',vf,'-af',af,'-c:v','libx264','-threads','2','-preset','veryfast','-crf','16','-pix_fmt','yuv420p','-c:a','pcm_s16le',str(path)],check=True)
 cache.write_text(json.dumps({'key':cacheKey,'piece':p,'sha256':sha(path)}));print('segment',i,p['kind'],p['duration'],flush=True)
(R/'segments.ffconcat').write_text('ffconcat version 1.0\n'+''.join(f"file 'segments/{i:02}.mkv'\n"for i in range(len(pieces))))
subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(R/'segments.ffconcat'),'-c','copy',str(R/'gameplay-uncut.mkv')],check=True)
print('EDIT',duration,'->',target/FPS,'seconds. Every source frame retained; speed changes only.',flush=True)
