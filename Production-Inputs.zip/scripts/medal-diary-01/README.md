# ずんだもんの勲章コンプ日記 #01

タイトル：#01 【STILLVEIL】 勲章コンプ、めざすのだ
対象ソース：e6f4715 / v1.28.0。新規セーブ・通常UIへの自動入力。ゲームの数値、所持品、進行、時計は変更しない。案内チュートリアルのみ辞退。

1. `npm run dev -- --port 4196`
2. `npx tsx scripts/medal-diary-01/capture.ts`
3. `OPENBLAS_NUM_THREADS=1 python scripts/medal-diary-01/comments.py`
4. `OPENBLAS_NUM_THREADS=1 python scripts/medal-diary-01/make-voices.py`
5. `OPENBLAS_NUM_THREADS=1 python scripts/medal-diary-01/prepare-edit.py`
6. `OPENBLAS_NUM_THREADS=1 python scripts/medal-diary-01/render.py`
7. `OPENBLAS_NUM_THREADS=1 python scripts/medal-diary-01/audit.py`
8. `node artifacts/medal-diary-01/serve.mjs` を別シェルで起動。
9. `npx tsx scripts/medal-diary-01/check-playback.ts`
10. 完成ファイルの開始・途中・終了、戦闘、勲章画面、字幕と立ち絵を目視確認し、同一SHA256へ結び付けた `visual-review.json` を作成。
11. `python scripts/medal-diary-01/package.py`

実行順をまとめた `finish-render.py` は収録終了後、音声・編集・完成MP4・実フレームと実音声の同期照合・ブラウザー再生検査までを進める。公開は検査と目視確認の後。

映像とゲーム音は連続収録。音声は48kHz・ゲーム音2チャンネル＋診断専用1チャンネル。診断画像は画面外の40px帯。画像帯と診断音は完成品へ残さない。開始・途中・終了で実測した時計の違いを補正し、映像と音を同じ範囲・速度で編集する。カットなし、移動待ちだけ2倍速。

完成ファイルの全ナレーションと、2回の実戦の序盤・中盤・終盤の実音声／9連続フレームを元素材と照合する。80msを超える誤差・相関不足・検査点不足は不合格。全編デコードとChromium/WebKitの再生は別ゲート。書き出しを変更したら全検査をやり直す。

元のVOICEVOXモデル・実行環境、楽曲単体は配布しない。元の診断PCMはローカル保存し、制作ZIPにはそのハッシュと参照を含める。元の無音録画、操作記録、開始終了セーブ、ナレーション、制作コードは追跡可能な証拠として保存する。

既存の公開許可に基づき、完成品はゲーム本体から独立したGitHubメディアブランチで公開。YouTube投稿やゲームのマージ・デプロイは行わない。
