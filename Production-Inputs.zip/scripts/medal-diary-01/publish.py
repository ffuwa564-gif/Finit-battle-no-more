from pathlib import Path
import subprocess,json,hashlib,shutil
R=Path('artifacts/medal-diary-01');D=R/'delivery';P=Path('/workspace/stillveil-medal-diary-01-media');branch='media/medal-diary-01-20261106';repo='ffuwa564-gif/Finit-battle-no-more'
def sha(p):return hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
qa=json.loads((D/'final-qa.json').read_text());assert qa['pass']and sha(D/'stillveil-medal-diary-01.mp4')==qa['sha256']
for k in ['sync-audit.json','playback-audit.json','visual-review.json']:
 a=json.loads((D/k).read_text());assert a['pass']and a['sha256']==qa['sha256']
manifest=json.loads((D/'SHA256.json').read_text())
for name,item in manifest.items():assert sha(D/name)==item['sha256'],name
for p in D.iterdir():
 if p.is_file():
  assert p.stat().st_size<95*1024*1024,('File exceeds media-branch budget',p.name)
  shutil.copyfile(p,P/p.name)
raw=f'https://raw.githubusercontent.com/{repo}/{branch}/'
(P/'README.md').write_text(f'''# #01 【STILLVEIL】 勲章コンプ、めざすのだ

ずんだもんの勲章コンプ日記。8分17秒 / 1920×1080 / 字幕入り。

[▶ 動画を開く・保存する]({raw}stillveil-medal-diary-01.mp4)

[投稿用セットをダウンロード]({raw}YouTube-Package.zip) — MP4、字幕、サムネイル、台本、説明文、チャプター、クレジット、検証記録。

[制作記録]({raw}Production-Inputs.zip) / [検証結果](final-qa.json)

![サムネイル](thumbnail.jpg)

新規データの通常UIを自動操作して収録し、ずんだもん実況を後付け。移動待ちのみ倍速、カットなし。能力値・所持品・進行・ゲーム内時計の変更なし。ver1.28.0の収録用ソースを使用。今回は2か所を踏破、勲章7/100個。

VOICEVOX:ずんだもん / 東北ずん子・ずんだもんプロジェクト / 音楽：甘茶の音楽工房。投稿時は [説明文](youtube-description.txt) のクレジットを掲載してください。

完成MP4 SHA-256：`{qa['sha256']}`

ゲーム本体の更新・YouTubeへの投稿は行っていません。旧作を上書きしない独立したメディアブランチです。
''')
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config',key],text=True).strip();subprocess.run(['git','-C',str(P),'config',key,value],check=True)
subprocess.run(['git','-C',str(P),'add','.'],check=True)
subprocess.run(['git','-C',str(P),'commit','-m','media: publish Zundamon medal diary episode 01'],check=True)
subprocess.run(['git','-C',str(P),'push','origin',f'HEAD:refs/heads/{branch}'],check=True)
commit=subprocess.check_output(['git','-C',str(P),'rev-parse','HEAD'],text=True).strip()
urls={name:f'https://raw.githubusercontent.com/{repo}/{commit}/{name}'for name in ['stillveil-medal-diary-01.mp4','YouTube-Package.zip','thumbnail.jpg','Production-Inputs.zip','final-qa.json']}
report={'repository':repo,'branch':branch,'commit':commit,'sha256':qa['sha256'],'urls':urls,'verification':'pending public read-back'};(R/'publication.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
