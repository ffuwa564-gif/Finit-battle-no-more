from pathlib import Path
import json,time,subprocess,os
r=Path('artifacts/medal-diary-01/raw/capture.json')
while not r.exists():time.sleep(3)
c=json.loads(r.read_text());assert not c['fatal']and not c['errors'],c.get('fatal')
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
subprocess.run(['python','scripts/medal-diary-01/comments.py'],check=True,env=env)
voice=subprocess.Popen(['python','scripts/medal-diary-01/make-voices.py'],env=env)
edit=subprocess.Popen(['python','scripts/medal-diary-01/prepare-edit.py'],env=env)
a=voice.wait();b=edit.wait();assert a==b==0,(a,b)
subprocess.run(['python','scripts/medal-diary-01/render.py'],check=True,env=env)
subprocess.run(['python','scripts/medal-diary-01/audit.py'],check=True,env=env)
subprocess.run(['npx','tsx','scripts/medal-diary-01/check-playback.ts'],check=True,env=env)
