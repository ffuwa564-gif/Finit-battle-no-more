import sys,json,wave,io,hashlib
from pathlib import Path
import numpy as np
from scipy.signal import resample_poly
R=Path('artifacts/medal-diary-01');engine=Path('artifacts/wolf-rta-v112');sys.path.insert(0,str(engine/'pydeps'))
from voicevox_core.blocking import Onnxruntime,OpenJtalk,Synthesizer,VoiceModelFile
syn=Synthesizer(Onnxruntime.load_once(filename=str(next((engine/'voicevox').rglob('libvoicevox_onnxruntime.so.1.17.3')).resolve())),OpenJtalk(engine/'voicevox/open_jtalk_dic_utf_8-1.11'),acceleration_mode='CPU',cpu_num_threads=1)
with VoiceModelFile.open(engine/'voicevox/0.vvm')as model:syn.load_voice_model(model)
(R/'voices').mkdir(exist_ok=True)
for line in json.loads((R/'comments.json').read_text()):
 p=R/'voices'/f"{line['id']}.wav";meta=p.with_suffix('.json');key=hashlib.sha256(json.dumps([line,3,'core0.17.1-vvm0.17.0',Path(__file__).read_text()],ensure_ascii=False).encode()).hexdigest()
 if p.exists()and meta.exists()and json.loads(meta.read_text()).get('key')==key:continue
 q=syn.create_audio_query(line['voice'],3);q.speed_scale=1.12;q.intonation_scale=1.2;q.pre_phoneme_length=.055;q.post_phoneme_length=.09
 raw=syn.synthesis(q,3)
 with wave.open(io.BytesIO(raw),'rb')as f:pcm=np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').astype(np.float64)/32768;rate=f.getframerate()
 pcm=resample_poly(pcm,48000,rate);pcm*=min(2,.8/max(.001,float(abs(pcm).max())))
 with wave.open(str(p),'wb')as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(48000);f.writeframes((np.clip(pcm,-1,1)*32767).astype('<i2').tobytes())
 meta.write_text(json.dumps({'key':key,'duration':len(pcm)/48000,'speaker':'VOICEVOX:ずんだもん（ノーマル）','text':line['text']},ensure_ascii=False));print(line['id'],round(len(pcm)/48000,2),line['text'],flush=True)
