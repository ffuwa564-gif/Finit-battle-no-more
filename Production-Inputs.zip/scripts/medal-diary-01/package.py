from pathlib import Path
import json,hashlib,shutil,zipfile,csv
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path('artifacts/medal-diary-01');D=R/'delivery';D.mkdir(exist_ok=True)
A=json.loads((R/'sync-audit.json').read_text());B=json.loads((R/'playback-audit.json').read_text());T=json.loads((R/'edit-manifest.json').read_text());C=json.loads((R/'raw/capture.json').read_text());movie=R/'stillveil-medal-diary-01.mp4'
def sha(p):return hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
assert A['pass']and B['pass']and A['sha256']==B['sha256']==sha(movie)
review=json.loads((R/'visual-review.json').read_text());assert review['pass']and review['sha256']==sha(movie)
def clock(t):return f'{int(t)//60:02}:{int(t)%60:02}'
def eventtime(e):
 t=e['epoch']/1000-C['firstFrameEpoch'];anchors=T['eventClockAnchors'];t+=float(np.interp(t,[a['real']for a in anchors],[a['video']-a['real']for a in anchors]));f=t*30
 p=next((p for p in T['pieces']if p['sourceStartFrame']<=f<p['sourceEndFrame']),T['pieces'][-1]);return p['start']+(f-p['sourceStartFrame'])/30/p['rate']
chapters=[('00:00','ずんだもんの勲章コンプ日記')]
for kind,title in [('medals-intro','勲章ツリーを見てみよう'),('medal-goal','最初の目標を決める'),('battle-start','忘却の聖堂へ'),('claimed','初めての獲得'),('medals-result','今日の勲章を確認'),('outro','次の目標')]:
 matches=[e for e in C['events']if e['type']==kind]
 for n,e in enumerate(matches):
  label=title
  if kind=='battle-start'and n:label='祈りの参道へ'
  if kind=='claimed'and n:continue
  chapters.append((clock(eventtime(e)),label))
chapters.sort(key=lambda p:p[0]);chapter_text='\n'.join(t+' '+label for t,label in chapters)+'\n'
credits='''音声：VOICEVOX:ずんだもん（ノーマル）
https://voicevox.hiroshiba.jp/
キャラクター：ずんだもん（東北ずん子・ずんだもんプロジェクト）
https://zunko.jp/
実況用イラスト：承認済みSTILLVEIL攻略日記Part2の表情素材。
音楽：甘茶の音楽工房（作曲：甘茶）
https://amachamusic.chagasi.com/
ゲーム内使用曲：「悲しみの曖昧な対象」「水に沈むオルガン」「フィヨルドの澄んだ風」「騎兵戦」「楽しい冒険」
ゲームのBGM・効果音をプレイ画面と同時に収録しています。
楽曲そのものの再配布・Content ID登録はしないでください。
ゲーム・収録・編集：STILLVEIL制作プロジェクト
'''
title='#01 【STILLVEIL】 勲章コンプ、めざすのだ'
description=f'''{title}

ずんだもんの勲章コンプ日記、はじまります。
目指すは全100種類。今回は新規データから、最初の勲章を狙って冒険へ。
初期の四人で探索し、最後は勲章ツリーで今日の成果を確認します。

対象版：ver{T['version']}（収録時点のソース）。公開版は更新で内容が変わる場合があります。
遊ぶ：https://finit-battle-no-more.luxpedia.workers.dev/
itch.io：https://fluffy3546.itch.io/stillveil

通常UIへの自動入力で実プレイを収録し、ずんだもんの実況を後付けしています。
能力値・所持品・進行・ゲーム内の時計は変更していません。妖精チュートリアル案内は辞退。
収録の途中にカットはありません。移動の待ち時間だけ2倍速、会話・戦闘は等速です。
RTAではありません。序盤の物語と勲章条件のネタバレがあります。
生成AIを制作の一部に使用しています。実際の獲得結果は保存データと記録に基づきます。

【チャプター】
{chapter_text}
【クレジット】
{credits}
#ずんだもん #STILLVEIL #ゲーム実況 #勲章コンプ
'''
(D/'youtube-description.txt').write_text(description);(D/'chapters.txt').write_text(chapter_text);(D/'credits.txt').write_text(credits)
(D/'script.md').write_text('# '+title+'\n\n'+'\n\n'.join(f"{clock(v['start'])}　ずんだもん：{v['text']}"for v in T['voices']))
(D/'README.txt').write_text(f'{title}\n{clock(T["duration"])} / 1920×1080 / H.264 + AAC / 48kHz\n字幕は焼き込み済み。SRTも同梱しています。\nYouTubeへ投稿する際は同梱のクレジットを掲載してください。\nゲーム本体の変更・デプロイ、YouTube投稿は行っていません。\n')
for name in ['stillveil-medal-diary-01.mp4','stillveil-medal-diary-01.srt','sync-audit.json','playback-audit.json','contact-sheet.jpg','visual-review.json','clock-stretch-test.json']:
 shutil.copyfile(R/name,D/name)
shutil.copyfile(R/'raw/initial-save.json',D/'initial-save.json');(D/'final-save.json').write_text(json.dumps(C['finalSave'],ensure_ascii=False,indent=2))
conditions={'version':T['version'],'commit':T['sourceCommit'],'freshBrowser':True,'tutorial':'declined','uiAutomation':True,'statsInventoryProgressionClockEdited':False,'initialSave':'initial-save.json','finalSave':'final-save.json','completedDungeons':C['finalSave']['completedDungeonIds'],'earnedMedals':C['finalSave'].get('medals',{}).get('earned',[]),'rawRecording':'artifacts/medal-diary-01/raw/video.mp4','rawPcm':'retained locally; not publicly distributed as standalone music','youtubeUploaded':False}
(D/'starting-conditions.json').write_text(json.dumps(conditions,ensure_ascii=False,indent=2))
with open(D/'storyboard.csv','w',newline='')as f:
 w=csv.writer(f,lineterminator='\n');w.writerow(['id','start','end','speaker','text','source_event','source_epoch','expression'])
 for v in T['voices']:w.writerow([v['id'],v['start'],v['end'],'ずんだもん',v['text'],json.dumps(v['sourceEvent'],ensure_ascii=False),v['sourceEvent']['epoch'],v['mood']])
shutil.copyfile(D/'storyboard.csv','docs/media/medal-diary-01/storyboard.csv')
# Thumbnail uses only frames/artwork from this actual episode.
thumb=Image.new('RGB',(1280,720),'#f9e8ef');draw=ImageDraw.Draw(thumb)
for x in range(-720,1280,32):draw.line((x,0,x+720,720),fill='#f4dfe9',width=7)
draw.rounded_rectangle((16,16,1264,704),radius=28,fill='#fffaf4',outline='#dca9c0',width=4)
font=lambda n:ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',n)
draw.text((45,45),'ずんだもんの',font=font(40),fill='#642c4e');draw.text((45,100),'勲章コンプ日記  #01',font=font(57),fill='#642c4e')
draw.text((360,290),'勲章コンプ、',font=font(62),fill='#b84b82');draw.text((360,380),'めざすのだ！',font=font(62),fill='#b84b82');draw.text((365,565),'STILLVEIL',font=font(39),fill='#642c4e')
art=Image.open(R/'assets/z-happy-avatar.png').convert('RGBA');thumb.paste(art,(30,250),art)
frame=Image.open(R/'reviews/04-medals-result.jpg').convert('RGB');game=frame.crop((310,66,796,930)).resize((320,569),Image.Resampling.LANCZOS);thumb.paste(game,(925,74));thumb.save(D/'thumbnail.jpg',quality=95)
# New browser tests and render verification are tied to the same delivered bytes.
qa={'sha256':sha(movie),'pass':True,'sourceCommit':T['sourceCommit'],'version':T['version'],'duration':T['duration'],'medals':conditions['earnedMedals'],'toleranceMs':80,'voiceChecks':len(A['voices']),'gameAudioChecks':len(A['gameAudio']),'frameSequenceChecks':len(A['gameFootage'])+len(A['originalFootage']),'fullDecode':A['fullDecode'],'browsers':B['results'],'manualReview':review,'pitchPreservation':json.loads((R/'clock-stretch-test.json').read_text())}
(D/'final-qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2))
# Reproducible evidence; runtime/models/music-only files are deliberately excluded.
source=[*Path('scripts/medal-diary-01').glob('*'),*Path('docs/media/medal-diary-01').glob('*'),R/'raw/video.mp4',R/'raw/capture.json',R/'raw/initial-save.json',R/'capture-sync.json',R/'timeline.json',R/'edit-manifest.json',R/'comments.json',R/'render-command.json',R/'subtitles.ass',R/'serve.mjs',*list((R/'voices').glob('*.wav')),*list((R/'assets').glob('*-avatar.png'))]
source=[p for p in source if p.is_file()]
inputs={str(p):{'sha256':sha(p),'bytes':p.stat().st_size}for p in source};inputs[str(R/'raw/audio.f32')]={'sha256':sha(R/'raw/audio.f32'),'bytes':(R/'raw/audio.f32').stat().st_size,'publication':'local-only; diagnostic PCM includes game music'};(R/'input-hashes.json').write_text(json.dumps(inputs,ensure_ascii=False,indent=2))
with zipfile.ZipFile(D/'Production-Inputs.zip','w',zipfile.ZIP_DEFLATED,compresslevel=1)as z:
 for p in source+[R/'input-hashes.json']:z.write(p,str(p))
manifest={p.name:{'sha256':sha(p),'bytes':p.stat().st_size}for p in D.iterdir()if p.is_file()and p.name not in ['SHA256.json','YouTube-Package.zip']};(D/'SHA256.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(D/'YouTube-Package.zip','w',zipfile.ZIP_DEFLATED,compresslevel=1)as z:
 for p in sorted(D.iterdir()):
  if p.is_file()and p.suffix!='.zip':z.write(p,p.name)
print('DELIVERED',clock(T['duration']),len(conditions['earnedMedals']),'medals',sha(movie))
