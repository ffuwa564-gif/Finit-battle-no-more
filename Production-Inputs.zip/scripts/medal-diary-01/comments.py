from pathlib import Path
import json
R=Path('artifacts/medal-diary-01');C=json.loads((R/'raw/capture.json').read_text());E=C['events'];lines=[]
assert not C['fatal'] and not C['errors']
def say(text,kind,offset=.5,nth=0,mood='happy',**filters):
 sel={'type':kind,'nth':nth,**filters};matches=[e for e in E if all(str(e.get(k))==str(v) for k,v in sel.items() if k!='nth')]
 if len(matches)<=nth:return
 lines.append({'id':f'z{len(lines)+1:03}','text':text,'voice':text,'selector':sel,'offset':offset,'mood':mood})
say('ずんだもんの、勲章コンプ日記。第一回、めざすのだ！','start',.5)
say('ボクはずんだもん。今日は、勲章を集める冒険を始めるのだ。','home',.2)
say('まずは図鑑。どんな勲章があるのかな。','home',4.8)
say('えっ、百種類あるの？　思ったより長い旅になりそうなのだ。','medals-intro',.4,mood='panic')
say('工房だけじゃなくて、探索も、仲間もあるんだね。','medals-intro',6.4)
say('初めての踏破。うん、まずはこれからなのだ。','medal-goal',.6)
say('一個も取れてない今なら、何をしても前進なのだ。','medal-goal',6.1)
say('名前は、ずん。最初からいる四人で行ってみるのだ。','profile',.2)
say('最初のお仕事は、狼退治なのだ。よろしく頼むのだ。','line',.6,scene='c1-job',line='0')
say('権利の照会って何？　初仕事から話が重いのだ。','line',1,scene='c1-job',line='2',mood='panic')
say('まずは聖堂。勲章第一号を取りに行くのだ。','dungeon-goal',.3,nth=0)
say('全員で帰れたらいいな。回復薬は、必要になったら使うのだ。','prepare',.3,nth=0)
say('よし、初戦。みんなの選択を見て、一手をつなぐのだ。','battle-start',.4,nth=0)
say('最初の一巡。みんな、どう動くかな。','battle-round',.4,dungeonId='silent-cathedral',round=1)
say('四人とも仕事が違うのだ。ボクだけ突っ走らないようにしよう。','battle-ready',.2,dungeonId='silent-cathedral',round=3)
say('素材が落ちても、まだ確定じゃない。ちゃんと帰るのだ。','battle-round',.6,dungeonId='silent-cathedral',round=4)
say('一個目の勲章のために、こんなに真剣になるとは。','battle-ready',.2,dungeonId='silent-cathedral',round=6)
say('最初の探索から、けっこう粘るのだ。','battle-round',.5,dungeonId='silent-cathedral',round=8)
say('ここで欲張って、全滅だけは嫌なのだ。','battle-ready',.2,dungeonId='silent-cathedral',round=10)
say('よし、クリアなのだ！　まずは素材を持ち帰ろう。','reward',.5,nth=0)
first_claim=next(e for e in E if e['type']=='claimed')
say(f'えっ、一回で{len(first_claim["earned"])}個も取れたの？　まとめ取りなのだ！','claimed',.2,nth=0,mood='panic')
say('景色がきれいなのだ。でもボクは、さっきの勲章が気になってる。','line',.8,scene='c1-hill',line='1')
say('次の仕事もあるの？　じゃあ、もう一か所なのだ。','line',.6,scene='c1-hill',line='3')
say('次は参道なのだ。違う場所も、ひとつずつ埋めていこう。','dungeon-goal',.3,nth=1)
say('出発すれば全回復。さっきの四人で続けるのだ。','prepare',.3,nth=1)
say('二回目。今度は、ちょっと落ち着いて見られるのだ。','battle-start',.4,nth=1)
say('さっきと同じ編成で行くのだ。回復役、頼りにしてるのだ。','battle-ready',.2,dungeonId='chapel-approach',round=2)
say('敵を倒すだけじゃなくて、全員で帰りたいのだ。','battle-round',.5,dungeonId='chapel-approach',round=4)
say('この調子で埋まったらいいけど、後半は絶対そうはいかないのだ。','battle-ready',.2,dungeonId='chapel-approach',round=6)
say('勲章コンプの道、一日目から地道なのだ。','battle-round',.5,dungeonId='chapel-approach',round=8)
say('二か所目も踏破！　今日は、ここで記録を見てみるのだ。','reward',.5,nth=1)
claims=[e for e in E if e['type']=='claimed']
if len(claims)>1 and set(claims[1]['earned'])==set(claims[0]['earned']):
 say('あれ、勲章は増えてないのだ。同じ条件だけじゃ、もう取れないんだね。','claimed',.2,nth=1,mood='panic')
else:say('勲章ツリーへ戻って、答え合わせなのだ。','claimed',.2,nth=1)
# Actual counts and earned names are resolved only from this recording's save.
result=next(e for e in E if e['type']=='medals-result');earned=result['earned'];catalog=json.loads(Path('src/content/medals.json').read_text());names={m['id']:m['name']['ja']for m in catalog['medals']}
say(f'今日の成果は、百種類中、{len(earned)}個なのだ！','medals-result',.5)
say('初めての踏破、ちゃんと取れてる。やっと、ゼロじゃなくなったのだ。','medals-result',6.2) if 'explore-first' in earned else None
if 'tactics-no-potion' in earned:say('薬に頼らず、も取れてる。今回は、薬を使わずに帰れたのだ。','result-branch',.5,name='連携')
if 'four-roles' in earned:say('四つの役目。初期の四人でも取れる条件があるんだね。','result-branch',.5,name='編成')
say(f'残りは、{100-len(earned)}個。いきなり全部取れたら、日記にならないのだ。','outro',.5)
say('次は、工房か、新しい仲間の勲章も狙ってみたいのだ。','outro',7)
say('少しずつ増えるのが楽しいね。それじゃあ、また次回なのだ！','outro',14)
# Add sparse reactions only where actual HP/wave events support them, avoiding speech overlap.
def epoch(l):
 sel=l['selector'];return [e for e in E if all(str(e.get(k))==str(v)for k,v in sel.items()if k!='nth')][sel['nth']]['epoch']/1000+l['offset']
lastwave={};added=0
for e in E:
 if e['type']!='battle-ready':continue
 d=e['dungeonId'];changed=d in lastwave and lastwave[d]!=e['wave'];lastwave[d]=e['wave']
 t=e['epoch']/1000+.3
 if any(abs(epoch(l)-t)<7.5 for l in lines):continue
 injured=[p for p in e['party']if p['hp']/max(1,p['max'])<.45]
 if changed:text='次のウェーブなのだ。持ち帰るまで、まだ気は抜けないのだ。'
 elif injured:text='体力が減ってきたのだ。回復が間に合うか、見ておこう。'
 else:continue
 say(text,'battle-ready',.3,dungeonId=d,round=e['round']);added+=1
(R/'comments.json').write_text(json.dumps(lines,ensure_ascii=False,indent=2));print('lines',len(lines),'actual medals',len(earned),[names[x]for x in earned])
# Fill only genuinely open combat intervals; every remark is based on observed UI state.
spare=['勲章を集める旅だけど、目の前の一戦を大事にするのだ。','まだみんな立ってる。このまま帰るところまで頑張るのだ。','一手ずつなのだ。初日から焦っても、仕方ないのだ。','強い子を集める前に、今いる四人の戦い方を覚えよう。']
previous={};j=0;injury_index=0
injury_lines=['リオラが攻撃を受けてるのだ。後ろの三人、今のうちに頼むのだ。','盾の子に攻撃が集まるね。回復も、うまくつながってほしいのだ。','減ってはいるけど、まだ立ってる。全員で帰るまで、もうひと踏ん張り。','少しずつ減ってきたのだ。ここは、このまま進めてみるのだ。']
for e in E:
 if e['type']!='battle-ready':continue
 d=e['dungeonId'];old=previous.get(d);previous[d]=e
 t=e['epoch']/1000+.4
 if any(abs(epoch(l)-t)<9 for l in lines):continue
 tank=next((u for u in e['party']if u['name']=='liora'),None);prev=next((u for u in old['party']if u['name']=='liora'),None)if old else None
 if tank and prev and tank['hp']>prev['hp']:text='お、リオラの体力が戻ってる。回復してくれる子がいると安心なのだ。'
 elif tank and prev and tank['hp']<prev['hp']:
  text=injury_lines[injury_index%len(injury_lines)];injury_index+=1
 elif all(u['hp']>0 for u in e['party']):text=spare[j%len(spare)];j+=1
 else:text='倒れた子がいるのだ。まずは、勝って帰れるか見よう。'
 say(text,'battle-ready',.4,dungeonId=d,round=e['round'])
(R/'comments.json').write_text(json.dumps(lines,ensure_ascii=False,indent=2));print('total commentary',len(lines))
