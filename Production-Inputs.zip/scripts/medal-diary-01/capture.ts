import {chromium,expect,type Frame,type Locator} from '@playwright/test';
import {readFileSync,writeFileSync,mkdirSync,appendFileSync} from 'node:fs';
import {spawn,execSync} from 'node:child_process';
import {once} from 'node:events';
import type {GameSave} from '../../src/domain/types';
const root='artifacts/medal-diary-01',pilot=process.argv.includes('--pilot');
const R=root+(pilot?'/pilot':'/raw');mkdirSync(R,{recursive:true});
writeFileSync(root+'/host.html',`<!doctype html><html><style>*{box-sizing:border-box}html,body{margin:0;background:#121212;width:580px;height:960px;overflow:hidden}iframe{position:absolute;left:0;top:0;width:540px;height:960px;border:0}#marker{position:absolute;left:540px;top:0;width:40px;height:960px;background:#121212}</style><iframe src="/"></iframe><div id="marker"></div><script>addEventListener('message',e=>{if('marker'in e.data)document.querySelector('#marker').style.background=e.data.marker?'white':'#121212'});</script></html>`);
const browser=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--disable-background-timer-throttling','--disable-renderer-backgrounding']});
const context=await browser.newContext({viewport:{width:580,height:960},locale:'ja-JP',deviceScaleFactor:1});
await context.addInitScript({content:readFileSync('scripts/medal-diary-01/audio-init.js','utf8')});
await context.addInitScript(()=>{localStorage.setItem('stillveil-language','ja');localStorage.setItem('stillveil-fairy-tutorial-v1',JSON.stringify({version:2,enrolled:false,dismissed:true,seen:[]}));});
writeFileSync(R+'/audio.f32',Buffer.alloc(0));let firstAudio:number|undefined,audioEnd=0;const audioGaps:any[]=[];
await context.exposeBinding('__pcmChunk',(_,{first,base64}:{first:number,base64:string})=>{
  const bytes=Buffer.from(base64,'base64');firstAudio??=first;
  const position=first-firstAudio;
  if(position>audioEnd){appendFileSync(R+'/audio.f32',Buffer.alloc((position-audioEnd)*12));audioGaps.push({at:audioEnd,frames:position-audioEnd});}
  if(position<audioEnd)throw Error('Audio chunks overlap');
  appendFileSync(R+'/audio.f32',bytes);audioEnd=position+bytes.length/12;
});
const page=await context.newPage();const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto('http://127.0.0.1:4196/'+root+'/host.html');
const frame=page.frames().find(f=>f.parentFrame()&&f.url()==='http://127.0.0.1:4196/')!;
if(!frame)throw Error('No game frame');
await frame.getByRole('button',{name:'タップしてはじめる',exact:true}).waitFor();
await frame.evaluate(()=>document.fonts.ready);await frame.evaluate(()=>(window as any).__initRecorder());
const ff=spawn('ffmpeg',['-v','error','-y','-f','image2pipe','-framerate','30','-i','pipe:0','-an','-c:v','libx264','-threads','2','-preset','veryfast','-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',R+'/video.mp4'],{stdio:['pipe','ignore','pipe']});let ffError='';ff.stderr.on('data',d=>ffError+=d);
const cdp=await context.newCDPSession(page);let first:number|undefined,last:Buffer|undefined,index=-1;const frames:any[]=[];let queue=Promise.resolve();
const put=async(data:Buffer)=>{if(!ff.stdin.write(data))await once(ff.stdin,'drain');};
cdp.on('Page.screencastFrame',e=>{
 const data=Buffer.from(e.data,'base64'),time=e.metadata.timestamp!;first??=time;const at=Math.round((time-first)*30);frames.push({time,at});
 queue=queue.then(async()=>{if(at<=index)return;while(index+1<at&&last){await put(last);index++;}await put(data);index++;last=data;});
 void cdp.send('Page.screencastFrameAck',{sessionId:e.sessionId});
});
await cdp.send('Page.startScreencast',{format:'jpeg',quality:97,maxWidth:580,maxHeight:960,everyNthFrame:1});
const events:any[]=[],speeds:any[]=[];const log=(type:string,data:any={})=>{const row={type,epoch:Date.now(),...data};events.push(row);console.log(type,JSON.stringify(data).slice(0,140));writeFileSync(R+'/events-live.json',JSON.stringify(events,null,2));};
const pause=(ms:number)=>page.waitForTimeout(ms);
async function click(button:Locator){await button.click({timeout:45000});}
async function save():Promise<GameSave>{return frame.evaluate(async()=>{const url='/src/platform/save.ts';return (await(await import(url)).loadSave())!;});}
async function readDialogue(opening=false){
 const box=frame.locator(opening?'.visual-novel:not(.world-conversation)':'.world-conversation');await box.waitFor();
 while(await box.count()){
  const sampled=await box.evaluate(el=>({text:el.querySelector('.novel-text')!.textContent!,scene:el.getAttribute('data-scene'),line:el.getAttribute('data-page'),speaker:el.querySelector('.novel-speaker')!.textContent!}));
  const {text,scene,line}=sampled;log('line',sampled);
  await pause(Math.max(4200,Math.min(8200,1400+text.length*105)));
  const next=box.getByRole('button',{name:'次の台詞',exact:true}),done=box.getByRole('button',{name:opening?'物語を閉じる':'地図へ戻る',exact:true});
  if(await done.count()){await click(done);break;}await click(next);
 }
}
let timer:ReturnType<typeof setInterval>|undefined;let fatal:unknown;
try{
 log('start',{pilot});await pause(1500);await click(frame.getByRole('button',{name:'タップしてはじめる',exact:true}));
 await frame.evaluate(()=>(window as any).__pulse('start'));
 timer=setInterval(()=>void frame.evaluate(()=>(window as any).__pulse('periodic')).catch(()=>{}),pilot?5000:8000);
 if(pilot){await pause(42000);}
 else{
  await readDialogue(true);log('home');writeFileSync(R+'/initial-save.json',JSON.stringify(await save(),null,2));await pause(7000);
  await click(frame.getByRole('button',{name:'記憶の図鑑',exact:true}));
  await click(frame.getByRole('button',{name:'勲章',exact:true}));log('medals-intro',{earned:(await save()).medals?.earned??[]});await pause(10000);
  await click(frame.getByRole('button',{name:'探索',exact:true}));await pause(5000);
  await click(frame.locator('[data-medal-id="explore-first"]'));log('medal-goal');await pause(12000);
  await click(frame.getByRole('button',{name:'閉じる',exact:true}).last());
  await click(frame.getByRole('navigation').getByRole('button',{name:'ホーム',exact:true}));await pause(1500);
  await click(frame.locator('[data-guide="home-dungeons"]'));
  await click(frame.locator('.world-next-action button').first());
  const form=frame.getByRole('dialog',{name:'主人公の設定'});await form.getByRole('textbox',{name:'名前',exact:true}).fill('ずん');await form.getByRole('combobox',{name:'話し方'}).selectOption('soft');
  log('profile');await pause(4500);await click(form.getByRole('button',{name:'今の旅から始める',exact:true}));
  const nav=frame.getByRole('navigation');
  async function focusGoal(){
   const hint=frame.locator('.world-next-action button').first();
   if(await hint.count()){await click(hint);return;}
   await click(frame.locator('.world-objective-dock__trigger'));
   await click(frame.locator('.world-story-objective__main'));
  }
  async function travelTo(kind:'talk'|'dungeon',id:string){
   await focusGoal();await pause(900);const travel=frame.locator('.world-map__travel');
   if((await travel.innerText()).includes('自動移動')){
    const start=Date.now();log('travel-start',{kind,id});await click(travel);
    await expect(travel).toContainText(kind==='talk'?'声をかける':'探索の準備',{timeout:65000});
    await expect(travel).toBeEnabled();speeds.push({start,end:Date.now(),rate:2,kind:'travel'});log('travel-end',{id});
   }
   await pause(1000);return travel;
  }
  let patrols=0;
  while(patrols<2){
   const s=await save(),next=await frame.evaluate(async s=>{const a='/src/content/index.ts',b='/src/domain/world-story.ts';const{content}=await import(a);const{storyNext}=await import(b);return storyNext(s,content.worldStory!);},s);
   if(next?.node){
    log('objective',{node:next.node.id,title:next.node.title.ja});
    await click(await travelTo('talk',next.node.id));await readDialogue();await pause(1200);continue;
   }
   if(!next?.dungeonId)throw Error('No next exploration');
   const dungeonId=next.dungeonId;log('dungeon-goal',{dungeonId,patrol:patrols+1});
   await click(await travelTo('dungeon',dungeonId));log('prepare',{dungeonId});await pause(5500);
   await click(frame.locator('[data-guide="depart"]'));log('battle-start',{dungeonId});
   await frame.evaluate(()=>(window as any).__pulse('battle-start'));let rounds=0;
   while(rounds<50){
    const s=await save();if(!s.battle)throw Error('Lost active battle');
    if(['reward','failed'].includes(s.battle.phase)){log(s.battle.phase,{dungeonId,rounds,materials:s.battle.pendingMaterials});break;}
    if(s.battle.phase!=='ready'){await pause(400);continue;}
    log('battle-ready',{dungeonId,round:++rounds,wave:s.battle.wave,party:s.battle.units.filter(u=>u.side==='party').map(u=>({name:u.characterId,hp:u.hp,max:u.maxHp}))});
    await pause(3200);await click(frame.getByRole('button',{name:'ラウンドを進める',exact:true}));log('battle-round',{dungeonId,round:rounds});
    await frame.evaluate(()=>(window as any).__pulse('battle-round'));await pause(1600);
   }
   const won=(await save()).battle?.phase==='reward';await pause(6000);
   if(won){await click(frame.getByRole('button',{name:'獲得を確定',exact:true}));log('claimed',{dungeonId,earned:(await save()).medals?.earned??[]});patrols++;}
   else{await click(frame.getByRole('button',{name:'街へ戻る',exact:true}));log('failed-return',{dungeonId});throw Error('Patrol ended without a victory; revise the episode around the actual result.');}
   await pause(1500);await click(nav.getByRole('button',{name:'ダンジョン',exact:true}));await pause(1500);
  }
  await click(nav.getByRole('button',{name:'ホーム',exact:true}));await pause(1500);
  await click(frame.getByRole('button',{name:'記憶の図鑑',exact:true}));await click(frame.getByRole('button',{name:'勲章',exact:true}));
  log('medals-result',{earned:(await save()).medals?.earned??[]});await pause(14000);
  for(const name of ['探索','連携','編成']){const tab=frame.getByRole('button',{name,exact:true});if(await tab.count()){await click(tab);log('result-branch',{name});await pause(10000);}}
  log('outro',{earned:(await save()).medals?.earned??[]});await pause(22000);
 }
}catch(e){fatal=e;log('error',{message:String(e)});await page.screenshot({path:R+'/failure.png'});}
finally{
 if(timer)clearInterval(timer);await frame.evaluate(()=>(window as any).__pulse('end'));await pause(1600);
 const audio=await frame.evaluate(()=>(window as any).__stopRecorder());await cdp.send('Page.stopScreencast');await queue;
 const end=Date.now();const finalIndex=Math.ceil((end/1000-first!)*30);while(index<finalIndex&&last){await put(last);index++;}
 ff.stdin.end();const[code]=await once(ff,'close');if(code!==0)throw Error(ffError);
 const finalSave=await save();writeFileSync(R+'/capture.json',JSON.stringify({version:finalSave.appVersion,commit:execSync('git rev-parse HEAD').toString().trim(),firstFrameEpoch:first,frames:index+1,frameLog:frames,audio:{...audio,firstSampleFrame:firstAudio,frames:audioEnd,gaps:audioGaps},events,speeds,errors,finalSave,uncut:true,gameRect:[0,0,540,960],diagnosticRect:[540,0,40,960],fatal:fatal?String(fatal):null},null,2));await browser.close();
}
if(fatal)throw fatal;
