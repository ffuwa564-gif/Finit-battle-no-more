(() => {
  if (window.top === window) return;
  const w = window, Native = AudioContext, connect = AudioNode.prototype.connect;
  const ctx = new Native({sampleRate:48000}); w.__recordContext = ctx;
  const mix = ctx.createGain(), split = ctx.createChannelSplitter(2), merge = ctx.createChannelMerger(3);
  connect.call(mix,split);connect.call(split,merge,0,0);connect.call(split,merge,1,1);
  const seen = new WeakMap();
  AudioNode.prototype.connect = function(destination,...args) {
    if (destination instanceof AudioDestinationNode && this.context !== ctx && typeof this.context.createMediaStreamDestination === 'function') {
      let tap=seen.get(this.context);
      if(!tap){tap=this.context.createMediaStreamDestination();seen.set(this.context,tap);const source=ctx.createMediaStreamSource(tap.stream);connect.call(source,mix);}
      connect.call(this,tap,args[0]??0);
    }
    return connect.call(this,destination,...args);
  };
  const play = HTMLMediaElement.prototype.play, sources=new WeakMap();
  HTMLMediaElement.prototype.play=function(...args){
    if(this.tagName==='AUDIO'&&!sources.has(this)){
      const source=ctx.createMediaElementSource(this);sources.set(this,source);connect.call(source,mix);connect.call(source,ctx.destination);
    }
    return play.apply(this,args);
  };
  document.addEventListener('pointerdown',()=>void ctx.resume(),true);
  w.__pending=Promise.resolve();w.__pulseLog=[];
  w.__initRecorder=async()=>{
    const source=`class Recorder extends AudioWorkletProcessor {
      constructor(){super();this.data=new Float32Array(4096*3);this.n=0;this.first=0;this.port.onmessage=e=>{if(e.data==='stop'){this.flush();this.port.postMessage({stopped:true});}};}
      flush(){if(this.n){const data=this.data.slice(0,this.n*3);this.port.postMessage({first:this.first,data},[data.buffer]);this.n=0;}}
      process(inputs){const channels=inputs[0];for(let i=0;i<128;i++){if(this.n===0)this.first=currentFrame+i;for(let c=0;c<3;c++)this.data[this.n*3+c]=channels[c]?.[i]??0;this.n++;if(this.n===4096)this.flush();}return true;}
    } registerProcessor('continuous-recorder',Recorder);`;
    await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([source],{type:'text/javascript'})));
    const node=new AudioWorkletNode(ctx,'continuous-recorder',{channelCount:3,channelCountMode:'explicit'});
    connect.call(merge,node);connect.call(node,ctx.destination);w.__recNode=node;
    node.port.onmessage=e=>{
      if(e.data.stopped){w.__stopped=true;return;}
      const bytes=new Uint8Array(e.data.data.buffer);let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));
      const data={first:e.data.first,base64:btoa(s)};
      w.__pending=w.__pending.then(()=>w.__pcmChunk(data));
    };
  };
  w.__pulse=label=>{
    if(ctx.state!=='running')return;
    const at=ctx.currentTime+.25,osc=ctx.createOscillator(),g=ctx.createGain();osc.frequency.value=1800;g.gain.value=.7;
    connect.call(osc,g);connect.call(g,merge,0,2);osc.start(at);osc.stop(at+.12);
    let on=false;const tick=()=>{
      if(ctx.currentTime>=at&&!on){on=true;parent.postMessage({marker:true},'*');w.__pulseLog.push({label,at,performance:performance.now(),epoch:Date.now()});}
      if(ctx.currentTime<at+.16)requestAnimationFrame(tick);else parent.postMessage({marker:false},'*');
    };requestAnimationFrame(tick);
  };
  w.__stopRecorder=async()=>{w.__recNode.port.postMessage('stop');while(!w.__stopped)await new Promise(r=>setTimeout(r,10));await w.__pending;return {sampleRate:ctx.sampleRate,pulses:w.__pulseLog,contextTime:ctx.currentTime};};
})();
