# ビルド研究日誌 #04 フィオ — その余りを、次の誰かへ。 — みんなが輝くRPGを！

[完成動画（14:14）](STILLVEIL-BuildResearchDiary-04.mp4) · [サムネイル](Thumbnail-BuildResearchDiary-04.jpg) · [台本](Script.md) · [字幕](Subtitles-ja.srt) · [チャプター](Chapters.txt) · [YouTube 説明文](YouTube-Description.txt)

メガネの研究者つむぎが、ずんだもん・めたんと「フィオの余った手当を次へ渡す仕事」を研究します。全員が輝くことを目標に、採用理由だけでなく反例と旧認定の再審も扱います。最後は未検証の次回新ビルド候補エレインBD001を実原画と問いで紹介します。

現行 1.11.0（489d5a4b15f02385c7229a2b2ff29f76da0abf44）での収録と、明示した未実装 LAB の実ログ再生を併用。現行ゲームでの独占攻略は未認定です。動画保存ブランチからゲームの新機能や itch.io 更新は行いません。

制作コードの固定コミット：`455e128e501b50dfe82a4ddaa47d1c8d4fadecb4`（`video/build-research-diary-04`）。ゲーム原本コミットとは別に記録します。

## 再現用素材

- [Production-Materials-01.zip](Production-Materials-01.zip) (61.5 MiB)
- [Production-Materials-02.zip](Production-Materials-02.zip) (22.3 MiB)
- [Recording-Sources-01.zip](Recording-Sources-01.zip) (19.4 MiB)
- [Recording-Sources-02.zip](Recording-Sources-02.zip) (30.0 MiB)

全 ZIP を同じソースブランチのリポジトリルートへ展開してください。新原画・再利用素材の出典・OP 音源・全音声・編集コード・研究データ・原本収録を収録。72 姿の既存ゲーム原画は [固定 URL＋SHA 台帳](External-Assets.json) で参照し、既存素材の二重収録を避けています。甘茶の原曲は公式配布先から取得してください。

[再現手順](Reproduce.md) · [制作クレジット](Credits.md) · [収録と研究の範囲](Methods.md) · [全少女台帳](Character-Registry.json) · [認定監査](Gem-Audit.json) · [収録原本](Recording-Sources.json)

## 検証

[完成動画の同期](Finished-Movie-Sync.json) · [デコード](Decode-Validation.json) · [ブラウザ](Validation.json) · [画面](Visual-QC.json) · [全員表示](Roster-Coverage.json) · [目視レビュー](Manual-Visual-Review.json)

各検査は同一完成動画の SHA に固定。[公開ファイル SHA](SHA256SUMS.txt) · [梱包台帳](Packaging-Manifest.json)。再編集した場合は全検査を更新してください。
