from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageOps
import json,shutil
B=Path('artifacts/rescue-sequel');C=B/'cards';C.mkdir(exist_ok=True);G=B/'figures';G.mkdir(exist_ok=True);F='/usr/share/fonts/opentype/noto/'
def font(n,b=False):return ImageFont.truetype(F+('NotoSansCJK-Bold.ttc'if b else'NotoSansCJK-Regular.ttc'),n)
def text(d,xy,s,n=22,color='#f1eee7',bold=False,maxw=698):
 while d.textbbox((0,0),s,font=font(n,bold))[2]>maxw:n-=1
 assert n>=12,(s,n)
 d.text(xy,s,font=font(n,bold),fill=color)
def base(title,tag='キャラクター救済工房・第二回 ／ 提案は未実装'):
 im=Image.new('RGB',(760,500),'#101c2b');d=ImageDraw.Draw(im);d.rounded_rectangle((1,1,758,498),radius=18,outline='#42566c',width=2);text(d,(27,20),tag,15,'#ddc18b');text(d,(26,54),title,28,bold=True);d.line((28,103,730,103),fill='#42566c');return im,d
def foot(d,s='条件と対象を絞った研究用の試案。全ビルド・全ダンジョンの最適化ではありません。'):text(d,(27,467),s,14,'#acbdce')
S=json.loads((B/'sections.json').read_text())
for s in S:
 im,d=base(s['title'])
 for i,(a,b)in enumerate(s['rows']):
  y=121+i*78;d.rounded_rectangle((24,y-4,735,y+67),radius=10,fill='#203144'if i%2==0 else'#142437');text(d,(37,y),a,20,'#ddc18b',True);text(d,(37,y+32),b,21)
 foot(d);im.save(C/(s['id']+'.png'))
# Collect official in-game profile recordings; keep original sources and offsets intact.
(B/'capture').mkdir(exist_ok=True)
for id in ['noelle','seris','nike-standard','lucielle','flora-standard','haniyasu','elaine','nox','athena','liora-awakened','noelle-awakened','kuzuha','hecate','seris-awakened']:
 if (B/'capture'/(id+'.json')).exists():continue
 for old in ['artifacts/character-spread/capture','artifacts/character-ranking-v1/capture']:
  p=Path(old)/(id+'.json')
  if p.exists():shutil.copyfile(p,B/'capture'/p.name);break
R={c['id']:c for c in json.loads(Path('artifacts/tower-redesign/audit.json').read_text())['characters']}
notes={'liora':'初期の姿／今回の固定技能20種の対象外','hebe':'通常回復の仕事と追加障壁を検討','tikka':'封印は通常スキルが対象／状態異常とは別','iris':'強化と行動のタイミングを考える','noelle-awakened':'今回の固定技能20種の対象外','noelle':'通常全体技の使いどころを検討','nike-standard':'通常の姿／破砕は既存の仕事','lucielle':'強い既存強化との重なりを検討','flora-standard':'低定数でも役割がある反例','haniyasu':'守護と王冠の代価を検討','elaine':'低定数でも回復の役割がある','nox':'強い攻撃役への波及も見る','athena':'元の王冠を外す代価を考える','seris':'初期の姿／固定下位群とは別'}
for id,note in notes.items():
 c=R[id];im=Image.new('RGB',(479,500),'#101c2b');d=ImageDraw.Draw(im);text(d,(25,23),'現行の図鑑 ／ 追加効果は提案',17,'#acbdce',maxw=429);text(d,(25,65),c['name'],32,bold=True,maxw=429);text(d,(25,116),c['epithet'],21,'#ddc18b',maxw=429);text(d,(25,165),f'{c.get("rarity","")} ／ 本人の定数 {c["strength"]/10:.1f}',25,'#bad7c9',True,maxw=429)
 for j,sk in enumerate(c['skills']):text(d,(25,226+j*39),sk['name'],21,maxw=429)
 text(d,(25,401),note,19,'#ddc18b',maxw=429);text(d,(25,466),'図鑑の元の技と、試作の追加効果は別です。',16,'#acbdce',maxw=429);im.save(C/('profile-'+id+'.png'))
for p in (B/'director/figures').glob('*.png'):shutil.copyfile(p,C/('diagram-'+p.name))
shutil.copyfile('artifacts/character-ranking-v1/stage.png',B/'stage.png')
print('Base cards',len(S),'profiles',len(notes))
