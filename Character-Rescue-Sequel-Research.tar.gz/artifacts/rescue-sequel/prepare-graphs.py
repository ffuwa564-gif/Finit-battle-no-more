from pathlib import Path
import json,runpy
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
from PIL import Image,ImageDraw
M=runpy.run_path('artifacts/rescue-sequel/prepare-base.py');B=M['B'];C=M['C'];G=M['G'];base=M['base'];text=M['text'];foot=M['foot'];A=json.loads((B/'benchmark/analysis.json').read_text());S=json.loads((B/'benchmark/selection.json').read_text());F='/usr/share/fonts/opentype/noto/'
font_manager.fontManager.addfont(F+'NotoSansCJK-Regular.ttc');plt.rcParams.update({'font.family':'Noto Sans CJK JP','font.size':11,'figure.facecolor':'#101c2b','axes.facecolor':'#101c2b','text.color':'#f1eee7','axes.labelcolor':'#cad6e0','xtick.color':'#cad6e0','ytick.color':'#cad6e0','axes.edgecolor':'#52677c','savefig.facecolor':'#101c2b'})
def save(fig,name,title,footer):
 fig.tight_layout();fig.savefig(G/(name+'.png'),dpi=200);fig.savefig(G/(name+'.svg'));plt.close(fig);im,d=base(title);p=Image.open(G/(name+'.png')).convert('RGB');p.thumbnail((710,343));im.paste(p,((760-p.width)//2,111));text(d,(27,467),footer,14,'#acbdce');im.save(C/(name+'.png'))
def chart():
 fig,ax=plt.subplots(figsize=(9,4.15));ax.spines[['top','right']].set_visible(False);return fig,ax
# A formula illustration, not a fitted empirical character-strength model.
fig,ax=chart();x=np.arange(10,81);defense=60;skill=14;f=lambda y:np.maximum(1,np.floor(3*y*(skill+30)/80-defense/2));ax.plot(x,f(x),label='元の攻撃',c='#9bb6ce',lw=2);ax.plot(x,f(x*1.1),label='攻撃を10%増やした例',c='#c4a3d8',lw=2);ax.plot(x,f(x+10),label='参照攻撃に10加えた例',c='#ddb872',lw=2);ax.set_xlabel('仮の参照攻撃');ax.set_ylabel('簡略化した一撃ダメージ');ax.set_title('通常攻撃スキル・強さ14・防御60／一時補正・連携・かばうを省略');ax.legend(frameon=False);ax.grid(alpha=.15);save(fig,'damage-threshold','防御の境目で、加算と倍率の効き方は違う','数式の説明用の例。実戦勝率でも、今回の全試作の計算でもありません。')
# Stage1 complete candidate table, split by actual opportunity cost.
for group,name,title in [(['gem','skill'],'screen-skill','調整用10条件：通常技能と石の候補'),(['leader'],'screen-leader','調整用10条件：王冠の代価を含める')]:
 rows=[r for r in S['rows']if r['family']in group];im,d=base(title,'候補を選ぶ調整値 ／ 未使用条件での確認結果ではありません')
 for xx,t in [(33,'試案'),(441,'対象数'),(563,'平均差・点')]:text(d,(xx,114),t,18,'#aebed0',maxw=180)
 h=34 if len(rows)>6 else 66
 for j,r in enumerate(rows):
  y=150+j*h;d.rounded_rectangle((26,y-2,734,y+h-7),radius=7,fill='#203144'if j%2==0 else'#142437');text(d,(38,y+1),r['name'],20,'#ddc18b',True,maxw=380);text(d,(465,y+1),str(r['n']),20,maxw=80);text(d,(577,y+1),f'{r["selectionGain"]:+.4f}',21,'#bcdbc6'if r['selectionGain']>0 else'#dea4b2',True,maxw=150)
 foot(d,'対象は案ごとに異なる。同じ予算のランキングではなく、各枠の候補選び。');im.save(C/(name+'.png'))
fig,ax=chart();keys=['flat-gem','flat-gem-optional','guard-counter','leader_pledge-optional'];labels=['灯芯・対象へ装備','灯芯・選択保持','守りの返し','致死回避・選択保持'];y=np.arange(4)
for j,k in enumerate(keys):
 m=A['modes'][k];delta=m['withinRoleSD']-A['modes']['native']['withinRoleSD'];lo,hi=m['sdChangeInterval'];ax.errorbar(delta,j,xerr=[[delta-lo],[hi-delta]],fmt='o',c='#ddb872'if j<2 else'#aa94c3',capsize=5,lw=2)
ax.axvline(0,c='#9fb4c9',ls='--');ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlabel('役割内スコアSDの差（負の方が差の縮小）');ax.grid(axis='x',alpha=.15);ax.set_title('確認用30条件の組を再標本化した95%区間／全69種類');save(fig,'sd-interval','小さい差を、どこまで確かめられた？','区間はこの試験条件内の揺れ。プレイヤー全体への効果の保証ではありません。')
fig,ax=chart();keys=['native','flat-gem','flat-gem-optional','guard-counter','leader_pledge','leader_pledge-optional'];labels=['現行','灯芯\n装備','灯芯\n選択','反撃','致死回避\n全対象','致死回避\n選択'];x=np.arange(len(keys));ax.bar(x-.18,[A['modes'][k]['bottomMean']for k in keys],width=.35,color='#dfbd83',label='固定下位20');ax.bar(x+.18,[A['modes'][k]['topMean']for k in keys],width=.35,color='#a9c9d8',label='固定上位20');ax.set_xticks(x,labels);ax.set_ylim(0,60);ax.set_ylabel('比較スコア平均（点）');ax.legend(frameon=False,ncol=2,loc='upper left');ax.grid(axis='y',alpha=.15);save(fig,'bottom-top','下位が上がったか、上位を下げただけか','上位20種は今回の対象条件外。全ての強者横取りを調べた意味ではありません。')
fig,ax=chart();v=[A['modes'][k]['bottomMean']for k in ['native','native_self','leader_pledge']];ax.bar([0,1,2],v,color=['#a9bfd2','#ce9bac','#dfbd83'],width=.62);ax.set_xticks([0,1,2],['元の王冠','本人へ王冠\n現行のまま','本人へ王冠\n致死回避を追加']);ax.set_ylim(0,49);ax.set_ylabel('固定下位20種の平均スコア');
for j,z in enumerate(v):ax.text(j,z+.7,f'{z:.3f}',ha='center',fontweight='bold',fontsize=14)
ax.annotate(f'王冠の代価 {v[1]-v[0]:+.3f}',xy=(1,v[1]),xytext=(.4,46),arrowprops=dict(arrowstyle='->',color='#d8b3be'),ha='center',c='#d8b3be');ax.annotate(f'新効果 {v[2]-v[1]:+.3f}',xy=(2,v[2]),xytext=(1.75,46),arrowprops=dict(arrowstyle='->',color='#dfbd83'),ha='center',c='#dfbd83');save(fig,'crown-waterfall','効果は働いた。でも、王冠を渡す代価に届かない','同じ新効果でも、比べる基準を変えると結論が変わります。')
# Data table, independent means and probabilities kept in different columns.
im,d=base('確認用30条件・69種：成果と代価を並べる')
for xx,t in [(30,'条件'),(310,'役割内SD'),(442,'下位20平均'),(610,'勝利割合')]:text(d,(xx,116),t,17,'#adbed0',maxw=190)
for j,(k,label)in enumerate(zip(keys,['現行','灯芯を装備','灯芯を選べる','守りの返し','致死回避・全対象','致死回避を選べる'])):
 m=A['modes'][k];y=153+j*45;d.rounded_rectangle((24,y-4,735,y+36),radius=7,fill='#203144'if j%2==0 else'#142437');text(d,(37,y),label,20,maxw=265)
 for xx,z in [(322,f'{m["withinRoleSD"]:.3f}'),(474,f'{m["bottomMean"]:.3f}'),(626,f'{m["meanWinRate"]*100:.3f}%')]:text(d,(xx,y),z,20,'#ddc18b',True,maxw=120)
foot(d,'選べる条件は調整時の選択を固定。確認用結果での選び直しはしていません。');im.save(C/'summary-table.png')
# Do not conflate changes across roles or decide a global ranking.
cs=[c for c in A['characters']if c['id']in A['protocol']['fixedBottom20']];fig,ax=plt.subplots(figsize=(9,4.15));gains=np.array([c['flat-gem-optional']['scoreGain']for c in cs]);order=np.argsort(gains);cs=[cs[i]for i in order];ax.barh(np.arange(len(cs)),gains[order],color=['#c2a0cc'if g<0 else'#dfbd83'for g in gains[order]],height=.7);ax.set_yticks(np.arange(len(cs)),[c['name']for c in cs],fontsize=8);ax.axvline(0,color='#8fa3b8',lw=1);ax.set_xlabel('灯芯・調整時の選択を保持した時のスコア変化（点）');ax.spines[['top','right']].set_visible(False);save(fig,'individual-changes','同じ石でも、変わる子と、変わらない子がいる','役割を超えた強さ順ではありません。固定下位20種の個別変化です。')
# Real traced AI interaction; this is one selected diagnostic example, not the aggregate proof.
im,d=base('小さな障壁が、強い障壁の行き先を変えた','同じ初期条件の追跡例 ／ ヘベ・成長後・塔1層・seed303')
for x,label,col in [(25,'現行','#b3ccdc'),(389,'祈りの余韻','#deba80')]:
 d.rounded_rectangle((x,116,x+345,445),radius=14,fill='#203144');text(d,(x+15,130),label,27,col,True,maxw=315)
 vals=['R1  ヘベがアテナを回復','R2  アテナへ白灯石169','R2後 アテナHP279','R24 勝利']if x==25 else['R1  回復＋アテナへ障壁55','R2  保護済み判定で別対象へ','R2後 アテナHP180','R18 敗北']
 for j,t in enumerate(vals):
  y=182+j*63;text(d,(x+15,y),t,20,col if j in[1,3]else'#e4ebec',j==3,maxw=315)
  if j<3:d.polygon([(x+167,y+31),(x+177,y+31),(x+172,y+43)],fill=col)
foot(d,'この例の因果候補を追加試験で分離。全ての悪化の原因を一例で断言しません。');im.save(C/'aftercare-cause.png')
# Stone references and their actual ceilings, not final damage caps.
for id,label,formula,sub in [('flat','灯芯の補助石','自分の参照攻撃 ＋24','参照値65まで／元の値より下げない'),('shared','分灯の共鳴石','他の生存味方の平均 ×90%','参照値70まで／元の値より下げない')]:
 im,d=base(label+'：どこへ補正を足す？');text(d,(36,130),formula,35,'#e0c18a',True);text(d,(36,193),sub,24,'#bfd9c7');d.rounded_rectangle((34,257,725,330),radius=10,fill='#203144');text(d,(50,274),'王冠の常時補正後 → 参照値の補助 → バフ・加速 → ダメージ',22);text(d,(37,363),'65・70は参照攻撃の上限。最終ダメージの上限ではない。',23);text(d,(37,410),'固定T3／再使用3R／通常の35%残響追撃／開幕障壁なし',20,'#acbdce');foot(d,'キャラクターの恒久ステータスや、本人の定数を書き換える案ではありません。');im.save(C/('stone-flow-'+id+'.png'))
if (B/'leaders/stress-figure.png').exists():
 import shutil;shutil.copyfile(B/'leaders/stress-figure.png',C/'leader-stress.png')
print('Stage1 graphs and causal figures prepared')
