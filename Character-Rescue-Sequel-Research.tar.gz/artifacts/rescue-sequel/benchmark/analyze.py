from pathlib import Path
import json,csv,collections,hashlib
import numpy as np
B=Path('artifacts/rescue-sequel/benchmark');P=json.loads((B/'protocol.json').read_text());S=json.loads((B/'selection.json').read_text());legacy=json.loads(Path('artifacts/character-spread/frozen-protocol.json').read_text());source={c['id']:c for c in json.loads(Path('artifacts/character-ranking-v1/characters.json').read_text())};ids=[c['id']for c in legacy['chars']];ix={id:i for i,id in enumerate(ids)};roles=sorted({source[id]['role']for id in ids});groups={r:[ix[id]for id in ids if source[id]['role']==r]for r in roles};bottom=[ix[id]for id in P['fixedBottom20']];top=[ix[id]for id in P['fixedTop20']];ctx=[(c,s)for c in ['early','developed']for s in ['event-whiteflower-path','ivory-tower-001','ivory-tower-010']];seeds=P['heldoutSeeds'];raw={};tensors={};triggers={};N=30

def load(name,path):
 d=json.loads(path.read_text());raw[name]=d;assert len(d['rows'])<=414 and len(d['rows'])%6==0;return d
base=load('native',B/'native-heldout.json')
def tensor(d,key='score',fallback=None):
 a=np.copy(fallback)if fallback is not None else np.zeros((69,6,N))
 for r in d['rows']:
  assert len(r['results'])==N
  j=ctx.index((r['core'],r['scene']));a[ix[r['id']],j]=[z[key]for z in r['results']]
 return a
for name,path in [('native',B/'native-heldout.json'),('native_self',B/'native-self-heldout.json'),('flat-gem',B/'heldout-flat-gem.json'),('guard-counter',B/'heldout-guard-counter.json'),('leader_pledge',B/'heldout-leader_pledge.json'),('echo-native',B/'echo-ablation.json')]:
 d=raw['native']if name=='native'else load(name,path);tensors[name]={k:tensor(d,k,tensors.get('native',{}).get(k))for k in ['score','win','survivors','progress','rounds']};dd=collections.Counter()
 for r in d['rows']:
  for z in r['results']:dd.update(z.get('triggers',{}))
 triggers[name]=dict(dd)
for row in S['selected']+[S['rejectedValidation']]:
 mode=row['mode'];take=np.array([row['optionChoices'][id]=='proposal'for id in ids]);tensors[mode+'-optional']={k:np.where(take[:,None,None],a,tensors['native'][k])for k,a in tensors[mode].items()}

take=np.array([S['selected'][0]['optionChoices'][id]=='proposal'for id in ids]);tensors['echo-native-flat-choice']={k:np.where(take[:,None,None],a,tensors['native'][k])for k,a in tensors['echo-native'].items()}

def stats(scores):
 a=np.asarray(scores);within=np.empty_like(a)
 for g in groups.values():within[g]=a[g]-a[g].mean(axis=0)
 return {'meanScore':a.mean(axis=0),'withinRoleSD':np.sqrt((within*within).mean(axis=0)),'bottomMean':a[bottom].mean(axis=0),'topMean':a[top].mean(axis=0),'topBottomGap':a[top].mean(axis=0)-a[bottom].mean(axis=0)}
rng=np.random.default_rng(20261101);weights=rng.multinomial(N,np.full(N,1/N),size=2000).T/N
nativeScores=tensors['native']['score'].mean(axis=(1,2));nativeBoot=stats(tensors['native']['score'].mean(axis=1)@weights);results={};per=[{'id':id,'name':source[id]['name'],'role':source[id]['role'],'rarity':source[id]['rarity'],'constant':source[id]['strength']/10}for id in ids]
for name,t in tensors.items():
 score=t['score'].mean(axis=(1,2));m={k:float(v)for k,v in stats(score).items()};boot=stats(t['score'].mean(axis=1)@weights);m.update({'meanWinRate':float(t['win'].mean()),'meanSurvivors':float(t['survivors'].mean()),'meanProgress':float(t['progress'].mean()),'meanRounds':float(t['rounds'].mean()),'adverseCharacters':int(np.sum(score<nativeScores-1e-9)),'improvedCharacters':int(np.sum(score>nativeScores+1e-9)),'unchangedCharacters':int(np.sum(abs(score-nativeScores)<=1e-9)),'roleMetrics':{r:{'n':len(g),'mean':float(score[g].mean()),'sd':float(score[g].std())}for r,g in groups.items()},'contextMetrics':[{'core':c,'scene':s,'meanScore':float(t['score'][:,j].mean()),'winRate':float(t['win'][:,j].mean()),'bottomScore':float(t['score'][bottom,j].mean()),'topScore':float(t['score'][top,j].mean())}for j,(c,s)in enumerate(ctx)],'CI':{k:[float(x)for x in np.quantile(v,[.025,.975])]for k,v in boot.items()}})
 if name!='native':m['differenceVsNative']={k:float(m[k]-results['native'][k])for k in ['meanScore','withinRoleSD','bottomMean','topMean','topBottomGap','meanWinRate','meanSurvivors','meanProgress']};m['sdChangeInterval']=[float(v)for v in np.quantile(boot['withinRoleSD']-nativeBoot['withinRoleSD'],[.025,.975])];m['bottomChangeInterval']=[float(v)for v in np.quantile(boot['bottomMean']-nativeBoot['bottomMean'],[.025,.975])];m['meanChangeInterval']=[float(v)for v in np.quantile(boot['meanScore']-nativeBoot['meanScore'],[.025,.975])];m['withinRoleSDReductionPercent']=float((1-m['withinRoleSD']/results['native']['withinRoleSD'])*100)
 results[name]=m
 for i,id in enumerate(ids):
  deltaSeed=(t['score'][i]-tensors['native']['score'][i]).mean(axis=0);ci=np.quantile(deltaSeed@weights,[.025,.975]);per[i][name]={'score':float(score[i]),'winRate':float(t['win'][i].mean()),'scoreGain':float(score[i]-nativeScores[i]),'scoreGainInterval':[float(x)for x in ci],'survivors':float(t['survivors'][i].mean()),'contextScores':[float(x)for x in t['score'][i].mean(axis=1)]}
allStats=[]
for mode in [r['id']for r in S['rows']]:
 d=json.loads((B/('screen-'+mode+'.json')).read_text());dd=collections.Counter()
 for r in d['rows']:
  for z in r['results']:dd.update(z.get('triggers',{}))
 allStats.append({'mode':mode,'phase':'screen','trials':d['trials'],'counters':dict(dd)})
ablation={}
for new,control in [('flat-gem','echo-native'),('flat-gem-optional','echo-native-flat-choice')]:
 delta=tensors[new]['score']-tensors[control]['score'];score=delta.mean(axis=(1,2));ablation[new]={'control':control,'meanScoreMechanismGain':float(delta.mean()),'bottomMechanismGain':float(delta[bottom].mean()),'meanWinRateMechanismGain':float((tensors[new]['win']-tensors[control]['win']).mean()),'meanScoreMechanismInterval':[float(x)for x in np.quantile(delta.mean(axis=1).mean(axis=0)@weights,[.025,.975])],'perCharacterMechanismGain':{id:float(score[ix[id]])for id in ids}}
report={'source':P['source'],'status':'proposal-only, game unchanged','forms':69,'constantDistributionUnchanged':True,'protocol':P,'selection':S,'heldout':{'seeds':seeds,'resampling':'2000 paired resamples of the30 seed blocks preserving all6 contexts and69 candidates; intervals describe this fixture, not player population','trials':sum(d['trials']for d in raw.values()),'note':'native_self contains fixed20 only and retains native rows for all other49, so reused rows are not counted as new battles'},'modes':results,'characters':per,'triggerCounters':triggers,'flatMechanismAblation':ablation,'screenTriggerCounters':allStats,'limits':['Not an exhaustive game balance or builds ranking','Individual choices frozen from training; optional rows reuse the matching native/proposal results without adding battles','Selected best failed leader remains rejected globally; optional alternative is follow-up only','Different proposals have different acquisition/slot/crown costs','Raw counter units differ and are not total successful damage increases','Do not add independent mode improvements as if a combined build were simulated']}
(B/'analysis.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
with(B/'Character-Rescue-Sequel-Comparison.csv').open('w',encoding='utf-8-sig',newline='')as f:
 w=csv.writer(f);w.writerow(['id','名前','役割','レア','定数','現行score','新石score','新石差','技能score','技能差','誓約leader強制score','誓約leader強制差','新石選択保持score','新石選択保持差','技能選択保持差','誓約選択保持差'])
 for c in per:w.writerow([c['id'],c['name'],c['role'],c['rarity'],c['constant'],c['native']['score'],c['flat-gem']['score'],c['flat-gem']['scoreGain'],c['guard-counter']['score'],c['guard-counter']['scoreGain'],c['leader_pledge']['score'],c['leader_pledge']['scoreGain'],c['flat-gem-optional']['score'],c['flat-gem-optional']['scoreGain'],c['guard-counter-optional']['scoreGain'],c['leader_pledge-optional']['scoreGain']])
for k,m in results.items():print(k,{x:round(m[x],5)for x in ['meanScore','withinRoleSD','bottomMean','topMean','meanWinRate']},m.get('sdChangeInterval'))
print('STAGE1 DATASET BATTLES',sum(json.loads(p.read_text())['trials']for p in B.glob('screen-*.json'))+sum(d['trials']for d in raw.values())+json.loads((B/'native-screen.json').read_text())['trials']+json.loads((B/'native-self-screen.json').read_text())['trials'])
