from pathlib import Path
import json,collections,statistics,csv
import numpy as np
B=Path('artifacts/rescue-sequel/benchmark');P=json.loads((B/'stage2-protocol.json').read_text());S=json.loads((B/'stage2-selection.json').read_text());R={c['id']:c for c in json.loads(Path('artifacts/character-ranking-v1/characters.json').read_text())};ctx=[(c,s)for c in ['early','developed']for s in ['event-whiteflower-path','ivory-tower-001','ivory-tower-010']];rng=np.random.default_rng(20261102);weights=rng.multinomial(30,np.ones(30)/30,size=2000).T/30
out={'source':P['source'],'scope':'independent exploration of existing stones and alternate role assignment; new skills are not applied','protocol':P,'selection':S,'contexts':[{'core':c,'scene':s}for c,s in ctx],'scopes':{},'limits':P['limits'],'nativeParity':json.loads((B/'stage2-native-parity.json').read_text())}
for scope in ['main','auxiliary']:
 d=json.loads((B/f'stage2-heldout-{scope}.json').read_text());ids=S['scopes'][scope]['candidates'];index={(r['id'],r['core'],r['scene'],r['mode']):r for r in d['rows']};choice=S['scopes'][scope]['choice'];modes={};aliases=['legacy-native','utility-native','chosen-fixed','chosen-opposite-policy'];stats={};resultsPer=[]
 for alias in aliases:
  a={k:np.zeros((len(ids),6,30))for k in ['score','win','survivors','progress','rounds']};counts=collections.Counter();actualModes={};per=[]
  for i,id in enumerate(ids):
   m='native-legacy'if alias=='legacy-native'else'native-utility'if alias=='utility-native'else choice[id];m=m.replace('-utility','-legacy')if alias=='chosen-opposite-policy'and m.endswith('-utility')else m.replace('-legacy','-utility')if alias=='chosen-opposite-policy'else m;actualModes[id]=m;ct=collections.Counter()
   for j,(c,s)in enumerate(ctx):
    row=index[(id,c,s,m)]
    for k in a:a[k][i,j]=[z[k]for z in row['results']]
    for z in row['results']:ct.update(z.get('counts',{}))
   counts.update(ct);per.append({'id':id,'name':R[id]['name'],'role':R[id]['role'],'mode':m,'meanScore':float(a['score'][i].mean()),'winRate':float(a['win'][i].mean()),'survivors':float(a['survivors'][i].mean()),'contextScores':[float(x)for x in a['score'][i].mean(axis=1)],'contextWins':[int(x)for x in a['win'][i].sum(axis=1)],'recordedCandidateActionSelections':dict(ct),'memoryActionSelections':{key:count for key,count in ct.items()if key.startswith('memory:')}})
  stats[alias]=a;ma=a['score'].mean(axis=(1,2));baseline=stats['legacy-native']['score'];delta=a['score']-baseline;ds=delta.mean(axis=1).mean(axis=0);modes[alias]={'meanScore':float(a['score'].mean()),'winRate':float(a['win'].mean()),'survivors':float(a['survivors'].mean()),'meanProgress':float(a['progress'].mean()),'meanRounds':float(a['rounds'].mean()),'gainVsNative':float(delta.mean()),'winRateGainVsNative':float(a['win'].mean()-stats['legacy-native']['win'].mean()),'meanGainSeedBlockInterval':[float(v)for v in np.quantile(ds@weights,[.025,.975])],'perCharacter':per,'actualModes':actualModes,'context':[{'core':c,'scene':s,'meanScore':float(a['score'][:,j].mean()),'winRate':float(a['win'][:,j].mean())}for j,(c,s)in enumerate(ctx)],'candidateMemoryActionSelections':{key:count for key,count in counts.items()if key.startswith('memory:')},'adverseCharacters':int(np.sum(ma<baseline.mean(axis=(1,2))-1e-9))}
 per=[]
 for i,id in enumerate(ids):
  cc={alias:modes[alias]['perCharacter'][i]for alias in aliases};delta=stats['chosen-fixed']['score'][i]-stats['legacy-native']['score'][i];per.append({'id':id,'name':R[id]['name'],'constant':R[id]['strength']/10,'choice':choice[id],'nativeScore':cc['legacy-native']['meanScore'],'chosenScore':cc['chosen-fixed']['meanScore'],'gain':float(delta.mean()),'winRateGain':cc['chosen-fixed']['winRate']-cc['legacy-native']['winRate'],'scoreGainInterval':[float(v)for v in np.quantile(delta.mean(axis=0)@weights,[.025,.975])],'scorePolicyContributionSameChosenGem':cc['chosen-fixed']['meanScore']-cc['chosen-opposite-policy']['meanScore'],'contextGains':[float(v)for v in delta.mean(axis=1)]})
 screen={m:{'meanScore':statistics.mean(S['scopes'][scope]['perCharacterScreen'][id][m]['meanScore']for id in ids),'winRate':statistics.mean(S['scopes'][scope]['perCharacterScreen'][id][m]['winRate']for id in ids)}for m in P['modes']}
 out['scopes'][scope]={'candidates':ids,'n':len(ids),'trials':d['trials'],'screenModes':screen,'modes':modes,'perCharacter':per,'screenTrials':len(ids)*60*8}
 print(scope,[(m,round(v['meanScore'],5),round(v['winRate']*100,5),round(v['gainVsNative'],5),v['meanGainSeedBlockInterval'])for m,v in modes.items()]);print('PER',[(c['id'],c['choice'],round(c['gain'],5))for c in per])
raw=json.loads((B/'shatter-exploration.json').read_text());summ=[]
for r in raw['rows']:
 counts=collections.Counter()
 for z in r['results']:counts.update(z.get('counts',{}))
 summ.append({k:r[k]for k in ['id','core','scene','policy']}|{'wins':sum(z['win']for z in r['results']),'total':len(r['results']),'meanScore':statistics.mean(z['score']for z in r['results']),'candidateActionSelections':dict(counts)})
out['shatterExploration']={'trials':raw['trials'],'scope':raw['scope'],'rows':summ};out['trials']=sum(s['trials']+s['screenTrials']for s in out['scopes'].values())+raw['trials'];(B/'stage2-analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
with(B/'Existing-Gems-and-Auxiliary-Comparison.csv').open('w',encoding='utf-8-sig',newline='')as f:
 w=csv.writer(f);w.writerow(['配置','ID','名前','定数','選択条件','元装備score','選択score','差','勝率差','差CI下','差CI上','同じ石の操作方針寄与'])
 for scope,s in out['scopes'].items():
  for c in s['perCharacter']:w.writerow([scope,c['id'],c['name'],c['constant'],c['choice'],c['nativeScore'],c['chosenScore'],c['gain'],c['winRateGain'],*c['scoreGainInterval'],c['scorePolicyContributionSameChosenGem']])
print('STAGE2 DATASET BATTLES',out['trials'])
