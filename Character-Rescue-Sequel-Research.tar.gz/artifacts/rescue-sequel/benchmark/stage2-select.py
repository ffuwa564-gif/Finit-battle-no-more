from pathlib import Path
import json,statistics
B=Path('artifacts/rescue-sequel/benchmark');P=json.loads((B/'stage2-protocol.json').read_text());modes=P['modes'];out={'frozenBeforeHeldout':True,'screenSeeds':P['screenSeeds'],'criterion':P['selection'],'scopes':{}}
for scope in ['main','auxiliary']:
 ids=P['mainCandidates']if scope=='main'else P['auxiliaryCandidates'];data={m:json.loads((B/f'stage2-screen-{scope}-{m}.json').read_text())for m in modes};assert all(d['trials']==len(ids)*60 for d in data.values());per={id:{}for id in ids}
 for m,d in data.items():
  for id in ids:
   rs=[z for r in d['rows']if r['id']==id for z in r['results']];per[id][m]={'meanScore':statistics.mean(z['score']for z in rs),'winRate':statistics.mean(z['win']for z in rs),'total':len(rs)}
 choices={id:sorted(modes,key=lambda m:(-per[id][m]['meanScore'],modes.index(m)))[0]for id in ids}
 out['scopes'][scope]={'candidates':ids,'perCharacterScreen':per,'choice':choices}
(B/'stage2-selection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
for scope,s in out['scopes'].items():
 print(scope,s['choice'])
 print('MEANS',[(m,round(statistics.mean(s['perCharacterScreen'][id][m]['meanScore']for id in s['candidates']),4))for m in modes])
