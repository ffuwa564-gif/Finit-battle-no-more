from pathlib import Path
B=Path('artifacts/rescue-sequel');p=Path('artifacts/tower-redesign/edit.py').read_text().replace('artifacts/tower-redesign','artifacts/rescue-sequel').replace('STILLVEIL-Tower-Redesign-720p.mp4','STILLVEIL-Character-Rescue-Sequel-720p.mp4')
for a,b in [('STILLVEIL  /  IVORY TOWER DESIGN','STILLVEIL  /  CHARACTER RESCUE WORKSHOP II'),('白亜の塔・ハードコア改良会議','弱めの仲間を救う・徹底研究②'),('71種類の敵・100層の案','12案を試作・再検証'),('前回の59層も踏まえる','117,040戦の比較'),('全編成の限界ではない','全ビルドの最適ではない'),('難しさと、面白さを問う','救済工房・第二回'),('編成・定数・対策\\N初案の失敗も検討','本人の技・王冠・石\\N失敗からもう一度作る')]:p=p.replace(a,b)
p=p.replace("if sec['id'] in ['record']:","if sec['id'] in []:")
p=p.replace("['experiment','result','critique']","['screen','stone-result','counter-result','aftercare','ablation','rebuild','shatter-result']").replace("['audit','record','constant','curve','adapter']","['recap','noelle-note','yardstick','protocol','choice','crown-result','existing-result']")
# Spoken Japanese decimals become compact display numerals. Narration stays natural.
idx=p.index('srt=[];counter=0')
fn='''def display_text(s):
 for a,b in [('いってんよん','1.4'),('いってんに','1.2'),('にてんぜろ','2.0'),('十一万七千四十戦','117,040戦'),('七万八千九百戦','78,900戦')]:s=s.replace(a,b)
 digits={'零':'0','〇':'0','一':'1','二':'2','三':'3','四':'4','五':'5','六':'6','七':'7','八':'8','九':'9'}
 hira={'きゅう':'九','なな':'七','はち':'八','ろく':'六','よん':'四','さん':'三','ぜろ':'零','れい':'零','いち':'一','に':'二','ご':'五'}
 ht='|'.join(hira);dt='零〇一二三四五六七八九';pattern=re.compile('((?:['+dt+'十百千万]|'+ht+')+)(?:点|てん)((?:['+dt+']|'+ht+')+)')
 def kan(s):
  for x,y in hira.items():s=s.replace(x,y)
  return s
 def integer(s):
  s=kan(s)
  if not any(x in s for x in '十百千万'):return ''.join(digits[x]for x in s)
  total=0;part=0;digit=0
  for c in s:
   if c in digits:digit=int(digits[c])
   elif c=='万':total+=(part+digit)*10000;part=0;digit=0
   else:part+=(digit or 1)*{'十':10,'百':100,'千':1000}[c];digit=0
  return str(total+part+digit)
 def repl(m):return integer(m.group(1))+'.'+''.join(digits[x]for x in kan(m.group(2)))
 return pattern.sub(repl,s)
'''
p=p[:idx]+fn+p[idx:]
a=p.index("  text=l['text'].replace(");b=p.index('\n  while len(text)>60:',a);p=p[:a]+"  text=display_text(l['text']);parts=[]"+p[b:]
a=p.index('maps={');b=p.index('\nSFX=',a)
p=p[:a]+'''maps={
'intro':[card('intro',.55),card('diagram-different-jobs',.45)],
'recap':[card('diagram-prior-two-gaps',.6),card('recap',.4)],
'noelle-note':[card('noelle-note',.7),dict(**{**profile('noelle'),'weight':.3})],
'weak':seq('weak',[(0,card('weak',1)),(at('weak','待って。'),profile('flora-standard')),(within('weak','覚醒ノエル'),profile('noelle-awakened')),(at('weak','最大体力の割合'),card('weak',1)),(at('weak','目標は、'),card('diagram-different-jobs',1))]),
'yardstick':[card('diagram-four-criteria',.7),card('yardstick',.3)],
'damage':[card('damage-threshold',.65),card('damage',.35)],
'three-tools':[card('diagram-levers',.7),card('three-tools',.3)],
'boundaries':[card('diagram-growth-cliff',.55),card('diagram-trigger-cap',.45)],
'catalog':[card('catalog',.7),card('diagram-evidence-ladder',.3)],
'flat-stone':[card('stone-flow-flat',.65),card('flat-stone',.35)],
'shared-stone':[card('stone-flow-shared',.65),card('shared-stone',.35)],
'noelle':[dict(**{**profile('noelle'),'weight':.35}),card('noelle',.65)],
'healing':[dict(**{**profile('hebe'),'weight':.35}),card('healing',.65)],
'guardian':[dict(**{**profile('haniyasu'),'weight':.32}),card('guardian',.68)],
'control':seq('control',[(0,card('control',1)),(at('control','ここで、ティッカ'),profile('tikka')),(at('control','しかも、封印'),card('diagram-jam-scope',1))]),
'support':[dict(**{**profile('lucielle'),'weight':.35}),card('support',.65)],
'leader-formation':[card('leader-formation',.6),card('diagram-crown-cost',.4)],
'leader-pledge':[card('leader-pledge',.65),card('diagram-trigger-cap',.35)],
'protocol':[card('protocol',.6),card('diagram-evidence-ladder',.4)],
'screen':[card('screen-skill',.55),card('screen-leader',.45)],
'stone-result':[card('summary-table',.5),card('sd-interval',.5)],
'choice':[card('choice',.4),card('individual-changes',.3),card('bottom-top',.3)],
'counter-result':[card('counter-result',.6),card('diagram-three-failure-types',.4)],
'crown-result':[card('crown-waterfall',.7),card('crown-result',.3)],
'local-success':[card('leader-stress',.7),card('local-success',.3)],
'aftercare':[card('aftercare',.22),card('aftercare-cause',.78)],
'old-tools':[card('diagram-existing-support-stones',.55),card('diagram-existing-conditional-stones',.45)],
'native-niche':[dict(**{**profile('nike-standard'),'weight':.35}),card('diagram-shatter-niche',.65)],
'ablation':[card('stone-waterfall',.7),card('diagram-stone-cost',.3)],
'rebuild':[card('healer-rebuild',.7),card('healer-individual',.3)],
'existing-result':[card('existing-gem-check',.4),card('existing-individual',.6)],
'deputy':[card('deputy',.55),card('existing-gem-check',.45)],
'shatter-result':[card('shatter-operation',.7),card('diagram-shatter-niche',.3)],
'future':seq('future',[(0,card('future',1)),(at('future','リオラたちは'),profile('liora')),(at('future','石、技、王冠'),card('diagram-trigger-cap',1)),(at('future','本人だけに効果'),card('future',1))]),
'verdict':[card('verdict-table',.55),card('diagram-acquisition',.45)],
'ending':[card('ending',.6),card('verdict-table',.4)]
}'''+p[b:]
p=p.replace('def seq(id,items):',"def within(id,phrase):\n sec=next(s for s in N['sections'] if s['id']==id)\n l=next(l for l in sec['lines'] if phrase in l['text'])\n return l['start']-sec['start']+l['duration']*l['text'].index(phrase)/len(l['text'])\ndef seq(id,items):")
# These native UI profiles are visual references; no tap sounds under the discussion.
p=p.replace("O=Path('/workspace/Finit-battle-no-more/artifacts/tower-diary-01')","for m in shots.values():m['audio']=None\nO=Path('/workspace/Finit-battle-no-more/artifacts/tower-diary-01')")
(B/'edit.py').write_text(p)
print('Prepared final36-chapter edit')
