from pathlib import Path
import json,runpy
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image,ImageDraw
M=runpy.run_path('artifacts/rescue-sequel/prepare-graphs.py');B=M['B'];C=M['C'];G=M['G'];A=M['A'];base=M['base'];text=M['text'];foot=M['foot'];chart=M['chart'];save=M['save'];H=json.loads((B/'skills/stage2/analysis.json').read_text());E=json.loads((B/'benchmark/stage2-analysis.json').read_text())
fig,ax=chart();vals=[A['modes']['native']['bottomMean'],A['modes']['flat-gem']['bottomMean']-A['flatMechanismAblation']['flat-gem']['bottomMechanismGain'],A['modes']['flat-gem']['bottomMean']];ax.bar([0,1,2],vals,color=['#aac4d8','#cea1b2','#dfbb7d'],width=.63);ax.set_ylim(0,50);ax.set_xticks([0,1,2],['元の優先装備','既存の残響\n同じ装備・操作の対照','灯芯の補助石\n新しい参照補助']);ax.set_ylabel('固定下位20種の平均スコア');
for j,z in enumerate(vals):ax.text(j,z+.6,f'{z:.3f}',ha='center',fontsize=14,fontweight='bold')
ax.text(.5,47,f'付替え {vals[1]-vals[0]:+.3f}',c='#deb4c1',ha='center');ax.text(1.9,47,f'新機構 {vals[2]-vals[1]:+.3f}',c='#dfbb7d',ha='center');save(fig,'stone-waterfall','石も、効果と持ち替えの代価に分ける','同じ確認用30条件・6文脈。全石最適化をした現行装備との比較ではありません。')
fig,ax=chart();keys=['off','aftercare','thin-shield-ai','aftercare-upgrade','aftercare-heal','aftercare-gauge'];labels=['現行','追加障壁\n旧試案','張替判断\nのみ','障壁＋\n張替判断','小回復\n加算','被弾充填\n診断'];wins=[H['modes'][k]['wins']for k in keys];ax.bar(np.arange(6),wins,color=['#a9c2d8','#d098aa','#a9c2d8','#cbb99b','#b3d3bf','#b3a4cc']);ax.set_ylim(0,400);ax.set_ylabel('確認用720戦中の勝数');ax.set_xticks(np.arange(6),labels)
for j,z in enumerate(wins):ax.text(j,z+5,str(z),ha='center',fontsize=14,fontweight='bold')
ax.grid(axis='y',alpha=.12);save(fig,'healer-rebuild','再試作：薄い障壁と仲間の判断を分離する','固定4回復役×6文脈×未使用30条件。全69種の結果ではありません。')
fig,ax=chart();ids=['veil-priestess','hebe','hebe-standard','flora-standard'];labels=['帳の巫女','ヘベ','通常姿ヘベ','通常姿フローラ'];x=np.arange(4);a=H['modes']['aftercare-heal']['characters'];b=H['modes']['aftercare-upgrade']['characters'];ax.bar(x-.18,[a[i]['delta']for i in ids],width=.35,color='#dfbd83',label='小回復加算');ax.bar(x+.18,[b[i]['delta']for i in ids],width=.35,color='#a3c3d6',label='障壁＋張替判断');ax.set_xticks(x,labels);ax.axhline(0,color='#d7dfe2',lw=1);ax.set_ylabel('現行からの平均スコア変化（点）');ax.legend(frameon=False);ax.grid(axis='y',alpha=.13);save(fig,'healer-individual','平均が上がっても、ヘベ本人は救えていない','同じ再案でも個別に違う。各キャラ6文脈×30条件＝180戦。')
fig,ax=chart();ys=[0,1];labels=['元の役割枠20種での持替え','副官枠6種での持替え'];
for j,k in enumerate(['main','auxiliary']):
 m=E['scopes'][k]['modes']['chosen-fixed'];v=m['gainVsNative'];lo,hi=m['meanGainSeedBlockInterval'];ax.errorbar(v,j,xerr=[[v-lo],[hi-v]],fmt='o',c='#dfbd83'if j==0 else'#cf9fb3',capsize=6,lw=2);ax.text(v,j+.2,f'{v:+.3f}点',ha='center',fontsize=12)
ax.set_yticks(ys,labels);ax.set_ylim(-.5,1.6);ax.invert_yaxis();ax.axvline(0,color='#c9d4df',ls='--');ax.set_xlabel('各配置の元装備からのスコア差と、seed組95%区間');ax.grid(axis='x',alpha=.14);save(fig,'existing-gem-check','調整で選んだ既存石は、別条件でも働く？','副官化そのものの効果ではなく、同じ副官編成内の石の持替えを比較。')
fig,ax=chart();pc=E['scopes']['main']['perCharacter'];ids=['kukurihime','tikka','iris','hebe','hebe-standard'];rows=[next(c for c in pc if c['id']==id)for id in ids];labels=['ククリヒメ','ティッカ','イリス','ヘベ','通常姿ヘベ'];gain=[r['gain']for r in rows];ax.barh(np.arange(5),gain,color=['#dfbd83'if v>=0 else'#ca9eb1'for v in gain]);ax.set_yticks(np.arange(5),labels);ax.invert_yaxis();ax.axvline(0,color='#cad5df');ax.set_xlabel('調整時に選んだ石・操作を固定した時のスコア差');ax.grid(axis='x',alpha=.13);save(fig,'existing-individual','既存石にも、相性の良い子と悪い子がいる','見せる5例は全員救済の証拠ではありません。全20種の表も公開します。')
fig,ax=chart();x=np.arange(2);ax.bar(x-.17,[5,0],width=.34,color='#a5bfd3',label='従来の注文');ax.bar(x+.17,[9,2],width=.34,color='#dfbd83',label='障壁時は破砕優先');ax.set_xticks(x,['通常姿ニケ','和装ニケ']);ax.set_ylim(0,40);ax.set_ylabel('凍暁・成長後の編成 40条件中の勝数');ax.legend(frameon=False);ax.grid(axis='y',alpha=.12)
for j,(u,v)in enumerate([(5,9),(0,2)]):ax.text(j-.17,u+.6,str(u),ha='center',fontweight='bold');ax.text(j+.17,v+.6,str(v),ha='center',fontweight='bold')
save(fig,'shatter-operation','既存の長所を使う注文で、少し届いた','補助640戦のうち凍暁・成長後の抜粋。全69種の散らばりには混ぜない。')
# Final research verdict with no release claims.
im,d=base('救済工房・審査票：何を次へ持ち帰る？')
rows=[('小さな次候補','限定T3の灯芯／個別の回復再案','#b5d4c1'),('実用差が小さい','守りの返し／調整数値と生存条件を再検討','#d9c18e'),('全体採用は不成立','王冠4案／元の王冠を手放す代価が大きい','#d2a0b3'),('相性を直して再試作','追加の薄盾と、仲間の障壁選択','#b2c8dc'),('既存の得意も活用','破砕の注文／星炉等の個別相性を検討','#b5d4c1')]
for j,(title,s,col)in enumerate(rows):
 y=120+j*65;d.rounded_rectangle((25,y-3,735,y+55),radius=8,fill='#203144');text(d,(38,y),title,20,col,True,maxw=255);text(d,(38,y+28),s,20,maxw=680)
foot(d,'全案は未実装。条件付きの候補を残す判定で、配信版への採用決定ではありません。');im.save(C/'verdict-table.png')
print('Stage2 graphs, ablation and verdict prepared')
