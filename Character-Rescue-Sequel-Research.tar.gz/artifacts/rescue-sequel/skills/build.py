from pathlib import Path
import json,difflib
B=Path('artifacts/rescue-sequel/skills');native=Path('src/domain/engine.ts').read_text();s=native
head='''// Proposal-only rescue laboratory. This module is never imported by the shipped game.
export let prototypeMode='off';
let prototypeTargets=new Set<string>();
let prototypeCandidate='';
let prototypeStats:Record<string,number>={};
export function configurePrototype(mode:string,targets:string[]=[],candidateId=''){prototypeMode=mode;prototypeTargets=new Set(targets);prototypeCandidate=candidateId;prototypeStats={};}
export function getPrototypeStats(){return {...prototypeStats};}
function note(key:string,value=1){prototypeStats[key]=(prototypeStats[key]??0)+value;}
function rescueActor(actor:Unit){return actor.side==='party'&&actor.characterId===prototypeCandidate&&prototypeTargets.has(actor.characterId);}
function rescueStone(actor:Unit,content:Content){const d=content.characters.find(c=>c.id===actor.characterId);return actor.side==='party'&&actor.characterId===prototypeCandidate&&!!d&&d.strength<=14&&['R','SR'].includes(d.rarity);}
export function applyPrototypeOpening(_battle:Battle,_content:Content){}
function prototypeShield(target:Unit,battle:Battle,value:number,key:string){const old=(target.barrierUntil??-1)>=battle.round?target.barrier??0:0;const capped=Math.min(60,Math.floor(target.maxHp*.2),Math.max(0,Math.floor(value)));if(capped>old){target.barrier=capped;target.barrierUntil=Math.max(target.barrierUntil??0,battle.round+1);note(key);note(key+'Amount',capped-old);}}
'''
s=head+s
old='''        const hit = damage(actor, target, numerator, denominator, battle, action.template !== 'area', content, action.template === 'pierce' || action.template === 'dawn', action.template === 'shatter', action.template === 'dawn', potency * executionPower(target), coordination); amount += hit.amount; absorbed += hit.absorbed; shattered += hit.shattered; targetIds.push(hit.unit.uid);'''
new='''        let hitActor=actor;
        if(['flat-gem','shared-gem'].includes(prototypeMode)&&rescueStone(actor,content)&&memoryDef?.id==='echo-shard'&&memoryGem?.variant==='pure'&&memoryRoll?.power===80&&memoryRoll?.trait==='none'&&memoryRoll?.value===0&&!action.ultimate&&!action.forcedBy){
          const peers=alive(battle.units,'party').filter(u=>u.uid!==actor.uid);
          const shared=peers.length?Math.floor(peers.reduce((v,u)=>v+u.attack,0)/peers.length*.9):actor.attack;
          const attack=prototypeMode==='flat-gem'?Math.max(actor.attack,Math.min(65,actor.attack+24)):Math.max(actor.attack,Math.min(70,shared));
          hitActor={...actor,attack};if(attack>actor.attack){note('stoneReference');note('stoneReferenceDelta',attack-actor.attack);}
        }
        const hit = damage(hitActor, target, numerator, denominator, battle, action.template !== 'area', content, action.template === 'pierce' || action.template === 'dawn', action.template === 'shatter', action.template === 'dawn', potency * executionPower(target), coordination); amount += hit.amount; absorbed += hit.absorbed; shattered += hit.shattered; targetIds.push(hit.unit.uid);'''
assert s.count(old)==1;s=s.replace(old,new)
marker='''    if (!action.ultimate && !action.forcedBy) gainUltimate(actor, 25);
    clearInvalidGuards(battle);'''
hook='''    if (!action.ultimate && !action.forcedBy) gainUltimate(actor, 25);
    // Individual ordinary-skill proposals never attach to memory skills or personal ultimates.
    if(rescueActor(actor)&&action.skill&&!memoryDef&&!action.ultimate&&!action.forcedBy){
      if(prototypeMode==='area-mark'&&action.template==='area'&&action.targets.filter(u=>u.side==='enemy').length>=2){
        for(const target of action.targets.filter(u=>u.side==='enemy'&&u.hp>0)){
          const active=(target.debuffUntil??-1)>=battle.round;target.debuffStrength=Math.max(active?target.debuffStrength??10:0,30);target.debuffUntil=Math.max(active?target.debuffUntil??0:0,battle.round+1);note('areaMark');
        }
      }
      if(['overheal','aftercare'].includes(prototypeMode)&&['heal','mend_pair'].includes(action.template)){
        for(const target of action.targets.filter(u=>u.side==='party'&&u.hp>0)){
          note('eligibleHealTargets');const old=before.find(u=>u.uid===target.uid)!;
          if(prototypeMode==='aftercare')prototypeShield(target,battle,Math.min(55,target.maxHp*.18),'aftercareShield');
          else {const raw=Math.max(1,Math.floor(effectiveAttack(actor,battle.round)*(action.skill.strength+30)/(action.template==='heal'?20:40)*potency));const healed=target.hp-old.hp;const excess=Math.max(0,raw-healed);note('healActions');if(excess>0)prototypeShield(target,battle,excess*.6,'overhealShield');}
        }
      }
      if(prototypeMode==='control-fallback'&&isAilment(action.template)&&statusAction==='resist'){
        const target=action.targets[0];const old=before.find(u=>u.uid===target.uid)!;note((old.statusWardUntil??-1)>=battle.round?'controlWardResist':hasAilment(old)?'controlExistingResist':'controlRollResist');
        const active=(target.debuffUntil??-1)>=battle.round;target.debuffStrength=Math.max(active?target.debuffStrength??10:0,20);target.debuffUntil=Math.max(active?target.debuffUntil??0:0,battle.round+1);note('fallbackDebuff');
      }
      if(prototypeMode==='buff-preserve'&&action.template==='buff'){
        const target=action.targets[0];const old=before.find(u=>u.uid===target.uid)!;if((old.buffUntil??-1)>=battle.round&&(old.buffStrength??10)>(target.buffStrength??10)){target.buffStrength=old.buffStrength;target.buffUntil=Math.max(target.buffUntil??0,old.buffUntil??0);note('preservedBuff');}
      }
    }
    clearInvalidGuards(battle);'''
assert s.count(marker)==1;s=s.replace(marker,hook)
# A counter follows an actual intercepted ordinary HP hit. One per guardian per round,
# no counter-on-counter trigger because this hook lives in resolveRound, not damage().
marker='''    const settled = settleAction(battle, content, before);'''
hook='''    if(prototypeMode==='guard-counter'&&actor.side==='enemy'&&!action.power&&!action.clockFinale&&amount>0&&action.targets.length===1){
      const guardian=battle.units.find(u=>rescueActor(u)&&u.hp>0&&targetIds.includes(u.uid)&&action.targets[0].uid!==u.uid&&before.some(old=>old.uid===u.uid&&old.guardTarget===action.targets[0].uid&&(old.guardUntil??-1)>=battle.round&&old.hp>u.hp));
      const record=(battle as Battle&{prototypeCounterTurns?:Record<string,string>});const key=`${battle.wave}:${battle.round}`;
      if(guardian&&record.prototypeCounterTurns?.[guardian.uid]!==key){record.prototypeCounterTurns??={};record.prototypeCounterTurns[guardian.uid]=key;
        const reference={...guardian,attack:Math.min(60,Math.floor(guardian.maxHp*.2))};const counter=damage(reference,actor,100,100,battle,true,content);note('guardCounter');note('guardCounterDamage',counter.amount);clearInvalidGuards(battle);emit(battle,{kind:'attack',actorId:guardian.uid,targetIds:[counter.unit.uid],amount:counter.amount,text:'救済試案 — 守りの返し',unitsAfter:clone(battle.units)});
      }
    }
    const settled = settleAction(battle, content, before);'''
assert s.count(marker)>=1;s=s.replace(marker,hook,1)
(B/'sandbox/src/domain/engine.ts').write_text(s)
(B/'engine.patch').write_text(''.join(difflib.unified_diff(native.splitlines(True),s.splitlines(True),fromfile='a/src/domain/engine.ts',tofile='b/src/domain/engine.ts')))
rows=[
('flat-gem','灯芯の補助石','gem','echo-shard','R/SR and base constant<=1.4; active wearer only','echo attack reference = max(own unbuffed battle attack after leader stat bonus,min(65,own unbuffed battle attack after leader stat bonus+24)); native cooldown3 and35% nonrecursive echo; fixed crafted T3 proxy power80/traitnone/pure only; no opening barrier'),
('shared-gem','分灯の共鳴石','gem','echo-shard','R/SR and base constant<=1.4; active wearer only','echo attack reference = max(own unbuffed battle attack after leader stat bonus,min(70,floor(mean other living ally unbuffed battle attack after leader stat bonus*0.9))); native cooldown3 and35% nonrecursive echo; fixed crafted T3 proxy power80/traitnone/pure only; no opening barrier'),
('area-mark','星図の露出','skill',None,'frozen previous bottom20 and current candidate only','ordinary personal area hitting>=2 enemies leaves strength30 defense debuff through next round on surviving targets; preserves stronger effect'),
('overheal','余光の包帯','skill',None,'frozen previous bottom20 and current candidate only','ordinary personal heal/mend_pair excess raw healing*0.6 -> barrier capped min60,20% recipient maxHP; max with existing, through next round'),
('aftercare','祈りの余韻','skill',None,'frozen previous bottom20 and current candidate only','ordinary personal heal/mend_pair grants barrier min55,18% recipient maxHP; max with existing, through next round; no charge'),
('guard-counter','守りの返し','skill',None,'frozen previous bottom20 and current candidate only','after actual intercepted ordinary enemy HP damage and surviving, one counter per guardian per round, reference attack min60,20% guardian maxHP; native armor/barrier/guard apply; no counter recursion; no bossStrike or bits hook'),
('control-fallback','再診の呪印','skill',None,'frozen previous bottom20 and current candidate only','ordinary personal ailment failed (including random miss) -> strength20 defense debuff next round, max with stronger; no effect on success; ward/existing/random failures counted separately; not jam'),
('buff-preserve','重ならない祈り','skill',None,'frozen previous bottom20 and current candidate only','ordinary personal buff cannot lower existing stronger buff and duration; no free extension beyond max old/native duration; no added gauge'),
]
manifest={'proposalOnly':True,'source':'616a074','engine':'artifacts/rescue-sequel/skills/sandbox/src/domain/engine.ts','interface':{'configure':'configurePrototype(mode,targets=[],candidateId="")','stats':'getPrototypeStats()','opening':'applyPrototypeOpening(battle,content) is no-op'},'modes':[dict(id=id,name=name,kind=kind,candidateGem=gem,targetScope=target,description=desc,ready=True)for id,name,kind,gem,target,desc in rows],'warnings':['No game main or live content changed','Fixed bottom20 skill targets are a research instrument for individualized redesign, not a proposed invisible equip restriction','Stone cutoff is explicit but still creates an eligibility cliff; exact UI/acquisition unresolved','Effects keep the original ordinary skill action and cooldown; no permanent stats changed','No claim that these are all possible rescue designs']}
(B/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print('8 modes built')
