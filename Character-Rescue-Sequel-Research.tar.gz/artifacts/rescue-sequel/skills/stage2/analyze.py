import json,statistics
from pathlib import Path
import numpy as np
B=Path('artifacts/rescue-sequel/skills/stage2');H=json.loads((B/'heldout.json').read_text());S=json.loads((B/'screen.json').read_text());out={'proposalOnly':True,'stage1SourceUnchanged':True,'screenTrials':S['trials'],'heldoutTrials':H['trials'],'totalTrials':S['trials']+H['trials'],'heldoutSeeds':H['seeds'],'scope':'Focused follow-up on four fixed weak healers and six fixed contexts. No roster-wide balance or all possible builds claim. All modes compared, no heldout selection. Seed-block bootstrap reflects conditional random-seed variability only.','modes':{}}
def key(r,x):return(r['id'],r['core'],r['scene'],x['seed'])
base={key(r,x):x for r in H['rows']if r['mode']=='off'for x in r['results']};rng=np.random.default_rng(20261101)
for mode in H['modes']:
 rows=[r for r in H['rows']if r['mode']==mode];rs=[x for r in rows for x in r['results']];deltas=[x['score']-base[key(r,x)]['score']for r in rows for x in r['results']];seedmeans=np.array([statistics.mean(x['score']-base[key(r,x)]['score']for r in rows for x in r['results']if x['seed']==seed)for seed in H['seeds']]);boot=np.mean(rng.choice(seedmeans,(5000,len(seedmeans)),replace=True),axis=1);triggers={}
 for x in rs:
  for k,v in x['triggers'].items():triggers[k]=triggers.get(k,0)+v
 chars={id:{'meanScore':statistics.mean(x['score']for r in rows if r['id']==id for x in r['results']),'delta':statistics.mean(x['score']-base[key(r,x)]['score']for r in rows if r['id']==id for x in r['results']),'wins':sum(x['win']for r in rows if r['id']==id for x in r['results']),'total':sum(len(r['results'])for r in rows if r['id']==id)}for id in H['subjects']}
 out['modes'][mode]={'meanScore':statistics.mean(x['score']for x in rs),'scoreDelta':statistics.mean(deltas),'wins':sum(x['win']for x in rs),'total':len(rs),'winRate':sum(x['win']for x in rs)/len(rs),'pairedImproved':sum(d>0 for d in deltas),'pairedWorsened':sum(d<0 for d in deltas),'pairedSame':sum(d==0 for d in deltas),'seedBlockScoreDelta95CI':list(np.percentile(boot,[2.5,97.5])),'triggers':triggers,'characters':chars}
(B/'analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps({m:{k:v[k]for k in ['meanScore','scoreDelta','wins','total','seedBlockScoreDelta95CI']}for m,v in out['modes'].items()},indent=2));
