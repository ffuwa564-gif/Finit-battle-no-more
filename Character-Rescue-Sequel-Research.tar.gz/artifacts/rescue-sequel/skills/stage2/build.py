from pathlib import Path
import json,difflib,hashlib
B=Path('artifacts/rescue-sequel/skills/stage2');old=Path('artifacts/rescue-sequel/skills/sandbox/src/domain/engine.ts').read_text();s=old
s="let stage2Mode='off';\n"+s
s=s.replace("prototypeMode=mode;prototypeTargets=", "stage2Mode=mode;prototypeMode=['aftercare-upgrade','aftercare-gauge'].includes(mode)?'aftercare':mode;prototypeTargets=")
s=s.replace("target.barrierUntil=Math.max(target.barrierUntil??0,battle.round+1);note(key);", "target.barrierUntil=Math.max(target.barrierUntil??0,battle.round+1);if(stage2Mode==='aftercare-gauge')(target as any).prototypeAftercare={wave:battle.wave,expiry:target.barrierUntil,baselineRemaining:old};note(key);")
oldex="  const exposed = allies.filter(unit => !(unit.barrier && (unit.barrierUntil ?? -1) >= battle.round)).sort(lowerHP)[0];"
newex="  const exposed = allies.filter(unit => !(unit.barrier && (unit.barrierUntil ?? -1) >= battle.round)||(['thin-shield-ai','aftercare-upgrade'].includes(stage2Mode)&&(unit.barrier??0)<unit.maxHp*.2)).sort(lowerHP)[0];"
assert s.count(oldex)==1;s=s.replace(oldex,newex)
marker="    // Individual ordinary-skill proposals never attach to memory skills or personal ultimates."
extra="""    if(['thin-shield-ai','aftercare-upgrade'].includes(stage2Mode)&&actor.side==='party'&&action.template==='barrier'){
      const target=action.targets[0],old=before.find(u=>u.uid===target.uid);if(old&&(old.barrier??0)>0&&(old.barrierUntil??-1)>=battle.round&&(old.barrier??0)<old.maxHp*.2)note('thinShieldUpgrade');
    }
"""
s=s.replace(marker,extra+marker)
marker="    if(rescueActor(actor)&&action.skill&&!memoryDef&&!action.ultimate&&!action.forcedBy){"
extra="""    if(stage2Mode==='aftercare-heal'&&rescueActor(actor)&&action.skill&&!memoryDef&&!action.ultimate&&!action.forcedBy&&['heal','mend_pair'].includes(action.template)){
      for(const target of action.targets.filter(u=>u.side==='party'&&u.hp>0)){const extra=Math.min(target.maxHp-target.hp,35,Math.floor(target.maxHp*.1));if(extra>0){target.hp+=extra;amount+=extra;note('aftercareExtraHeal');note('aftercareExtraHealAmount',extra);}}
    }
"""
s=s.replace(marker,extra+marker)
marker="    if (memoryDef?.id === 'shield-break') {"
extra="""    if(stage2Mode==='aftercare-gauge'&&(action.template==='barrier'||action.ultimate&&['tank','supporter'].includes(actorDef.role)))for(const target of action.targets)delete (target as any).prototypeAftercare;
"""
assert s.count(marker)==1;s=s.replace(marker,extra+marker)
marker="  if (actual > 0) gainUltimate(recipient, 10);"
extra="""  if(stage2Mode==='aftercare-gauge'&&recipient.side==='party'){
    const source=(recipient as any).prototypeAftercare;
    if(source&&source.wave===battle.wave&&source.expiry>=battle.round){
      if(actual===0&&amount>source.baselineRemaining){const prior=recipient.ultimateCharge??0;gainUltimate(recipient,10);note('compensatedHitGauge');note('compensatedHitGaugeAmount',(recipient.ultimateCharge??0)-prior);}
      source.baselineRemaining=Math.max(0,source.baselineRemaining-amount);
    }
  }
"""
assert s.count(marker)==1;s=s.replace(marker,extra+marker)
(B/'sandbox/src/domain/engine.ts').write_text(s);(B/'stage2.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='stage1-engine.ts',tofile='stage2-engine.ts')))
rows=[('aftercare-heal','祈りの後押し','候補本人の通常heal/mend_pairの回復後、最大HP10%・上限35を追加回復。障壁は付けない。通常技能は固定下位20のうち候補1名だけ。'),('thin-shield-ai','薄い障壁の更新AI','AIが障壁の対象を選ぶ時、最大HP20%未満の障壁は保護完了と扱わない。全味方の障壁選択の方針変更でありキャラ固有救済ではない。追加の回復障壁なし。'),('aftercare-upgrade','祈りの余韻＋更新AI','第1試案aftercareに上記薄盾更新AIを併用。AI単独との比較で救済効果と方針変更効果を分離する。'),('aftercare-gauge','被弾充填だけ補う反実仮想','診断専用。aftercare由来障壁がなければHP被害が発生した同じ一撃を、仮想の既存障壁残量で追跡し、完全吸収時に失った被弾10充填だけ補う。通常の新スキルとして採用を提案する案ではない。AIは旧まま。')]
m={'proposalOnly':True,'source':'616a074','stage1Unchanged':True,'engineSha256':hashlib.sha256(s.encode()).hexdigest(),'modes':[dict(id=id,name=name,description=desc)for id,name,desc in rows],'subjects':['veil-priestess','hebe','hebe-standard','flora-standard'],'contexts':'2 existing parties x event whiteflower / tower1 / tower10','screenSeeds':list(range(12001,12011)),'heldoutSeeds':list(range(15001,15031)),'choice':'All4 stages are compared; none selected on heldout. No stage1 seeds reused. Diagnostic gauge mode is not a gameplay-ready recommendation.'}
(B/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));print('stage2 built')
