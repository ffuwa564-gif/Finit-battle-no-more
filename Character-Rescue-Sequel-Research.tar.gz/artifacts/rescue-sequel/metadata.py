from pathlib import Path
import json,csv,shutil
B=Path('artifacts/rescue-sequel');A=json.loads((B/'benchmark/analysis.json').read_text());E=json.loads((B/'benchmark/stage2-analysis.json').read_text());H=json.loads((B/'skills/stage2/analysis.json').read_text());L=json.loads((B/'benchmark/trial-ledger.json').read_text());N=json.loads((B/'narration.json').read_text());root='https://raw.githubusercontent.com/ffuwa564-gif/Finit-battle-no-more/refs/heads/downloads/tower-diary-part1/'
notes='''STILLVEIL キャラクター救済工房②：弱めの仲間を救う研究・続編
ずんだもん×四国めたん／複数担当による監査・設計・比較・批評

【動画と研究の位置づけ】
対象ソース616a0747c4118a991770226d37347f34b31e2ec6（2026-11-01時点でmainと一致を確認）。前回キャラ性能差動画の続編。
ゲーム本体・main・itch.ioは変更していない。研究用sandbox・シミュレーション・動画・公開ダウンロード資料のみ。『候補として残す』は配信版へ採用した意味ではない。
全探索・絶対最適・全キャラ救済完了の主張はしない。実ユーザーの使用率・遊ぶ時間・愛着・継続率の改善も、この試算では測れていない。

【チームと問い】
担当を①前回と本体の監査、②通常技能/石の試作、③リーダー試作、④統一比較/既存石と操作の探索、⑤厳しい批評、⑥構成/図解、⑦統合・音声/動画/公開に分けた。
狙いは基礎定数を揃えることではなく、その子を入れて、元の得意や違う攻略の理由が生まれること。今回本人のstrengthは一切変えず、定数CV26.7%自体は変わらない。
効果が出るか、編成が良くなるか、上位だけに横取りされないか、王冠/装備/行動/入手の代価を四つに分ける。

【前回の再点検】
前回の役割内SD5.036→4.848は約3.7%縮小の小さな結果。元の低定数エレイン/通常フローラにも仕事があり、低定数=弱いという区切りは不十分。
前回初期ノエルのbound調整値37.1308→37.3072（+0.1764）は装備変更閾値>0.25点に届かず、確認用ではnative装備を保持。候補石を装備しても絶対無効と分かったわけではない。
前回tank枠の王冠は他役割と設定が異なるため、跨いだ点数で誰が一番弱いかは順位付けしない。
今回も初期リオラ/覚醒ノエルは『固定下位20への通常技能』の対象外。研究の対象をゲームの見えない弱者スコア制限として提案しているわけではない。

【12試作と機会費用】
石2案：固定T3 power80/pure/traitnone、CD3のecho-shardを研究用代理とし、35%の非再帰追撃を維持。R/SR・strength<=14（定数1.4以下）の候補本人が対象。25種類が装備可能。開幕障壁なし。
・灯芯の補助石：max(自分の参照ATK,min(65,自分の参照ATK+24))。
・分灯の共鳴石：max(自分の参照ATK,min(70,floor(他の生存味方の参照ATK平均×0.9)))。
ここで参照ATKは王冠の常時補正後のunit.attack、戦闘buff/加速の前。65/70は最終ダメージ上限ではない。既存の石を外して新石を使う行動も支払う。

通常技能6案：前回役割別の固定下位20種のうち、対象技を持つ候補本人だけへ追加。対象全員へ同時に技能を付与した全編成環境ではない。既存技能とCDは維持。
・星図の露出(area-mark)：本人通常areaが2体以上へ命中→生存敵に強さ30の防御弱体を次Rまで。強い既存弱体は維持。該当2種。
・余光の包帯(overheal)：通常heal/mend_pairの余剰60%を障壁へ、上限min(60,対象maxHP20%)、次Rまで。該当4種。
・祈りの余韻(aftercare)：通常heal/mend_pair後の障壁min(55,対象maxHP18%)、次Rまで。該当4種。
・守りの返し(guard-counter)：通常敵攻撃をかばい、実HP被害を受け生存→1守護役1R1回反撃、参照ATK=min(60,自maxHP20%)。敵の防御/障壁/かばうで軽減される。再反撃連鎖なし。別処理のbossStrike/bitsは除外。該当3種。
・再診の呪印(control-fallback)：通常の睡眠/麻痺等が失敗した時だけ強さ20の防御弱体を次Rまで。既存重複・耐性・乱数失敗を別記。jam/封印は対象外。該当4種。
・重ならない祈り(buff-preserve)：通常buffが既存より弱い場合だけ、既存の強い値と期限を守る。追加ゲージや無料の延長はなし。同値のbuffで旧期限だけ長い場合は未対応。該当4種。
石・必殺・強制行動等への無制限な波及はしない。障壁系は有効な既存障壁より新量が大きい場合だけ更新し、弱い新障壁で強い旧障壁を延長しない。

リーダー4案：固定下位20の候補本人へ王冠を移し、その子の既存ステータス補正とパッシブは残す『上乗せ』試作。本人の旧王冠効果を新技能へ置換した試験ではない。元の有力リーダーの王冠は失う。枠の予算・入手条件は未校正。
・四重奏の帰還：4役が生存中、R末に全員へ固定12障壁、非累積・次Rまで。
・まだ帰れない：leader生存中、敵由来の最初の致死ダメージをHP1で耐える。一層1回、waveで回数回復なし、別の次の一打は通常通り。
・余白の祈り：本人通常heal/mend_pair余剰50%を障壁、対象maxHP25%まで。石/必殺/regen/薬は除外。
・同行者の灯：生存leader下の味方の通常攻撃/通常攻撃技能へ、max(0,min(10,(60-baseStats.attack)*0.25))の低攻撃向け加算。石/必殺/強制行動除外。石と違い不足量は王冠補正前baseStats由来、加算分をbuff/加速で増幅しない。

【統一した第一段階】
加入可能69フォーム、early/developed×白花の小径/塔1/塔10の6文脈、T3 power80/pure/traitnone。枠は役割ごと固定、家族重複禁止。現行の装備候補(baseline/echo)は前回の選択を凍結して継承し、既存全石を最適化した基準ではない。
スコア=70×勝利+20×wave正規化の敵HP攻略進度+10×生存割合。勝率と同一ではない。各役割平均を引いた残差のpopulation SDを、種類数でまとめる。役割を跨ぐ強さランキングにはしない。
固定下位20/上位20は前回調整から維持。各案の調整評価は、その中で実際に対象技を持つ群。対象人数が異なるため12案を同予算ランキングにしない。
seed301..310で各枠の全体候補と各キャラのnative保持/提案選択を固定し、未使用9001..9030で確認。元の0.25点閾値ではなくpositive gain>0で変更。確認を見て選び直さない。
石=flat-gem、通常技能=guard-counter、王冠は全4案net負のため採用なし。最良不採用pledgeは別の追試として確認した。『本人王冠native比の純益』と『元王冠からの持替えnet』を分ける。
選択保持はnative/proposalの同じ結果行を再利用し、別戦闘として加算しない。

【独立確認の主な結果】
'''
lines=[]
for k,label in [('native','現行'),('flat-gem','灯芯対象装備'),('flat-gem-optional','灯芯選択保持'),('guard-counter','守りの返し'),('leader_pledge','致死回避全対象'),('leader_pledge-optional','致死回避選択保持')]:
 m=A['modes'][k];lines.append(f'{label}: SD{m["withinRoleSD"]:.6f}点、固定下位平均{m["bottomMean"]:.6f}点、固定上位{m["topMean"]:.6f}点、勝利割合{m["meanWinRate"]*100:.6f}%。')
notes+='\n'.join(lines)+'''
灯芯強制のSD差95%seedblock区間は約[-0.2318,-0.0114]点。小規模な改善で、勝率は約+0.0644ポイント（全12,420戦では+8勝）。選択保持で勝率が少し高くても、全指標で常に最良になるわけではない。
通常守護反撃は下位+0.00247点、勝利割合は変化なし。実用的救済の証拠として大きく扱わない。
王冠waterfallは下位41.913531→本人王冠37.519532→追加致死回避39.614308。効果は+2.0948点あるが王冠の代価約-4.394点を回収できずnet約-2.299点。選択保持pledgeのSD差区間は約[-0.0460,+0.0526]で、格差縮小の根拠なし。
上位20が不変なのは対象外条件の影響もある。あらゆる強者編成で横取りなしを証明したものではない。低定数でも既に有用な回復役へ利益が出る例もある。
再標本化は30のseed組を全キャラ・全文脈で対に保つ2000回。区間はこの試験の条件の揺れを表し、人間のプレイヤー母集団の保証ではない。

【石の機構を分解した追試】
同じ25種・6文脈・9001..9030で既存echo固定を追加し、元装備との代価と新+24参照機構を分離。下位平均41.913531→通常残響41.401931→灯芯42.448492。持替え損-0.511600、新機構益+1.046561、net+0.534961。
ノエルは通常残響と元装備が同じ結果で、新機構純益+0.333519点。定数が低くても既に仕事がある通常フローラ/エレイン等も利益を得るので『弱者だけへ届く』としない。

【王冠の独立した局所試験720戦】
先固定A4役[seris,lucielle,liora,elaine]とB3役[seris,lucielle,nike-standard,elaine]。全員定数1.4、合計5.6、同じリュシエル王冠・slot別T3。忘却章2ボス/銀地下墓所/塔1×native/unity/pledge/guidance×seed12001..12030。
銀地下墓所Aはnative0/30→unity5/30、pledge10/30、guidance3/30。Bは0→0/1/0。塔1は全0勝。AでもR末まで4役生存できずunity不発。
この比較は本人王冠内の補助。元王冠より優位の証拠ではない。LioraとNikeの固有技/能力も替わるためA-Bの生差を役割条件だけの因果効果としない。

【追加薄盾で悪化した同seedの追跡】
Hebe/developed/塔1/seed303。R1Hebeの通常回復後、試案はAthenaへ障壁55。R2nativeはAthenaへ白灯石169、試案は薄盾のAthenaを保護済みとしHebeへ94。R2後AthenaHPはnative279/試案180。後続の守護・薬・行動が変わり試案HebeはR3に死亡。native24R勝利、旧aftercare18R敗北。
同seedで薄盾張替方針+aftercareは24R勝利へ戻る。被弾ゲージだけの補填では18R敗北(この例で補填発火0)。この例は薄盾とnative障壁対象AIの相性を支持するが、全ての悪化の原因ではない。

【4回復役の再試作：別5,760戦】
固定[帳の巫女,ヘベ,通常ヘベ,通常フローラ]×6文脈。6条件を先固定しscreen12001..12010、確認15001..15030で全条件比較。第1段のsourceは変更せず隔離し、off/nativeと機構を別確認。
'''
for k,label in [('off','現行'),('aftercare','旧追加薄盾'),('thin-shield-ai','薄盾更新AI単独'),('aftercare-upgrade','薄盾+更新AI'),('aftercare-heal','小回復加算'),('aftercare-gauge','被弾充填診断')]:
 m=H['modes'][k];notes+=f'{label}: 平均{m["meanScore"]:.6f}点、現行差{m["scoreDelta"]:+.6f}点、{m["wins"]}/{m["total"]}勝。\n'
notes+='''小回復は本人通常heal/mend_pair後にmaxHP10%・上限35を追加。障壁を付けない。更新AIは全味方の障壁対象選択でmaxHP20%未満の薄盾を保護完了としない方針変更で、個人固有技能ではない。
更新AI単独はnativeと同値。元ゲーム全体のAI欠陥ではなく、新しい薄盾追加との相互作用を修正したもの。被弾ゲージ補填は診断用反実仮想で、通常の新スキルとして提案していない。
小回復は4人平均+1.1251775点だがヘベ単体は-0.180点。代表一戦が救えても、独立条件の個人平均が上がるとは限らない。6条件すべての結果を公開し、全69のSD改善として混ぜない。

【既存石・副官・操作の第2探索】
星炉/巻戻し/奪灯+元装備、各legacy/utilityの8条件。main固定下位20とauxiliary弱め攻撃6種を別に。調整21001..21010でキャラごとに選択を固定、確認24001..24030。元装備旧/utility、選択条件、同じ選択石の逆policy対照を設ける。
mainは従来の役割枠差替え。auxiliaryはslot1へ入れ、Seris/Nox主火力とLiora/Athena王冠を残す。その中で元装備と選択支援石を比較する。main/auxiliaryの平均やSDを直接混ぜない。
'''
for k,label in [('main','従来の役割枠20種'),('auxiliary','同じ副官配置6種内の持替え')]:
 m=E['scopes'][k]['modes'];x=m['chosen-fixed'];notes+=f'{label}: 元装備{x["meanScore"]-x["gainVsNative"]:.6f}→選択{x["meanScore"]:.6f}点、差{x["gainVsNative"]:+.6f}点、95%seed組区間{x["meanGainSeedBlockInterval"]}、勝利割合{m["legacy-native"]["winRate"]*100:.6f}%→{x["winRate"]*100:.6f}%。\n'
notes+='''mainの平均+0.118は区間が0をまたぐ。個別にククリヒメ+2.3845、ティッカ+2.2411、イリス+1.5960の候補がある一方、選択されたヘベ/通常ヘベに低下例。
auxiliaryの-1.6185が否定するのは同じ副官編成で今回選んだ石への持替え案で、副官化自体の失敗を示さない。調整10条件の選択が新30条件で外れた反例。
元装備旧/utilityが多く同値なのは今回6文脈の条件。敵に通常barrierがないのでshatter優先が発動せず、元pilotのechoにはutilityの支援石候補がない。副官本人は非pilotでnative AIが既に石を扱うためpolicy差0。別凍暁ではshatter差、main狼星炉ではpolicy差が出る。

【破砕を使う補助640戦】
通常/和装Nike×early/developed×月盾/凍暁×legacy/障壁時shatter優先×40seed。同編成・同装備の別探索。
月盾は全40/40勝で飽和、early凍暁は全0/40。developed凍暁では通常Nike5→9/40、和装Nike0→2/40。
通常shatterは時計のboss.barrierも消し、その後の防御低下に入れる。障壁破壊量とbossWindupを崩す実HPダメージは別。jam/封印は通常スキルを封じ、通常攻撃や別処理bossStrike/bitsは封じない。
これらの補助結果を全69主比較のSDへ混ぜない。

【比較データの戦数】
'''
for g in L['groups']:notes+=f'{g["name"]}: {g["trials"]:,}戦\n'
notes+='''合計117,040戦。これは117,040人の実プレイヤーでも、独立した別ビルド数でもない。optional/未対象の補完再利用・bootstrap・説明用の診断trace・off/native機構QAを別戦闘数として加えていない。ファイルごとのSHAをTrial-Ledger.jsonへ保存。

【残す候補と未検証の地図】
限定T3の参照補助と個別の回復再案を、小さな次候補として残す。守護反撃は実用差が小さく、王冠は元の効果の代価が重い。一律の追加薄盾は連携判断を直さず配らない。
個別の記憶解放・確定習得・制作など、使いたい子へ届く入口を検討。T6二重完璧装備を救済の前提にしない。定数境界/覚醒で使用不可の崖、返却/移行/固有技能化も未解決。
今後の候補：Noelleの全体技から次の味方へ繋ぐ印、Tikka封印の終わりの別仕事、Liora等のかばって生き残る足場、Lucielle強化の重なり、行動順や再使用を軸にした役割。これらも未試作なら仕様案として明記する。
上位キャラを一律弱体化しない。塔のハードコア目標を、全員同じ編成で100層を制覇する目標へ置き換えない。
未検証：全相方/隊列/王冠/石/ティア/trait/操作/敵/初期条件、複数の新効果を同時配布した全編成、実入手時間、手動の花/妖精温存、スマホ負担、愛着/使用率/継続。個々の改善を足し算して複合最強ビルドとは言わない。

【再現と公開資料】
本体616a074の上でartifacts/rescue-sequelを同じ構造に置く。Source-Index.jsonはResearch.tar.gzの各収録パス・サイズ・SHA256。展開時に元の相対パスを保持する。隔離エンジンはnativeのdomainコピーに研究用差分のみ。候補設定のglobal stateは1戦ごとconfigureし、同一processで別モードを並列実行しない。
Protocol/Selection/Analysis/Stage2/Skill-Stage2/Trial-Ledger/Comparison各CSV、仕様manifest、機構QA、批評、図表PDFを公開。細かい生データ/runner/隔離domainはResearch.tar.gzに収録し、Source-Indexで照合可能。
公開先は既存downloads/tower-diary-part1ブランチ。ゲームmain/itch.io/YouTubeは変更・投稿しない。

【制作クレジット】
VOICEVOX:ずんだもん
VOICEVOX:四国めたん
立ち絵：東北ずん子・ずんだもんプロジェクト公式素材 https://zunko.jp/
音楽：甘茶の音楽工房（作曲：甘茶） https://amachamusic.chagasi.com/
使用曲：悲しみの曖昧な対象／フィヨルドの澄んだ風／騎兵戦／楽しい冒険
ゲーム内イラスト・図鑑映像：STILLVEIL。イラスト/プログラミング等に生成AIを使用。図表はコードによる作図。
音楽だけの再配布やContent ID登録をしない。VOICEVOXと公式立ち絵の各規約も確認すること。
'''
(B/'Character-Rescue-Sequel-Notes.txt').write_text(notes)
chapters='\n'.join(f'{int(s["start"])//60:02}:{int(s["start"])%60:02} {s["title"]}'for s in N['sections'])
desc='''タイトル案：
【STILLVEIL】弱い子を救うスキルを作ったら、逆に弱くなった!? 救済工房②【ずんだもん＆四国めたん】

説明欄：
好きな仲間で勝つには、何を変えればいい？
ずんだもんと四国めたんが、弱めのキャラクターの救済案を徹底検討します。
通常スキル6案、石2案、リーダースキル4案から始め、失敗した原因を追跡し、再試作まで進めました。

複数の担当で監査・試作・比較・批評を分担。主な比較データは117,040戦。
王冠や石を替える代価、小さな障壁が連携を崩す例、既存の石や破砕の使い方も、グラフ・図・表で見ていきます。

※開発会議・試算の動画です。新しい提案はゲーム本体へ未実装。
※定数自体は変えていません。実戦スコアの差と、本人の定数の差は別です。
※有限の編成・装備・操作条件での比較で、全ビルドの最適化や全員救済完了ではありません。
※補助試験と全69種の比較を分け、失敗例も公開しています。

無料ブラウザRPG「STILLVEIL」：
https://fluffy3546.itch.io/stillveil

研究メモ：
'''+root+'Character-Rescue-Sequel-Notes.txt\n\n図表集PDF：\n'+root+'Character-Rescue-Sequel-Figures.pdf\n\n69種の比較CSV：\n'+root+'Character-Rescue-Sequel-Comparison.csv\n\n【チャプター】\n'+chapters+'''

【音声】
VOICEVOX:ずんだもん
VOICEVOX:四国めたん
【立ち絵】
東北ずん子・ずんだもんプロジェクト公式素材
https://zunko.jp/
【音楽】
甘茶の音楽工房（作曲：甘茶）
https://amachamusic.chagasi.com/
悲しみの曖昧な対象／フィヨルドの澄んだ風／騎兵戦／楽しい冒険
【イラスト・図鑑映像】STILLVEIL
ゲーム制作のイラスト・プログラミング等に生成AIを使用しています。

#STILLVEIL #ずんだもん #四国めたん #ゲーム開発 #ハクスラ #ブラウザゲーム
'''
(B/'Character-Rescue-Sequel-YouTube-description.txt').write_text(desc)
# Publication-ready figures collected into a portable PDF, with explanatory cards.
from PIL import Image
pages=[]
for name in ['summary-table','damage-threshold','screen-skill','screen-leader','sd-interval','bottom-top','individual-changes','crown-waterfall','leader-stress','aftercare-cause','stone-waterfall','healer-rebuild','healer-individual','existing-gem-check','existing-individual','shatter-operation','verdict-table','diagram-levers','diagram-trigger-cap','diagram-growth-cliff','diagram-stone-cost','diagram-crown-cost','diagram-four-criteria','diagram-jam-scope','diagram-shatter-niche','diagram-existing-support-stones','diagram-existing-conditional-stones','diagram-three-failure-types','diagram-acquisition']:
 p=B/'cards'/(name+'.png');im=Image.open(p).convert('RGB');pages.append(im.resize((1520,1000),Image.Resampling.LANCZOS))
pages[0].save(B/'Character-Rescue-Sequel-Figures.pdf',save_all=True,append_images=pages[1:],resolution=160)
print('Notes',len(notes),'chars,',len(N['sections']),'YouTube chapters, PDF',len(pages),'pages')
