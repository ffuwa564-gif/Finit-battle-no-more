from pathlib import Path
exec(Path('artifacts/rescue-sequel/director/draw-diagrams.py').read_text().split('# 01')[0])
manifest=json.loads((B/'figures-manifest.json').read_text())
# Existing native mechanics: the rescue value is still waiting for unified measurement.
im,d=base('既存の石でも、低い火力に別の仕事を渡せる？','現行の石の仕組み ／ 救済としての効果は第2探索で確認')
for x,title in [(35,'星炉の記憶'),(399,'巻戻しの石')]:
 panel(d,(x,128,x+326,416));gem(d,x+40,169,MINT if x==35 else BLUE);text(d,(x+76,148),title,27,GOLD,True,maxw=238)
text(d,(56,208),'T3・効力80なら70充填',24,MINT,True,maxw=283);text(d,(56,248),'自分以外の味方の必殺へ',21,maxw=283);text(d,(56,283),'本人の攻撃力に依存しない',20,maxw=283);text(d,(56,326),'最大HP10%消費／再使用5R',19,RED,maxw=283);text(d,(56,366),'HP20%超・対象ゲージ65以下',18,GRAY,maxw=283)
text(d,(420,208),'T3・効力80なら2R短縮',24,BLUE,True,maxw=283);text(d,(420,248),'別の味方の通常技を再使用へ',20,maxw=283);text(d,(420,283),'石の技・必殺は短縮しない',20,maxw=283);text(d,(420,326),'行動1回／再使用5R',21,RED,maxw=283);text(d,(420,366),'待ち時間がなければ使えない',18,GRAY,maxw=283)
foot(d,'澄明T3・効力80の例。ゲージ上限100。発動したことと攻略改善は別。');save(im,'existing-support-stones','Current native mechanics with rolled pure power80 T3; rescue performance pending. Furnace gemFurnaceCharge cap70, HP cost10%, hp>20%, other target gauge<=65, CD5. Rewind normal character skill cooldowns -2, gem/ultimate excluded, CD5.')
im,d=base('奪う石と、消費する石。強さには条件がある','現行の石の仕組み ／ 向く敵・相方・代価を比較中')
for x,title in [(35,'奪灯石'),(399,'砕盾石')]:
 panel(d,(x,128,x+326,416));gem(d,x+40,169,GOLD if x==35 else BLUE);text(d,(x+76,148),title,28,GOLD,True,maxw=238)
text(d,(56,207),'敵の攻撃強化・再生を解除',22,MINT,True,maxw=283);text(d,(56,249),'灯を最高ATKの味方へ回収',21,maxw=283);text(d,(56,285),'使う本人は低火力でもよい',20,maxw=283);text(d,(56,328),'敵に該当効果がある場面向け',18,RED,maxw=283);text(d,(56,366),'障壁は奪えない／再使用4R',18,GRAY,maxw=283)
text(d,(420,207),'最大の味方障壁を全て消費',22,BLUE,True,maxw=283);text(d,(420,249),'自分の攻撃力も砲撃へ関わる',20,maxw=283);text(d,(420,285),'障壁だけで火力が決まらない',19,maxw=283);text(d,(420,328),'守りを失う代価も数える',20,RED,maxw=283);text(d,(420,366),'障壁が必要／澄明は再使用4R',17,GRAY,maxw=283)
foot(d,'仕組みは現行。低定数の子の救済になるかは、装備・敵・操作をそろえて検証。');save(im,'existing-conditional-stones','Current native hollow-lantern and shield-break mechanics. Lantern transfers buff/regen to highest Unit.attack living ally (may include self), not barrier. Shield-break consumes all largest active friendly barrier, still attack dependent; pure CD4. Rescue efficacy pending.')
im,d=base('「効かなかった」を、3つに分ける')
for i,(title,c,lines)in enumerate([('発動しない',BLUE,['条件がなかった？','AIが選ばなかった？','まず行動ログを見る']),('発動して弱い',GOLD,['実際に使ったが','必要な効果に届かない','威力・対象・期限を確認']),('強いが代価負け',RED,['効果自体はあっても','王冠や石枠を失った分が','改善を上回ってしまう'])]):
 x=24+i*244;panel(d,(x,142,x+230,364));center(d,(x+115,166),title,25,c,True,maxw=213)
 for j,l in enumerate(lines):center(d,(x+115,225+j*37),l,19,maxw=208)
panel(d,(35,393,725,442),ALT);center(d,(380,403),'不発の修正 ／ 効果の調整 ／ 交換価値の再設計',23,MINT,True,maxw=664);foot(d,'得点差が0という結果だけでは、どの問題なのかまでは分からない。');save(im,'three-failure-types','Qualitative distinction: trigger/AI non-use, inadequate contribution when triggered, or opportunity-cost net loss. No measured numerical claim.')
# Idempotent manifest if re-run.
manifest=list({x['name']:x for x in manifest}.values());(B/'figures-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print('Added3 figures; total',len(manifest))
