from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
B=Path('artifacts/rescue-sequel/director');O=B/'figures';O.mkdir(exist_ok=True);F='/usr/share/fonts/opentype/noto/'
BG='#101c2b';BOX='#203144';ALT='#142437';WHITE='#f1eee7';GOLD='#ddc18b';MINT='#bad7c9';BLUE='#b9cddd';RED='#dfacbb';GRAY='#9cb0c4';LINE='#42566c';manifest=[]
def font(n,b=False):return ImageFont.truetype(F+('NotoSansCJK-Bold.ttc'if b else'NotoSansCJK-Regular.ttc'),n)
def text(d,xy,s,n=22,c=WHITE,b=False,maxw=700):
 while d.textbbox((0,0),s,font=font(n,b))[2]>maxw:n-=1
 assert n>=13,(s,n,maxw)
 d.text(xy,s,font=font(n,b),fill=c)
def center(d,xy,s,n=22,c=WHITE,b=False,maxw=700):
 while d.textbbox((0,0),s,font=font(n,b))[2]>maxw:n-=1
 assert n>=13,(s,n)
 w=d.textbbox((0,0),s,font=font(n,b))[2];d.text((xy[0]-w/2,xy[1]),s,font=font(n,b),fill=c)
def base(title,tag='救済工房・第二回 ／ 仕組みを考える説明図'):
 im=Image.new('RGB',(760,500),BG);d=ImageDraw.Draw(im);d.rounded_rectangle((1,1,758,498),radius=18,outline=LINE,width=2);text(d,(27,20),tag,15,GOLD);text(d,(26,54),title,28,WHITE,True);d.line((28,103,730,103),fill=LINE);return im,d
def panel(d,xy,fill=BOX,outline=None):d.rounded_rectangle(xy,radius=14,fill=fill,outline=outline,width=2)
def arrow(d,a,b,c=MINT,width=4):
 d.line((*a,*b),fill=c,width=width);ang=math.atan2(b[1]-a[1],b[0]-a[0]);r=12;pts=[b,(b[0]-r*math.cos(ang-.5),b[1]-r*math.sin(ang-.5)),(b[0]-r*math.cos(ang+.5),b[1]-r*math.sin(ang+.5))];d.polygon(pts,fill=c)
def foot(d,s):text(d,(28,467),s,14,GRAY)
def save(im,name,scope):im.save(O/(name+'.png'));manifest.append(dict(name=name,path=str(O/(name+'.png')),width=760,height=500,scope=scope))
def crown(d,x,y,c=GOLD):d.polygon([(x-25,y-12),(x-15,y+15),(x+15,y+15),(x+25,y-12),(x+9,y-2),(x,y-24),(x-9,y-2)],fill=c)
def gem(d,x,y,c=MINT):d.polygon([(x,y-24),(x+21,y-6),(x+13,y+20),(x-13,y+20),(x-21,y-6)],outline=c,width=3);d.line((x,y-24,x,y+20),fill=c,width=2)
def pawn(d,x,y,c=BLUE):d.ellipse((x-10,y-25,x+10,y-5),outline=c,width=3);d.rounded_rectangle((x-15,y-1,x+15,y+24),radius=7,outline=c,width=3)
# 01
im,d=base('3つの救済手段は、払うものが違う')
for i,(title,lines,col,icon)in enumerate([('本人のスキル',['元の得意を伸ばす','全員への無料上乗せに','しない工夫も必要'],BLUE,pawn),('リーダースキル',['王冠は1つだけ','既存の補正・効果を','手放す価値を比べる'],GOLD,crown),('記憶石',['装備枠は1人1つ','今使っている石と','交換して試す'],MINT,gem)]):
 x=25+i*240;panel(d,(x,123,x+230,375));icon(d,x+115,165);center(d,(x+115,207),title,25,col,True,maxw=210)
 for j,l in enumerate(lines):center(d,(x+115,256+j*32),l,19,maxw=214)
arrow(d,(140,383),(140,414));arrow(d,(380,383),(380,414));arrow(d,(620,383),(620,414));center(d,(380,423),'この子を選ぶ理由が増えるか？',26,MINT,True);foot(d,'技能・王冠・石を同時に全部足す前に、それぞれの交換価値を比べる。');save(im,'levers','proposal diagram; no measured effects')
# 02
im,d=base('支援が、支援を無限に生まないように')
for i,(a,b)in enumerate([('通常の行動','本来の仕事をする'),('条件を満たす','実際の破壊・回復など'),('小さな追加効果','次の1回へつなぐ')]):
 x=25+i*245;panel(d,(x,146,x+215,279));center(d,(x+107,173),a,24,GOLD,True,maxw=197);center(d,(x+107,227),b,18,maxw=198)
 if i<2:arrow(d,(x+218,212),(x+242,212))
panel(d,(45,313,715,426),ALT,RED);text(d,(67,330),'決める上限',22,RED,True);text(d,(67,369),'1行動1回／1対象1回／追加効果から再発動しない',23,maxw=622);foot(d,'これは設計原則。個別試案の最終仕様・数値は、結果の章で確認する。');save(im,'trigger-cap','generic nonrecursive support principle')
# 03
im,d=base('王冠を渡すと、何を手放す？')
for x,title,clr in [(205,'既存のリーダー',BLUE),(555,'救済案のリーダー',GOLD)]:
 panel(d,(x-162,129,x+162,355));crown(d,x,174,clr);center(d,(x,213),title,25,clr,True,maxw=300)
 for i,l in enumerate(['能力補正＋既存効果','その子を王冠にする価値']if x==205 else['本人を支える新効果','生存中などの条件も確認']):center(d,(x,270+i*35),l,21,maxw=300)
arrow(d,(372,240),(388,240),GOLD);center(d,(380,388),'「追加したら強い」と「王冠を渡したい」は別',25,MINT,True,maxw=710);foot(d,'比較では同じ編成を使い、王冠を付けた現行との機会費用も見る。');save(im,'crown-cost','opportunity cost; diagram only')
# 04
im,d=base('新しい石は、今の1個と交換する')
for x,title,lines,c in [(210,'今の装備',['回復・障壁・追撃など','既存の仕事がある'],BLUE),(550,'救済用の石',['別の仕事を加える代わりに','今の仕事を失う'],MINT)]:
 panel(d,(x-160,125,x+160,358));gem(d,x,171,c);center(d,(x,218),title,26,c,True,maxw=297)
 for i,l in enumerate(lines):center(d,(x,275+i*34),l,21,maxw=290)
arrow(d,(376,225),(387,225),GOLD);center(d,(380,391),'装備枠を増やした比較にしない',27,GOLD,True);foot(d,'効力・特性・相方・操作もそろえ、試す前に装備の選び方を決める。');save(im,'stone-cost','single gem-slot replacement, not extra equipment')
# 05
im,d=base('救済の境界で、成長が罰にならない？')
text(d,(40,124),'避けたい体験',20,RED,True);panel(d,(40,158,323,254));panel(d,(437,158,720,254));center(d,(181,174),'低い定数では使用可',22,MINT,True,maxw=260);center(d,(579,174),'少し成長すると使用不可',21,RED,True,maxw=260);arrow(d,(332,207),(426,207),RED);center(d,(380,258),'覚醒・別の姿で、道具を失う崖',23,RED,True)
text(d,(40,314),'設計したい移行',20,MINT,True);panel(d,(40,348,720,428),ALT);text(d,(60,367),'序盤の支え → 個性の技能 → 別用途の石へ',27,GOLD,True,maxw=640);foot(d,'定数やレアリティで区切る場合、境界と成長後の移行先まで案内する。');save(im,'growth-cliff','design risk; no particular game restriction claimed as implemented')
# 06
im,d=base('救済は、4つの軸で採点する')
rows=[('固定した下位','勝利や攻略の進みが上がった？',MINT),('固定した上位','強者だけが更に得をしていない？',GOLD),('出番と個性','同じ電池役へそろえていない？',BLUE),('使うための負担','王冠・石枠・入手・操作が重くない？',RED)]
for i,(a,b,c)in enumerate(rows):
 x=30+(i%2)*365;y=125+(i//2)*151;panel(d,(x,y,x+335,y+133));text(d,(x+18,y+17),a,25,c,True,maxw=300);text(d,(x+18,y+74),b,19,maxw=300)
foot(d,'散らばりの縮小だけで採用しない。勝率・下位改善・上位横取りを分ける。');save(im,'four-criteria','evaluation dimensions, not numerical scoring')
# 07
im,d=base('救済を使う前に、最高難度を要求しない')
for i,(a,b)in enumerate([('普通の探索','素材を集める'),('確定制作','まず試せる'),('好きな子で試す','違う勝ち方'),('周回で更新','育成の目標')]):
 x=23+i*184;panel(d,(x,142,x+164,282));center(d,(x+82,166),a,22,GOLD,True,maxw=150);center(d,(x+82,228),b,18,maxw=150)
 if i<3:arrow(d,(x+166,210),(x+182,210),MINT,3)
panel(d,(42,324,718,425),ALT,RED);text(d,(61,340),'避ける循環',21,RED,True);text(d,(61,378),'塔深層に勝つための救済石が、塔深層でしか出ない',23,maxw=635);foot(d,'入手先や課題名は提案。公開ゲームに追加済みという意味ではない。');save(im,'acquisition','proposed progression, not actual acquisition instructions')
# 08
im,d=base('定数の差と、実戦の差は同じではない','前回の検証を復習 ／ 今回の新しい測定結果ではありません')
panel(d,(30,129,357,381));panel(d,(403,129,730,381));center(d,(193,150),'基礎定数の散らばり',23,GOLD,True,maxw=300);center(d,(193,209),'26.7%',54,GOLD,True);center(d,(193,291),'平均に対する標準偏差',19,maxw=300);center(d,(193,331),'そのまま火力差ではない',20,maxw=300)
center(d,(566,150),'役割内の実戦スコアSD',22,MINT,True,maxw=303);center(d,(566,219),'5.036 → 4.848',34,MINT,True,maxw=301);center(d,(566,291),'制限付きの石を選べる条件',18,maxw=300);center(d,(566,331),'縮小は約3.7%・控えめ',20,maxw=300);center(d,(380,411),'低定数でも強い子がいる／高い定数でも苦しい子がいる',22,BLUE,True,maxw=710);foot(d,'前回の固定69種・6文脈・装備候補の範囲。得点は勝率ではない。');save(im,'prior-two-gaps','previous measured results only; data from character-spread analysis.json')
# 09
im,d=base('ティッカの封印が止めるもの、止めないもの','現行の技能を確認 ／ 秒針ジャミング＝通常スキルの封印')
panel(d,(35,135,725,239),BOX,MINT);text(d,(59,151),'止める',23,MINT,True);text(d,(188,151),'敵の通常スキル',28,WHITE,True);text(d,(188,198),'使えるスキルがある敵を狙う',20,BLUE)
panel(d,(35,266,725,406),ALT,RED);text(d,(59,283),'止めない',23,RED,True);text(d,(214,283),'通常攻撃',24);text(d,(214,328),'ボスの予告大技／ビット射撃',24);foot(d,'封印対象外と、睡眠・魅了などが抵抗される場面は、別の現象。');save(im,'jam-scope','current native skill-info.ts16; not a proposal')
# 10
im,d=base('通常ニケには、既に障壁を割る仕事がある','現行の処理を確認 ／ 効果を足す前に、使い所を探す')
for i,(a,b)in enumerate([('磐砕き','実在する障壁を破壊'),('クローナの障壁','現行では通常barrierを利用'),('障壁がない間','時計の防御低下へつながる')]):
 x=26+i*244;panel(d,(x,142,x+218,300));center(d,(x+109,166),a,23,GOLD,True,maxw=200);center(d,(x+109,226),b,18,maxw=200)
 if i<2:arrow(d,(x+221,219),(x+242,219),MINT,3)
panel(d,(43,335,717,425),ALT);text(d,(63,353),'別の判定：予告大技を崩すには実HPダメージを数える',22,BLUE,maxw=630);text(d,(63,390),'障壁を壊した量と、HPへ与えた量を混ぜない。',21,maxw=630);foot(d,'native engineの障壁・破砕・時計処理。全ての敵への勝利を保証しない。');save(im,'shatter-niche','current native engine.ts408-416 and clock barrier assignment')
# 11
im,d=base('全員を、同じ強い仕事に変えない')
rows=[('ノエル','複数の敵を観測する'),('リオラ','守った先へつなぐ'),('ヘベ','回復の余白を活かす'),('ティッカ','一拍のずれをつくる'),('ニケ','進路の障壁を割る'),('リュシエル','灯りが割れた後を支える')]
for i,(a,b)in enumerate(rows):
 x=25+(i%3)*244;y=129+(i//3)*144;panel(d,(x,y,x+230,y+123));center(d,(x+115,y+15),a,24,GOLD,True,maxw=210);center(d,(x+115,y+71),b,18,WHITE,maxw=210)
center(d,(380,437),'同じゲージ係を6人作るより、違う相手に選びたい',23,MINT,True,maxw=710);foot(d,'ここに記した新しい役目は個別案。実験したモードとの対応を別途確認する。');save(im,'different-jobs','character identity ideas; not measured implementation')
# 12
im,d=base('思いつきから、採用までの証拠を分ける')
steps=[('案を作る','狙う仕事を言葉にする'),('仕組みを確認','発動・上限・対象を検査'),('候補を選ぶ','調整用条件で比較'),('別条件で確認','選んだ案を変えず試す'),('遊んで確かめる','理解・操作・周回も確認')]
for i,(a,b)in enumerate(steps):
 y=120+i*64;x=35+i*34;panel(d,(x,y,x+550,y+55),BOX if i%2==0 else ALT);text(d,(x+14,y+9),a,22,GOLD,True,maxw=190);text(d,(x+215,y+13),b,19,maxw=320)
foot(d,'試算で良くても、そのまま全環境のバランス改善を証明したことにはならない。');save(im,'evidence-ladder','evidence stages, no claim all stages completed')
(B/'figures-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print('Prepared',len(manifest),'diagrams')
