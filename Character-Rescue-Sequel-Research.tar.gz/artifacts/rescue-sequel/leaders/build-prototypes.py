from pathlib import Path
import json,hashlib
B=Path('artifacts/rescue-sequel/leaders');p=B/'sandbox/src/domain/engine.ts';src=Path('src/domain/engine.ts').read_text()
prefix='''// Proposal-only leader rescue experiments. Native source is not changed.
export type RescueLeaderMode = 'off'|'leader_unity'|'leader_pledge'|'leader_overflow'|'leader_guidance';
let rescueLeaderMode:RescueLeaderMode='off';let rescueLeaderTargets=new Set<string>();let rescueLeaderCandidate='';
let rescueLeaderStats={unityRounds:0,unityShields:0,pledgePreventions:0,overflowActions:0,overflowShield:0,guidanceHits:0,guidanceAddedAttack:0};
export function configure(mode:string,targets:string[]=[],candidateId=''){
 if(!['off','leader_unity','leader_pledge','leader_overflow','leader_guidance'].includes(mode))throw Error('Unknown leader proposal '+mode);
 rescueLeaderMode=mode as RescueLeaderMode;rescueLeaderTargets=new Set(targets);rescueLeaderCandidate=candidateId;
 rescueLeaderStats={unityRounds:0,unityShields:0,pledgePreventions:0,overflowActions:0,overflowShield:0,guidanceHits:0,guidanceAddedAttack:0};
}
export const configurePrototype=configure;
export function getPrototypeStats(){return {...rescueLeaderStats};}
export function applyOpening(_battle:Battle,_content:Content){} // no setup mutation required
function rescueLeaderActive(b:Battle,c:Content,mode:RescueLeaderMode){
 if(rescueLeaderMode!==mode||b.leaderId!==rescueLeaderCandidate||!rescueLeaderTargets.has(b.leaderId))return false;
 return b.units.some(u=>u.side==='party'&&u.characterId===b.leaderId&&u.hp>0);
}
function rescueOverflow(actor:Unit,target:Unit,attempted:number,healed:number,b:Battle,c:Content){
 if(actor.side!=='party'||actor.characterId!==b.leaderId||!rescueLeaderActive(b,c,'leader_overflow'))return;
 const excess=Math.max(0,attempted-healed);const grant=Math.min(Math.floor(target.maxHp*.25),Math.floor(excess*.5));
 const old=(target.barrierUntil??-1)>=b.round?target.barrier??0:0;
 if(grant>old){target.barrier=grant;target.barrierUntil=Math.max(target.barrierUntil??0,b.round+1);rescueLeaderStats.overflowActions++;rescueLeaderStats.overflowShield+=grant-old;
 emit(b,{kind:'guard',actorId:actor.uid,targetIds:[target.uid],text:'試案リーダー — 余白の祈り',unitsAfter:clone(b.units)});}
}
function rescueUnity(b:Battle,c:Content){
 if(!rescueLeaderActive(b,c,'leader_unity'))return;
 const living=b.units.filter(u=>u.side==='party'&&u.hp>0);const roles=new Set(living.map(u=>character(c,u.characterId).role));if(roles.size<4)return;
 const granted:string[]=[];for(const u of living){const old=(u.barrierUntil??-1)>=b.round?u.barrier??0:0;if(old<12){u.barrier=12;u.barrierUntil=Math.max(u.barrierUntil??0,b.round+1);granted.push(u.uid);rescueLeaderStats.unityShields+=12-old;}}
 if(granted.length){rescueLeaderStats.unityRounds++;emit(b,{kind:'guard',actorId:'party:'+b.leaderId,targetIds:granted,text:'試案リーダー — 四重奏の帰還',unitsAfter:clone(b.units)});}
}
'''
s=prefix+src
old="  const powerNumerator = effectiveAttack(actor, battle.round, activeAcceleration(battle, content)?.percent ?? 0) * numerator * resonance * (dawning && (recipient.debuffUntil ?? -1) >= battle.round ? 125 : 100);"
new="""  const guiding = actor.side==='party' && Boolean((actor as Unit & {_rescueGuidance?:boolean})._rescueGuidance) && rescueLeaderActive(battle,content,'leader_guidance') ? Math.max(0,Math.min(10,(60-baseStats(character(content,actor.characterId)).attack)*.25)):0;
  if(guiding>0){rescueLeaderStats.guidanceHits++;rescueLeaderStats.guidanceAddedAttack+=guiding;}
  const powerNumerator = (effectiveAttack(actor, battle.round, activeAcceleration(battle, content)?.percent ?? 0)+guiding) * numerator * resonance * (dawning && (recipient.debuffUntil ?? -1) >= battle.round ? 125 : 100);"""
assert old in s;s=s.replace(old,new)
old="  const actual = Math.min(recipient.hp, amount - absorbed); recipient.hp -= actual;"
new="""  const rescueState=battle as Battle & {_rescueLeaderPledgeSpent?:boolean};
  const pledge = recipient.side==='party' && actor.side==='enemy' && amount-absorbed>=recipient.hp && recipient.hp>0 && !rescueState._rescueLeaderPledgeSpent && rescueLeaderActive(battle,content,'leader_pledge');
  const actual = Math.min(recipient.hp-(pledge?1:0), amount - absorbed); recipient.hp -= actual;
  if(pledge){rescueState._rescueLeaderPledgeSpent=true;rescueLeaderStats.pledgePreventions++;emit(battle,{kind:'guard',actorId:'party:'+battle.leaderId,targetIds:[recipient.uid],text:'試案リーダー — まだ帰れない',unitsAfter:clone(battle.units)});}"""
assert old in s;s=s.replace(old,new)
old="    const name = actorDef.name;"
new="""    (actor as Unit & {_rescueGuidance?:boolean})._rescueGuidance=Boolean(actor.side==='party'&&!memoryGem&&!action.ultimate&&!action.forcedBy&&!action.power);
    const name = actorDef.name;"""
assert old in s;s=s.replace(old,new)
# No transient state is serialized to ordinary events or later turns.
old="    if (!action.ultimate && !action.forcedBy) gainUltimate(actor, 25);"
new="    delete (actor as Unit & {_rescueGuidance?:boolean})._rescueGuidance;\n"+old
assert old in s;s=s.replace(old,new)
old="""      amount = Math.min(target.maxHp - target.hp, Math.max(1, Math.floor(effectiveAttack(actor, battle.round) * (action.skill!.strength + 30) / 20 * potency)));
      target.hp += amount; targetIds.push(target.uid);"""
new="""      const attempted = Math.max(1, Math.floor(effectiveAttack(actor, battle.round) * (action.skill!.strength + 30) / 20 * potency));
      amount = Math.min(target.maxHp - target.hp, attempted);
      target.hp += amount; targetIds.push(target.uid);
      if(!memoryGem&&!action.forcedBy)rescueOverflow(actor,target,attempted,amount,battle,content);"""
assert old in s;s=s.replace(old,new)
old="""        const healed = Math.min(target.maxHp - target.hp, Math.max(1, Math.floor(effectiveAttack(actor, battle.round) * (action.skill!.strength + 30) / 40 * potency)));
        target.hp += healed; amount += healed; targetIds.push(target.uid);"""
new="""        const attempted = Math.max(1, Math.floor(effectiveAttack(actor, battle.round) * (action.skill!.strength + 30) / 40 * potency));
        const healed = Math.min(target.maxHp - target.hp, attempted);
        target.hp += healed; amount += healed; targetIds.push(target.uid);
        if(!memoryGem&&!action.forcedBy)rescueOverflow(actor,target,attempted,healed,battle,content);"""
assert old in s;s=s.replace(old,new)
# Insert exactly at the end-of-round survival check; not the mid-round actor-order check.
old="  if (!alive(battle.units, 'party').length) {\n    battle.nextPhase = 'failed';"
new="  rescueUnity(battle,content);\n"+old
assert old in s;s=s.replace(old,new)
# QA-only private mechanism probes in the ignored sandbox, never game APIs.
s+='''\nexport function debugRescueDamage(b:Battle,c:Content,actor:Unit,target:Unit,numerator=100){return damage(actor,target,numerator,100,b,false,c);}
export function debugRescueUnity(b:Battle,c:Content){rescueUnity(b,c);}
export function debugRescueOverflow(b:Battle,c:Content,actor:Unit,target:Unit,attempted:number,healed:number){rescueOverflow(actor,target,attempted,healed,b,c);}
'''
p.write_text(s)
(B/'engine.ts').write_text("export * from './sandbox/src/domain/engine';\n")
proto=json.loads(Path('artifacts/character-spread/frozen-protocol.json').read_text());targets=[i for g in proto['groups']for i in g['bottom']]
rows=[('leader_unity','四重奏の帰還','4つの役割が生存中、ラウンド末に全員へ固定12障壁。max更新で非累積、次R末まで。'),('leader_pledge','まだ帰れない','リーダー生存中に最初の敵側致死ダメージを一層1回だけHP1で耐える。直後の別ヒットは普通に通る。'),('leader_overflow','余白の祈り','候補リーダー本人の通常heal/mend_pairの余剰50%を対象障壁へ。25%最大HP上限、強い既存障壁を上書き/延長せず、石/必殺/再生/薬を除外。'),('leader_guidance','同行者の灯','生存リーダー下で通常攻撃/通常攻撃スキルの低基礎攻撃へ加算max(0,min(10,(60-baseAtk)*0.25))。石・必殺・強制行動・敵除外。加算分は加速/攻撃buffで増幅しない。')]
manifest={'status':'proposal-only, unimplemented in game','module':'artifacts/rescue-sequel/leaders/engine.ts','configure':'configure(mode,targets,candidateId)','openingHook':'applyOpening','openingRequired':False,'statsHook':'getPrototypeStats','eligibleTargets':targets,'eligibilityMeaning':'fixed prior-study bottom20 for experiments, NOT an in-world score-gated unlock; character-specific learnable skills/acquisition are separate design work','modes':[{'id':id,'label':name,'engineMode':id,'leaderOverride':'candidate','openingHook':False,'targets':targets,'description':desc}for id,name,desc in rows],'bounds':'while selected candidate leader is living and fixed target; old native leader stat/passive remains; same-candidate-leader native and original-leader native comparisons both required','baseEngineSha256':hashlib.sha256(src.encode()).hexdigest()}
(B/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print('Built4 leader prototypes; targets',len(targets))
