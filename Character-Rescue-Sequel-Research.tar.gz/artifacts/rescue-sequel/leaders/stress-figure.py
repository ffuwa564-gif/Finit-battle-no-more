from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import json
B=Path('artifacts/rescue-sequel/leaders');A=json.loads((B/'stress-summary.json').read_text());F='/usr/share/fonts/opentype/noto/'
def f(n,b=False):return ImageFont.truetype(F+('NotoSansCJK-Bold.ttc'if b else'NotoSansCJK-Regular.ttc'),n)
im=Image.new('RGB',(760,500),'#101c2b');d=ImageDraw.Draw(im)
def t(x,y,s,n=22,c='#f1eee7',bold=False):d.text((x,y),s,font=f(n,bold),fill=c)
d.rounded_rectangle((1,1,758,498),radius=18,outline='#42566c',width=2);t(26,20,'事前固定の補助試験 ／ 自己王冠の中で比較・未実装',16,'#ddc18b');t(26,54,'局所で効いた案と、条件まで届かない案',27,bold=True);d.line((28,103,730,103),fill='#42566c')
t(29,118,'銀地下墓所：両編成とも総定数5.6／リュシエル王冠',21,'#bed7c9')
for x,label in [(30,'各30条件'),(275,'現行'),(380,'四重奏'),(505,'誓約'),(625,'導き')]:t(x,162,label,19,'#acbdce')
for j,(p,label)in enumerate([('four-roles','A：4役'),('three-roles','B：3役')]):
 y=202+j*65;d.rounded_rectangle((24,y-4,734,y+51),radius=10,fill='#203144');t(37,y+5,label,26,'#ddc18b',True)
 for x,m in [(275,'off'),(390,'leader_unity'),(505,'leader_pledge'),(625,'leader_guidance')]:
  r=next(r for r in A['rows']if r['party']==p and r['scene']=='silver-crypt'and r['mode']==m);t(x,y+5,str(r['wins'])+'/30',25,'#b7d7c7',True)
d.rounded_rectangle((25,346,735,444),radius=12,fill='#283245');t(39,360,'塔1層は全て0勝。Aも四重奏は0回発火。',23,'#e6b7bf',True);t(39,399,'出発時に4役でも、ラウンド末の4役生存が0回。',21)
t(26,465,'交替で技・能力配分も変わる。役割数だけの因果比較ではない。',16,'#acbdce');im.save(B/'stress-figure.png')
