from pathlib import Path
import json,math,csv
B=Path('artifacts/rescue-sequel/leaders');A=json.loads((B/'stress-results.json').read_text());out=[]
def wilson(w,n):
 z=1.96;p=w/n;mid=(p+z*z/(2*n))/(1+z*z/n);half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n);return[round((mid-half)*100,1),round((mid+half)*100,1)]
for r in A['rows']:
 base=next(x for x in A['rows']if x['party']==r['party']and x['scene']==r['scene']and x['mode']=='off');hits=r['results'];out.append({k:r[k]for k in ['party','scene','mode','wins','total','score','meanRounds','leaderAliveAtEnd','triggeredBattles']}|{'scoreDeltaVsOwnPartyOff':r['score']-base['score'],'winDeltaVsOwnPartyOff':r['wins']-base['wins'],'wilson95Percent':wilson(r['wins'],r['total']),'leaderAliveReadyFraction':sum(x['leaderAliveReady']for x in hits)/sum(x['rounds']for x in hits),'all4AliveReadyFraction':sum(x['all4AliveReady']for x in hits)/sum(x['rounds']for x in hits),'fourRolesAliveAtEndRounds':sum(x['eligible4RoleEndRounds']for x in hits),'leaderAliveAtEndRounds':sum(x['leaderAliveEndRounds']for x in hits)})
summary={'scope':'Separate predeclared supplementary stress, not part of main ranking or selection','trials':A['trials'],'rows':out,'interpretation':['Equal total constant does not make parties equivalent: Liora to NikeStandard changes role, native skills and base stat ratios','Compare each party mode−off; direct difference across parties is not an isolated causal role-condition effect','HollowGate all30wins causes ceiling: unchanged winrate does not prove effects absent','SilverCrypt predeclared four-role party improves0/30→5/30 unity,10/30 pledge,3/30 guidance; three-role party unity remains0 and pledge1/30','Tower1 unity never fires in either party: four-role party has0round-end states with4roles; three-role party fails role condition inherently','Pledge fires30/30 onTower1 and still0wins: hit prevention is not full-battle survival or viability','These are specific self-leader parties, not proof of net advantage over an original stronger crown or stronger69-character best build']}
(B/'stress-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
with(B/'stress-summary.csv').open('w',encoding='utf-8-sig',newline='')as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
notes='''リーダー救済・補助ストレス試験（主要69種比較とは別資料）

事前固定：4役A[セリス／リュシエル／リオラ／エレイン]、3役B[セリス／リュシエル／通常姿ニケ／エレイン]。全員strength14、総定数5.6。王冠は両方リュシエル。装備は位置ごとT3 power80 pure/none、残響石/祓いの涙石/白灯石/双潮の記憶を固定。役割に合わせた装備最適化はしない。
対象：虚ろの門D10.2、錆銀の地下墓所D14.3、塔1層D31.1。各off/unity/pledge/guidance、新しいseed12001〜12030。2編成×3敵×4条件×30=720戦。後から勝った編成や敵を抜き出して評価用へ回してはいない。全条件を報告。

銀地下墓所：
4役Aは現行自己王冠0/30、四重奏5/30、誓約10/30、導き3/30。
3役Bは現行0/30、四重奏0/30、誓約1/30、導き0/30。
四重奏はA全30戦で発火しBは0戦。誓約は両方30戦で発火したが効果の届き方が大きく違った。

塔1層：
全条件0/30勝。四重奏はAも0回発火。4役が揃って出発しても、ラウンド末に4役が揃った状態が一度も残らず、発動条件に到達できなかった。Bは最初から3役である。
誓約は全30戦で発火しても、0勝のまま。致死1打を防ぐことと、戦闘を立て直せることは別。

虚ろの門：
全条件30/30勝。四重奏/導きが動いても勝率には天井があり、差が見えない。

解釈：
・役割と総定数を合わせた以外、交替する子の基礎能力配分、固有スキル、役割AIも違う。A/Bの勝率差を、純粋に4役条件だけの因果効果と呼ばない。各編成内のmode−offをまず見る。
・ここでのnativeも王冠はリュシエル。普段の別リーダーを失う機会費用を解消した証拠ではない。主要比較で元の王冠比が負であることと、特定の自己王冠編成が改善することは両立する。
・0/30は不可能の証明ではなく、10/30も十分安定という意味ではない。Wilson95%区間をsummaryに併記。
・弱いキャラ救済と、強者3人に便利な付属効果を渡すトークン化は別。全員へ固定障壁を渡す案なら理論上の受益者は本人だけではない。今回の補助試験は全員1.4の低定数編成なので、強者キャリーを安価なRリーダーで支える最適性を測ったものではない。
・発動条件を満たす編成で出発できても、発動時刻まで全員が生き残れなければ働かない。『4役の編成課題』と『4役を維持する戦闘課題』を分けて考える材料になる。
・全て未実装の試算。ゲーム本体、main、itch.ioは変更していない。
'''
(B/'stress-notes.txt').write_text(notes)
print('Supplementary stress summary written',len(out),'rows')
