import { RELEASE } from '../content/version';
import { validBattleReview, validExpeditionTracking } from '../domain/expedition-review';
import { validateCommandOrder } from '../domain/command-doctrine';
import { validBuildGoal } from '../domain/builds';
import { validMemoryGem, validGemInventory, gemSkill, gemDefinitionForSkill, gemRollKey } from '../domain/memory-gems';
import { validCrystalRole } from '../domain/crystal-resonance';
import { validBattleFairies } from '../domain/battle-fairies';
import { validBattleBlooms } from '../domain/battle-blooms';
import { validLegacyOmens } from '../domain/legacy-omens';
import { ailments } from '../domain/ailments';
import { duplicateFamily } from '../domain/events';
import { validPartyOrder } from '../domain/party-orders';
import type { Content, GameSave, GachaResult } from '../domain/types';

export const SAVE_DATABASE = 'stillveil-save';
export const SAVE_STORE = 'state';
export interface BootMetadata {
  contractVersion: 1; schemaVersion: number; appVersion: string; contentVersion: string; rulesVersion: string;
  hasExploration: boolean; hasPendingRewards: boolean; revision: number;
}

function record(value: unknown): value is Record<string, unknown> { return typeof value === 'object' && value !== null && !Array.isArray(value); }
function stringArray(value: unknown): value is string[] { return Array.isArray(value) && value.every(item => typeof item === 'string'); }
function count(value: unknown): value is number { return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0; }
function nonempty(value: unknown): value is string { return typeof value === 'string' && value.length > 0; }
function uniqueStrings(value: unknown): value is string[] { return stringArray(value) && new Set(value).size === value.length && value.every(nonempty); }
function materialMap(value: unknown): boolean { return record(value) && Object.entries(value).every(([id, amount]) => /^[a-zA-Z0-9_-]+:(common|rare|epic)$/.test(id) && count(amount)); }
function validExpeditionHistory(value: unknown): boolean {
  if (!Array.isArray(value) || value.length > 30) return false;
  const ids = new Set<string>();
  return value.every(item => {
    if (!record(item) || Object.keys(item).some(key => !['runId', 'dungeonId', 'appVersion', 'contentVersion', 'rulesVersion', 'outcome', 'durationMs', 'review', 'earned', 'potionsUsed'].includes(key))) return false;
    for (const key of ['runId', 'dungeonId', 'appVersion', 'contentVersion', 'rulesVersion']) if (!nonempty(item[key]) || String(item[key]).length > 256) return false;
    if (ids.has(String(item.runId))) return false;
    ids.add(String(item.runId));
    if (!['victory', 'defeat', 'timeout', 'retreat'].includes(String(item.outcome)) || item.durationMs !== null && !count(item.durationMs) || item.potionsUsed !== null && (!count(item.potionsUsed) || Number(item.potionsUsed) > 5) || item.review !== undefined && !validBattleReview(item.review)) return false;
    const earned = item.earned;
    if (!record(earned) || Object.keys(earned).some(key => !['gold', 'stones', 'gemCount', 'materials', 'dust'].includes(key)) || !count(earned.gold) || !count(earned.stones) || !count(earned.gemCount) || !materialMap(earned.materials) || !record(earned.dust) || Object.entries(earned.dust).some(([id, amount]) => !['sanctuary', 'clock', 'grave'].includes(id) || !count(amount))) return false;
    return true;
  });
}
function validGachaResult(value: unknown): value is GachaResult { return record(value) && nonempty(value.characterId) && typeof value.duplicate === 'boolean' && count(value.refund) && value.refund <= 3 && (value.currency === undefined || ['stones', 'astralStones'].includes(value.currency as string)); }
function validUnit(value: unknown): boolean {
  if (!record(value) || !nonempty(value.uid) || !nonempty(value.characterId) || !['party', 'enemy'].includes(value.side as string) || typeof value.boss !== 'boolean') return false;
  for (const key of ['hp', 'maxHp', 'attack', 'defense', 'speed', 'tie']) if (!count(value[key])) return false;
  if (Number(value.maxHp) < 1 || Number(value.hp) > Number(value.maxHp) || !record(value.cooldowns) || Object.values(value.cooldowns).some(item => !count(item))) return false;
  if (value.ailments !== undefined && (!record(value.ailments) || Object.entries(value.ailments).some(([id,state]) => !(ailments as readonly string[]).includes(id) || !record(state) || !count(state.turns) || state.turns < 1 || state.turns > 2 || !nonempty(state.sourceId)))) return false;
  if (value.ultimateCharge !== undefined && (value.side !== 'party' || !count(value.ultimateCharge) || value.ultimateCharge > 100)) return false;
  if (value.ultimateQueued !== undefined && (typeof value.ultimateQueued !== 'boolean' || value.side !== 'party' || value.ultimateQueued && value.ultimateCharge !== 100)) return false;
  if (value.statusWardUntil !== undefined && !count(value.statusWardUntil)) return false;
  if (value.bossWindup !== undefined && (!record(value.bossWindup) || value.side !== 'enemy' || !value.boss || !count(value.bossWindup.round) || value.bossWindup.round < 1 || !count(value.bossWindup.damage))) return false;
  if (value.bossRecoveryUntil !== undefined && (value.side !== 'enemy' || !value.boss || !count(value.bossRecoveryUntil))) return false;
  if (value.defendingUntil !== undefined && !count(value.defendingUntil)) return false;
  if (value.bits !== undefined && (!record(value.bits) || value.side !== 'enemy' || !value.boss || !count(value.bits.count) || value.bits.count < 1 || value.bits.count > 4 || !count(value.bits.deployedRound) || value.bits.deployedRound < 1 || !count(value.bits.expiresRound) || value.bits.expiresRound <= value.bits.deployedRound || value.bits.expiresRound > value.bits.deployedRound + 5)) return false;
  if (value.towerSupportUsed !== undefined && (!record(value.towerSupportUsed) || value.side !== 'enemy' || !count(value.towerSupportUsed.healing) || !count(value.towerSupportUsed.barrier))) return false;
  if (value.whiteFlower !== undefined && (!record(value.whiteFlower) || value.side !== 'party' || !count(value.whiteFlower.amount) || value.whiteFlower.amount !== 50 || !count(value.whiteFlower.until))) return false;
  if (value.scoutMark !== undefined && (!record(value.scoutMark) || !nonempty(value.scoutMark.sourceId) || !count(value.scoutMark.until))) return false;
  for (const key of ['scoutLanternUntil','scoutThreadUntil']) if (value[key] !== undefined && !count(value[key])) return false;
  if (value.guardTarget !== undefined && !nonempty(value.guardTarget)) return false;
  for (const key of ['guardUntil', 'guardStrength', 'buffUntil', 'buffStrength', 'debuffUntil', 'debuffStrength', 'barrier', 'barrierUntil', 'regenStrength', 'regenUntil']) if (value[key] !== undefined && !count(value[key])) return false;
  return true;
}
function validUnits(value: unknown): boolean { return Array.isArray(value) && value.every(validUnit) && new Set(value.map(unit => unit.uid)).size === value.length; }
function validEvent(value: unknown): boolean {
  if (record(value) && ['absorbed', 'selfCost'].some(key => value[key] !== undefined && !count(value[key]))) return false;
  if (record(value) && value.coordinationAction !== undefined && (!['linked', 'isolated', 'held', 'interrupted'].includes(value.coordinationAction as string) || value.coordinationAction === 'isolated' && value.kind !== 'attack')) return false;
  if (record(value) && value.actionSelection !== undefined && typeof value.actionSelection !== 'boolean') return false;
  if (!record(value) || !nonempty(value.id) || typeof value.text !== 'string' || !['attack', 'area', 'heal', 'guard', 'buff', 'debuff', 'drop', 'dialogue', 'wave', 'defeat'].includes(value.kind as string)) return false;
  for (const key of ['actorId', 'skillId', 'materialId', 'ultimateName']) if (value[key] !== undefined && !nonempty(value[key])) return false;
  if (value.targetIds !== undefined && !stringArray(value.targetIds)) return false;
  if (value.amount !== undefined && !count(value.amount)) return false;
  if (value.rarity !== undefined && !['common', 'rare', 'epic'].includes(value.rarity as string)) return false;
  if (value.clockAction !== undefined && (!['restore', 'break', 'finale'].includes(value.clockAction as string) || value.kind !== ({ restore: 'guard', break: 'debuff', finale: 'area' } as Record<string, string>)[String(value.clockAction)])) return false;
  if (value.directive !== undefined && !['aggressive', 'survival'].includes(value.directive as string)) return false;
  if (value.ultimate !== undefined && typeof value.ultimate !== 'boolean') return false;
  if (value.bossStrike !== undefined && typeof value.bossStrike !== 'boolean') return false;
  if (value.ailment !== undefined && !(ailments as readonly string[]).includes(value.ailment as string)) return false;
  if (value.statusAction !== undefined && (!['inflict', 'resist', 'skip', 'recover', 'friendly_fire'].includes(value.statusAction as string) || value.ailment === undefined)) return false;
  if (value.fairyAction !== undefined && !(value.fairyAction === 'charge' && value.kind === 'buff' && ['left', 'right'].includes(value.fairySide as string))) return false;
  if (value.bloomAction !== undefined && !((value.bloomAction === 'heal' && value.kind === 'heal') || (value.bloomAction === 'strike' && value.kind === 'attack'))) return false;
  if (value.bitAction !== undefined && !['deploy', 'fire', 'expire'].includes(value.bitAction as string)) return false;
  if (value.bitIndex !== undefined && (value.bitAction !== 'fire' || !count(value.bitIndex) || value.bitIndex > 3)) return false;
  if (value.unitsAfter !== undefined && !validUnits(value.unitsAfter)) return false;
  return true;
}

/** Reject unreadable records; callers must never interpret corruption as a new game. */
export function assertValidSave(value: unknown): asserts value is GameSave {
  if (!record(value) || value.schemaVersion !== 1) throw new Error('未対応または破損した保存形式です。セーブは保持されています。');
  for (const key of ['appVersion', 'contentVersion', 'rulesVersion', 'leaderId']) if (typeof value[key] !== 'string' || !value[key]) throw new Error('保存データの版情報を読めません。');
  for (const key of ['revision', 'gold', 'potions', 'stones', 'drawCount', 'seed']) if (!count(value[key])) throw new Error('保存データの所持数または状態が不正です。');
  for (const key of ['astralStones', 'xrDrawCount']) if (value[key] !== undefined && !count(value[key])) throw new Error('星晶の所持数または状態が不正です。');
  if (value.expeditionHistory !== undefined && !validExpeditionHistory(value.expeditionHistory)) throw new Error('周回の実績が不正です。');
  if (value.ssrPity !== undefined && (!count(value.ssrPity) || value.ssrPity >= 90 || value.ssrPity > Number(value.drawCount))) throw new Error('祈願の天井情報が不正です。');
  if (value.lastGachaResult !== undefined && !validGachaResult(value.lastGachaResult)) throw new Error('祈願の結果情報が不正です。');
  if (value.lastGachaResults !== undefined) {
    const results = value.lastGachaResults;
    if (!Array.isArray(results) || ![1, 10].includes(results.length) || !results.every(validGachaResult) || Number(results[0]?.currency === 'astralStones' ? value.xrDrawCount ?? 0 : value.drawCount) < results.length || results.some(result => (result.currency ?? 'stones') !== (results[0]?.currency ?? 'stones')) || !validGachaResult(value.lastGachaResult)) throw new Error('祈願の結果情報が不正です。');
    const last = results.at(-1)!;
    if (last.characterId !== value.lastGachaResult.characterId || last.duplicate !== value.lastGachaResult.duplicate || last.refund !== value.lastGachaResult.refund || (last.currency ?? 'stones') !== (value.lastGachaResult.currency ?? 'stones')) throw new Error('祈願の結果情報が不正です。');
  }
  if (value.novels !== undefined) {
    const novels = value.novels;
    if (!record(novels) || !uniqueStrings(novels.seen)) throw new Error('物語の記録が不正です。');
    if (novels.active !== undefined && (!record(novels.active) || !nonempty(novels.active.sceneId) || !count(novels.active.page) || value.battle !== null)) throw new Error('物語の再生位置が不正です。');
  }
  for (const key of ['ownedIds', 'partyIds', 'discoveredIds', 'completedDungeonIds', 'claimedExplorationIds']) if (!uniqueStrings(value[key])) throw new Error('保存データのキャラクター情報が不正です。');
  const partyIds = value.partyIds as string[];
  if (partyIds.length < 1 || partyIds.length > 4 || !partyIds.includes(value.leaderId as string) || partyIds.some(id => !(value.ownedIds as string[]).includes(id))) throw new Error('保存データの編成が不正です。');
  if (value.towerRecord !== undefined) {
    const r = value.towerRecord;
    if (!record(r) || r.version !== '1.10' || !Array.isArray(r.completedFloors) || r.completedFloors.some(f => !count(f) || f < 1 || f > 100) || new Set(r.completedFloors).size !== r.completedFloors.length || !count(r.legacyHighest) || r.legacyHighest > 100) throw new Error('白亜の塔の記録が不正です。');
    const floors = [...r.completedFloors].sort((a,b) => Number(a)-Number(b));
    if (floors.some((f,i) => f !== i+1)) throw new Error('白亜の塔の記録が連続していません。');
  }
  if (value.buildGoal !== undefined && !validBuildGoal(value.buildGoal)) throw new Error('目標ビルドの保存状態が不正です。');
  if (value.memoryGems !== undefined) {
    if (!validGemInventory(value.memoryGems)) throw new Error('記憶石の保存状態が不正です。');
    const inventory = value.memoryGems as unknown as NonNullable<GameSave['memoryGems']>;
    if (inventory.pending && value.battle !== null) throw new Error('記憶石の調律結果が未確定のまま探索はできません。');
    if (Object.keys(inventory.equipped).some(id => !(value.ownedIds as string[]).includes(id))) throw new Error('記憶石を装備している仲間が不正です。');
  }
  if (!materialMap(value.materials)) throw new Error('保存データの素材数が不正です。');
  if (!Array.isArray(value.history) || value.history.some(item => !record(item) || typeof item.id !== 'string' || typeof item.text !== 'string')) throw new Error('保存データの履歴が不正です。');
  const settings = value.settings;
  if (!record(settings) || ![1, 2].includes(settings.speed as number) || typeof settings.reducedMotion !== 'boolean' || ['bgmVolume', 'seVolume'].some(key => typeof settings[key] !== 'number' || !Number.isFinite(settings[key]) || Number(settings[key]) < 0 || Number(settings[key]) > 1)) throw new Error('保存データの設定が不正です。');
  if (settings.homeCharacterId !== undefined && settings.homeCharacterId !== null && (!nonempty(settings.homeCharacterId) || !(value.ownedIds as string[]).includes(settings.homeCharacterId))) throw new Error('ホームの表示設定が不正です。');
  if (value.battle !== null) {
    const battle = value.battle;
    if (record(battle) && (battle.tracking !== undefined && !validExpeditionTracking(battle.tracking) || battle.failureKind !== undefined && !['defeat', 'timeout', 'retreat'].includes(String(battle.failureKind)))) throw new Error('探索の集計状態が不正です。');
    if (!record(battle) || !nonempty(battle.id) || !nonempty(battle.dungeonId) || !nonempty(battle.contentVersion) || !nonempty(battle.rulesVersion) || !['ready', 'playing', 'reward', 'failed'].includes(battle.phase as string) || !['ready', 'wave', 'reward', 'failed'].includes(battle.nextPhase as string) || !validUnits(battle.units) || !Array.isArray(battle.events) || !battle.events.every(validEvent) || !validUnits(battle.initialUnits) || !count(battle.cursor) || battle.cursor > battle.events.length || !count(battle.wave) || !count(battle.round) || battle.round < 1 || !materialMap(battle.pendingMaterials) || !uniqueStrings(battle.partyIds) || !nonempty(battle.leaderId) || !battle.partyIds.includes(battle.leaderId) || !uniqueStrings(battle.talkFlags) || !count(battle.potionsRemaining) || battle.potionsRemaining > 5 || typeof battle.potionUsed !== 'boolean' || !count(battle.seed) || !count(battle.goldEarned) || !['balanced', 'aggressive', 'survival'].includes(battle.strategy as string)) throw new Error('探索の保存状態を読み込めません。セーブは保持されています。');
    if (battle.scoutState !== undefined) {
      const s = battle.scoutState;
      if (!record(s) || ['ioneLeaderTriggered','neriLeaderTriggered','fioLeaderTriggered'].some(k => s[k] !== undefined && typeof s[k] !== 'boolean') || s.rukaHeals !== undefined && (!count(s.rukaHeals) || s.rukaHeals > 3) || s.rukaHealRound !== undefined && !count(s.rukaHealRound)) throw new Error('仲間の固有技能の記録が不正です。');
    }
    if (battle.memoryGems !== undefined && (!record(battle.memoryGems) || Object.entries(battle.memoryGems).some(([id, gem]) => !(battle.partyIds as string[]).includes(id) || !validMemoryGem(gem)))) throw new Error('戦闘の記憶石が不正です。');
    if (battle.memoryGems !== undefined && new Set(Object.values(battle.memoryGems as Record<string, { id: string }>).map(gem => gem.id)).size !== Object.values(battle.memoryGems).length) throw new Error('同じ記憶石が複数の仲間に装備されています。');
    if (battle.gemChestChecks !== undefined && !uniqueStrings(battle.gemChestChecks)) throw new Error('宝箱の開封記録が不正です。');
    if (battle.gemFinds !== undefined && (!Array.isArray(battle.gemFinds) || !battle.gemFinds.every(validMemoryGem) || new Set(battle.gemFinds.map(gem => gem.id)).size !== battle.gemFinds.length)) throw new Error('宝箱の獲得記録が不正です。');
    if (battle.memoryEchoes !== undefined && (!Array.isArray(battle.memoryEchoes) || battle.memoryEchoes.some(echo => !record(echo) || !nonempty(echo.actorId) || !nonempty(echo.targetId) || !count(echo.dueRound) || !count(echo.power) || !nonempty(echo.skillId) || !gemDefinitionForSkill(echo.skillId) || !nonempty(echo.name)))) throw new Error('記憶石の残響状態が不正です。');
    if (battle.crystalRole !== undefined && !validCrystalRole(battle.crystalRole)) throw new Error('宝石の共鳴状態が不正です。');
    if (battle.partyOrder !== undefined && !validPartyOrder(battle.partyOrder)) throw new Error('行動の予約が正しくありません。');
    if (battle.commandOrder !== undefined && (!record(battle.commandOrder) || !nonempty(battle.commandOrder.targetId) || !uniqueStrings(battle.commandOrder.followerIds) || !battle.commandOrder.followerIds.length || battle.commandOrder.followerIds.length > 3)) throw new Error('号令の予約が正しくありません。');
    if (battle.commandIssuedRound !== undefined) throw new Error('号令の一時状態を保存できません。');
    if (battle.focusTargetId !== undefined && (!nonempty(battle.focusTargetId) || !(battle.units as { uid: string; side: string }[]).some(u => u.uid === battle.focusTargetId && u.side === 'enemy'))) throw new Error('狙う敵を選んでください。');
    if (battle.fairies !== undefined && !validBattleFairies(battle.fairies, battle as unknown as Parameters<typeof validBattleFairies>[1])) throw new Error('妖精の保存状態が不正です。');
    if (battle.blooms !== undefined && !validBattleBlooms(battle.blooms, battle as unknown as Parameters<typeof validBattleBlooms>[1])) throw new Error('花の保存状態が不正です。');
    if (battle.omens !== undefined && !validLegacyOmens(battle.omens, battle as unknown as Parameters<typeof validLegacyOmens>[1])) throw new Error('痕跡の保存状態が不正です。');
    if (battle.phase !== 'playing' && battle.cursor !== battle.events.length) throw new Error('探索演出の完了状態が不正です。');
  }
}

/** Resolve all persisted IDs against the selected immutable content release. */
export function assertSaveCompatibility(save: GameSave, content: Content): void {
  assertValidSave(save);
  if (save.schemaVersion !== content.schemaVersion || save.appVersion !== content.appVersion || save.contentVersion !== content.contentVersion || save.rulesVersion !== content.rulesVersion) throw new Error('このセーブに対応するリリースで再開してください。');
  if (content.appVersion === RELEASE.appVersion && save.towerRecord?.version !== '1.10') throw new Error('1.10の白亜の塔の記録がありません。');
  if (duplicateFamily(save.partyIds, content)) throw new Error('同じ仲間の複数形態が編成されています。セーブは保持しています。');
  const characters = new Set(content.characters.map(item => item.id));
  const skills = new Set(content.skills.map(item => item.id));
  const species = new Set(content.species.map(item => item.id));
  const assertReviewReferences = (review: import('../domain/expedition-review').BattleReview | undefined) => {
    const hit = review?.largestHit;
    if (hit && (!characters.has(hit.targetCharacterId) || hit.actorCharacterId !== undefined && !characters.has(hit.actorCharacterId) || hit.skillId !== undefined && !skills.has(hit.skillId) && !gemDefinitionForSkill(hit.skillId))) throw new Error('探索の集計が参照する仲間や技がありません。');
  };
  for (const item of save.expeditionHistory ?? []) {
    if (item.contentVersion !== content.contentVersion || item.rulesVersion !== content.rulesVersion) continue;
    if (!content.dungeons.some(d => d.id === item.dungeonId) || Object.keys(item.earned.materials).some(id => !species.has(id.split(':')[0]!)) || item.review && item.potionsUsed !== null && item.review.potionsUsed !== item.potionsUsed) throw new Error('周回の実績の参照先が不正です。');
    assertReviewReferences(item.review);
  }
  const dungeonIds = new Set(content.dungeons.map(item => item.id));
  if ([...save.ownedIds, ...save.discoveredIds].some(id => !characters.has(id)) || save.completedDungeonIds.some(id => !dungeonIds.has(id)) || Object.keys(save.materials).some(id => !species.has(id.split(':')[0]!))) throw new Error('保存データが参照する定義がありません。セーブを保持して停止します。');
  if ([...(save.lastGachaResults ?? []), ...(save.lastGachaResult ? [save.lastGachaResult] : [])].some(result => !characters.has(result.characterId) || !save.ownedIds.includes(result.characterId))) throw new Error('祈願の結果が所持情報と一致しません。');
  if (save.novels) {
    if (save.novels.seen.some(id => !content.novels?.some(scene => scene.id === id))) throw new Error('物語の固定定義がありません。');
    const active = save.novels.active;
    if (active) {
      const scene = content.novels?.find(scene => scene.id === active.sceneId);
      if (!scene || active.page >= scene.pages.length || (scene.trigger.kind === 'dungeon-clear' && !save.completedDungeonIds.includes(scene.trigger.dungeonId))) throw new Error('物語を再開するための定義がありません。');
    }
  }
  const battle = save.battle;
  if (!battle) return;
  assertReviewReferences(battle.tracking?.review);
  if (battle.commandOrder !== undefined) validateCommandOrder(battle.commandOrder, battle, content, { stored: true });
  const dungeon = content.dungeons.find(item => item.id === battle.dungeonId);
  if (battle.partyOrder?.kind === 'skill' && !content.characters.find(c => c.id === battle.partyIds[0])?.skillIds.includes(battle.partyOrder.skillId) && (!battle.memoryGems?.[battle.partyIds[0]!] || gemSkill(battle.memoryGems[battle.partyIds[0]!]!).id !== battle.partyOrder.skillId)) throw new Error('行動の予約が正しくありません。');
  if (!dungeon || battle.wave >= dungeon.waves.length || battle.contentVersion !== content.contentVersion || battle.rulesVersion !== content.rulesVersion || battle.partyIds.some(id => !save.ownedIds.includes(id)) || Object.keys(battle.pendingMaterials).some(id => !species.has(id.split(':')[0]!))) throw new Error('探索を再開するための固定定義がありません。');
  if (battle.memoryGems && Object.entries(battle.memoryGems).some(([characterId, gem]) => !save.memoryGems?.items.some(item => item.id === gem.id && gemRollKey(item) === gemRollKey(gem)) || save.memoryGems.equipped[characterId] !== gem.id)) throw new Error('戦闘の記憶石が所持・装備情報と一致しません。');
  if (battle.gemFinds?.some(gem => !save.memoryGems?.items.some(item => item.id === gem.id && gemRollKey(item) === gemRollKey(gem)))) throw new Error('獲得した記憶石が所持情報にありません。');
  if (battle.memoryEchoes?.some(echo => !battle.units.some(unit => unit.uid === echo.actorId && unit.side === 'party') || !battle.units.some(unit => unit.uid === echo.targetId && unit.side === 'enemy'))) throw new Error('記憶石の残響対象が戦闘データにありません。');
  if (battle.omens && dungeon.kind === 'trial') throw new Error('腕試しの探索状態が不正です。');
  const snapshots = [battle.units, battle.initialUnits, ...battle.events.flatMap(event => event.unitsAfter ? [event.unitsAfter] : [])];
  if (snapshots.some(units => units.some(unit => unit.whiteFlower && (unit.characterId !== battle.partyIds[0] || unit.whiteFlower.until > battle.round + 2)))) throw new Error('白花の種の対象か期限が正しくありません。');
  if (snapshots.some(units => units.some(unit => (unit.bossWindup?.round ?? 0) > battle.round || (unit.bossRecoveryUntil ?? 0) > battle.round))) throw new Error('ボスの予告状態が探索のラウンドと一致しません。');
  if (snapshots.some(units => units.some(unit => !characters.has(unit.characterId) || Object.keys(unit.cooldowns).some(id => !skills.has(id) && id !== 'memory:slot' && !gemDefinitionForSkill(id))))) throw new Error('戦闘データが参照するキャラクター・スキルがありません。');
  if (snapshots.some(units => units.some(unit => unit.scoutMark && !units.some(source => source.uid === unit.scoutMark!.sourceId && source.side === 'party')))) throw new Error('道標の付与者が探索に存在しません。');
  if (snapshots.some(units => units.some(unit => Object.values(unit.ailments ?? {}).some(state => !units.some(source => source.uid === state.sourceId))))) throw new Error('状態異常の付与者が戦闘データにありません。');
  if (battle.events.some(event => event.skillId && !skills.has(event.skillId) && !gemDefinitionForSkill(event.skillId))) throw new Error('保存済み演出のスキル定義がありません。');
}

export function bootMetadata(save: GameSave): BootMetadata {
  return { contractVersion: 1, schemaVersion: save.schemaVersion, appVersion: save.appVersion, contentVersion: save.contentVersion, rulesVersion: save.rulesVersion, hasExploration: save.battle !== null, hasPendingRewards: save.battle?.phase === 'reward' || save.battle?.nextPhase === 'reward', revision: save.revision };
}

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') { reject(new Error('この環境ではブラウザー保存が利用できません。')); return; }
    const request = indexedDB.open(SAVE_DATABASE, 1);
    request.onupgradeneeded = () => { if (!request.result.objectStoreNames.contains(SAVE_STORE)) request.result.createObjectStore(SAVE_STORE); };
    request.onsuccess = () => { const db = request.result; db.onversionchange = () => db.close(); resolve(db); };
    request.onerror = () => reject(new Error('保存領域を開けません。ブラウザー設定を確認してください。'));
    request.onblocked = () => reject(new Error('別のタブが保存領域を使用しています。ほかのタブを閉じてください。'));
  });
}

async function readRecord(key: string): Promise<unknown> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(SAVE_STORE, 'readonly');
    const request = transaction.objectStore(SAVE_STORE).get(key);
    let value: unknown;
    request.onsuccess = () => { value = request.result; };
    transaction.oncomplete = () => { db.close(); resolve(value); };
    transaction.onabort = transaction.onerror = () => { db.close(); reject(new Error('保存データを読み込めません。')); };
  });
}

export async function loadSave(): Promise<GameSave | null> {
  const db = await openDatabase();
  const pair = await new Promise<{ value: unknown; boot: unknown }>((resolve, reject) => {
    const transaction = db.transaction(SAVE_STORE, 'readonly');
    const store = transaction.objectStore(SAVE_STORE);
    const saveRequest = store.get('save'); const bootRequest = store.get('boot');
    transaction.oncomplete = () => { db.close(); resolve({ value: saveRequest.result, boot: bootRequest.result }); };
    transaction.onabort = transaction.onerror = () => { db.close(); reject(new Error('保存データを読み込めません。')); };
  });
  const value = pair.value;
  if (value === undefined) {
    if (pair.boot !== undefined) throw new Error('保存本体が見つかりません。既存の起動情報を保持して停止します。');
    return null;
  }
  assertValidSave(value);
  const expected = bootMetadata(value);
  const metadata = pair.boot;
  if (!record(metadata) || Object.entries(expected).some(([key, item]) => metadata[key] !== item)) throw new Error('セーブと起動メタ情報が一致しません。既存セーブを保持して停止します。');
  return value;
}

/** The launcher reads this record before importing or migrating a release. */
export async function readBootMetadata(): Promise<BootMetadata | null> {
  const value = await readRecord('boot');
  if (value === undefined) {
    if (await readRecord('save') !== undefined) throw new Error('起動メタ情報がありません。既存セーブを保持して停止します。');
    return null;
  }
  if (!record(value) || value.contractVersion !== 1 || !count(value.schemaVersion) || !count(value.revision) || typeof value.appVersion !== 'string' || typeof value.contentVersion !== 'string' || typeof value.rulesVersion !== 'string' || typeof value.hasExploration !== 'boolean' || typeof value.hasPendingRewards !== 'boolean') throw new Error('起動メタ情報を読めません。既存セーブを保持して停止します。');
  return value as unknown as BootMetadata;
}

/** Compare-and-swap and the save/boot write share one IndexedDB transaction. */
export async function persistSave(save: GameSave, expectedRevision?: number, options: { legacySource?: GameSave } = {}): Promise<void> {
  assertValidSave(save);
  if (expectedRevision !== undefined && (!count(expectedRevision) || save.revision !== expectedRevision + 1)) throw new Error('保存の更新順序が正しくありません。');
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(SAVE_STORE, 'readwrite');
    const store = transaction.objectStore(SAVE_STORE);
    const request = store.get('save');
    let reason = '保存に失敗しました。空き容量・ブラウザー設定を確認して再試行してください。';
    request.onsuccess = () => {
      const previous: unknown = request.result;
      try {
        if (previous === undefined) {
          if (expectedRevision !== undefined || save.revision !== 0) throw new Error('保存データが変更されています。再読み込みしてください。');
        } else {
          assertValidSave(previous);
          if (expectedRevision === undefined || previous.revision !== expectedRevision) throw new Error('別のタブで進行が更新されました。このタブを再読み込みしてください。');
          if (previous.appVersion !== save.appVersion || previous.schemaVersion !== save.schemaVersion || previous.contentVersion !== save.contentVersion || previous.rulesVersion !== save.rulesVersion) throw new Error('異なる版から保存しようとしています。対応するリリースで再開してください。');
          store.put(previous, 'backup');
        }
        if (options.legacySource) {
          assertValidSave(options.legacySource);
          if (!isLegacySaveVersion(options.legacySource)) throw new Error('移行元の版を確認できません。');
          store.put(options.legacySource, 'migration-v1.0');
        }
        store.put(save, 'save');
        store.put(bootMetadata(save), 'boot');
      } catch (error) {
        reason = error instanceof Error ? error.message : reason;
        transaction.abort();
      }
    };
    transaction.oncomplete = () => { db.close(); resolve(); };
    transaction.onabort = transaction.onerror = () => { db.close(); reject(new Error(reason)); };
  });
}

/** Only the previously released 1.0 internal contract is an accepted upgrade source. */
export function isLegacySaveVersion(value: Pick<GameSave, 'schemaVersion' | 'appVersion' | 'contentVersion' | 'rulesVersion'>): boolean {
  return value.schemaVersion === 1 && value.appVersion === '0.1.0' && value.contentVersion === 'initial-r1' && value.rulesVersion === '1';
}
/** 1.11 only changes presentation; 1.10 combat/farming snapshots remain valid. */
export function isPortraitHotfixSaveVersion(value: Pick<GameSave, 'schemaVersion' | 'appVersion' | 'contentVersion' | 'rulesVersion'>): boolean {
  return RELEASE.appVersion === '1.11.0' && value.schemaVersion === RELEASE.schemaVersion && value.appVersion === '1.10.0' && value.contentVersion === RELEASE.contentVersion && value.rulesVersion === RELEASE.rulesVersion;
}
export function isUpgradeableSaveVersion(value: Pick<GameSave, 'schemaVersion' | 'appVersion' | 'contentVersion' | 'rulesVersion'>): boolean {
  return isLegacySaveVersion(value) || isPortraitHotfixSaveVersion(value);
}
/** Upgrade save, boot metadata and the permanent original in one compare-and-swap transaction. */
export async function persistMigratedSave(next: GameSave, previous: GameSave): Promise<void> {
  assertValidSave(previous); assertValidSave(next);
  if (!isUpgradeableSaveVersion(previous) || next.appVersion !== RELEASE.appVersion || next.contentVersion !== RELEASE.contentVersion || next.rulesVersion !== RELEASE.rulesVersion || next.schemaVersion !== RELEASE.schemaVersion || next.revision !== previous.revision + 1) throw new Error('保存データの移行順序が正しくありません。');
  const db = await openDatabase();
  return new Promise((resolve,reject) => {
    const tx = db.transaction(SAVE_STORE,'readwrite'), store = tx.objectStore(SAVE_STORE), req = store.get('save');
    let reason = '更新前の保存データを保持して、移行を中止しました。';
    req.onsuccess = () => {
      try {
        if (JSON.stringify(req.result) !== JSON.stringify(previous)) throw new Error('別のタブで進行が更新されました。再読み込みしてください。');
        store.put(previous,isLegacySaveVersion(previous) ? 'migration-v1.0' : 'migration-v1.10'); store.put(previous,'backup');
        store.put(next,'save'); store.put(bootMetadata(next),'boot');
      } catch (e) { reason = e instanceof Error ? e.message : reason; tx.abort(); }
    };
    tx.oncomplete = () => {db.close();resolve();};
    tx.onabort = tx.onerror = () => {db.close();reject(new Error(reason));};
  });
}
/** The original 1.0 record is never rotated by ordinary saves. */
export async function loadMigrationBackup(): Promise<GameSave | null> {
  const value = await readRecord('migration-v1.0');
  if (value === undefined) return null;
  assertValidSave(value);
  return value;
}
